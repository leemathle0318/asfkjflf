#import "Receiver.h"
#import "MediaBus.h"
#import "Shared.h"
#import "Client.h"
#include <atomic>
#include "core/VideoBudget.hpp"
#include <notify.h>
#include <cmath>
#include <mutex>

namespace {
dispatch_source_t tickTimer;
dispatch_queue_t producerQueue;
std::mutex diagnosticLock;
NSString *lastRequest;
NSString *commandError = @"";
NSString *statusWriteError = @"";
std::atomic<bool> heartbeatBusy{false};
void phoneHeartbeat(void) {
    static double last=0;double now=OBNow();if(now-last<5)return;last=now;
    NSDictionary *c=[NSDictionary dictionaryWithContentsOfFile:OB_CONFIG],*p=c[@"Pairing"];
    if(![p isKindOfClass:NSDictionary.class] || ![c[@"Mode"] isEqual:@"RTMP"] ||
        ![c[@"RTMPURL"] isEqual:p[@"rtmp"]] || ![p[@"server"] isKindOfClass:NSString.class] ||
        ![p[@"heartbeat_key"] isKindOfClass:NSString.class] || ![p[@"device"] isKindOfClass:NSString.class] ||
        heartbeatBusy.exchange(true))return;
    NSString *url=[NSString stringWithFormat:@"http://%@:%ld/heartbeat",p[@"server"],(long)[p[@"port"] integerValue]];
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    request.timeoutInterval=4;request.HTTPMethod=@"POST";[request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSMutableDictionary *data=[OBReceiveCounters() mutableCopy];data[@"channel_id"]=p[@"channel_id"]?:@"";
    data[@"device"]=p[@"device"];data[@"key"]=p[@"heartbeat_key"];
    request.HTTPBody=[NSJSONSerialization dataWithJSONObject:data options:0 error:nil];
    [[NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *reply,NSURLResponse *response,NSError *error){
        (void)reply;(void)response;(void)error;heartbeatBusy=false;
    }] resume];
}
void videoRotation(NSDictionary *config) {
    id value = config[@"VideoRotation"];
    unsigned turns = [value isKindOfClass:NSNumber.class] ? unsigned([value unsignedIntegerValue] & 3) : 0;
    OBBusSetVideoRotation(turns);
    NSDictionary *t=config[@"Transform"];obs::VideoTransform v;
    if([t isKindOfClass:NSDictionary.class]) {
        v.zoom=t[@"zoom"]?[t[@"zoom"] doubleValue]:1;v.x=[t[@"x"] doubleValue];v.y=[t[@"y"] doubleValue];
        v.left=[t[@"left"] doubleValue];v.right=[t[@"right"] doubleValue];v.top=[t[@"top"] doubleValue];v.bottom=[t[@"bottom"] doubleValue];
        v.landscape=[t[@"landscape"] boolValue];
    } OBBusSetTransform(v);
    id profile=config[@"VideoProfile"];
    OBBusSetVideoProfile([profile isKindOfClass:NSNumber.class]?obs::normalizedProfile(unsigned([profile unsignedIntegerValue])):2);
    id live = config[@"LiveAudio"];
    OBBusSetLiveAudioEnabled(![live isKindOfClass:NSNumber.class] || [live boolValue]);
}
void control(void) {
    NSDictionary *config = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    videoRotation(config); // Does not stop/restart OBS or replay a saved command.
    NSString *request = config[@"RequestID"];
    NSDate *date = config[@"RequestDate"];
    if (![request isKindOfClass:NSString.class] || [request isEqual:lastRequest] ||
        ![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow) > 15) return;
    lastRequest = request;
    BOOL enabled = [config[@"Enabled"] boolValue];
    if(enabled && [config[@"Mode"] isEqual:@"RTMP"]) {
        id url=config[@"RTMPURL"];
        if([url isKindOfClass:NSString.class]) OBStartRTMP(url);
        else {std::lock_guard<std::mutex> lock(diagnosticLock);commandError=@"RTMP地址无效";}
        return;
    }
    NSString *bind = config[@"BindIP"], *peer = config[@"PCIP"];
    if (enabled && (![bind isKindOfClass:NSString.class] || ![peer isKindOfClass:NSString.class])) {
        std::lock_guard<std::mutex> lock(diagnosticLock);
        commandError = @"启动配置中的 BindIP/PCIP 类型不正确"; return;
    }
    { std::lock_guard<std::mutex> lock(diagnosticLock); commandError = @""; }
    if (enabled) OBStart(bind, peer); else OBStop();
}
void saveStatus(void) {
    NSDictionary *status = @{@"Version": OB_VERSION, @"Date": [NSDate date],
        @"Text": OBControlStatus(), @"Enabled": @(OBEnabled())};
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:status
        format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    BOOL ok = data && [data writeToFile:OB_STATUS options:NSDataWritingAtomic error:&error];
    NSString *result = ok ? @"" : [NSString stringWithFormat:@"接收层状态文件写入失败：%@ (%@/%ld)",
        error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    std::lock_guard<std::mutex> lock(diagnosticLock);
    if (![result isEqual:statusWriteError]) {
        statusWriteError = result;
        if (!ok) NSLog(@"[OBSBridge] %@", result);
    }
}
}
NSString *OBControlStatus(void) {
    NSString *command, *file;
    { std::lock_guard<std::mutex> lock(diagnosticLock); command = commandError; file = statusWriteError; }
    return [NSString stringWithFormat:@"%@\n额外旋转 %u°\n%@\n%@", OBStatus(), OBBusVideoRotation() * 90, command, file];
}
__attribute__((constructor)) static void OBProducerInitialize(void) {
    producerQueue = dispatch_queue_create("local.xiaoguai.obsbridge.producer", DISPATCH_QUEUE_SERIAL);
    dispatch_async(producerQueue, ^{
        @autoreleasepool {
            NSString *error = OBBusCreate();
            if (error) NSLog(@"[OBSBridge] %@", error);
            // Never auto-start an old saved command after SpringBoard restarts.
            NSDictionary *old = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
            videoRotation(old);
            NSString *request = old[@"RequestID"];
            if ([request isKindOfClass:NSString.class]) lastRequest = request;
            int token;
            uint32_t rc = notify_register_dispatch(OB_NOTIFY, &token, producerQueue, ^(int value) {
                (void)value; control();
            });
            if (rc != NOTIFY_STATUS_OK) {
                std::lock_guard<std::mutex> lock(diagnosticLock);
                commandError = [NSString stringWithFormat:@"命令通知注册失败：%u；使用控制文件轮询", rc];
            }
            tickTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, producerQueue);
            dispatch_source_set_timer(tickTimer, dispatch_time(DISPATCH_TIME_NOW, 0),
                                      NSEC_PER_SEC / 2, NSEC_PER_SEC / 20);
            dispatch_source_set_event_handler(tickTimer, ^{
                @autoreleasepool {
                    OBProducerTick();
                    static double lastControl = 0, lastStatus = 0;
                    static unsigned timerFPS = 0;
                    double now = OBNow();
                    if (now - lastControl >= .45) { control(); phoneHeartbeat(); lastControl = now; }
                    if (now - lastStatus >= 1. && (OBEnabled() || now - lastStatus >= 5.)) { saveStatus(); lastStatus = now; }
                    BOOL active = OBEnabled();
                    unsigned fps=active?obs::videoBudget(OBBusVideoProfile(),unsigned(NSProcessInfo.processInfo.thermalState)).fps:2;
                    if (fps != timerFPS) {
                        timerFPS = fps;
                        uint64_t interval = NSEC_PER_SEC / fps;
                        dispatch_source_set_timer(tickTimer, dispatch_time(DISPATCH_TIME_NOW, interval), interval, interval / 8);
                    }
                }
            });
            dispatch_resume(tickTimer);
            NSLog(@"[OBSBridge] %@ SpringBoard receiver initialized", OB_VERSION);
        }
    });
}
