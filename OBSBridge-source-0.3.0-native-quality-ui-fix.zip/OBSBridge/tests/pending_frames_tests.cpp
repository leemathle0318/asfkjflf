#include "../core/PendingFrames.hpp"
#include "../core/PresentationClock.hpp"
#include "../core/SharedMedia.hpp"
#include <memory>
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <deque>
#include <cstdio>
static unsigned run(bool oldPolicy) {
    std::deque<double> queue; unsigned published = 0;
    for (unsigned i = 0; i < 300; ++i) {
        double now = double(i)/60;
        if (oldPolicy) {
            queue.push_back(now+.180);
            while (queue.size() > 6) queue.pop_front();
        } else obs::enqueuePending(queue, now+.180);
        bool ready = false;
        while (!queue.empty() && queue.front() <= now) { ready = true; queue.pop_front(); }
        if (ready) ++published;
    }
    return published;
}
int main() {
    auto pcm = std::make_unique<obs::SharedMedia>();
    pcm->initialize(); pcm->enabled=1; pcm->generation=1; pcm->heartbeatUS=1000000;
    float inputPCM[1024]; std::fill(std::begin(inputPCM),std::end(inputPCM),.5f);
    unsigned oldHoles=0, newHoles=0;
    for (bool smooth : {false,true}) {
        pcm->resetAudio();obs::AudioSampleClock audio;
        for (unsigned i=0;i<40;++i) {
            double due=1.+std::floor(i*1024.*1000./48000.)/1000.;
            if(smooth)due=audio.align(due,1024,48000,1);
            pcm->writeAudio(inputPCM,1024,due);
        }
        float output[1024];unsigned holes=0;
        for(unsigned i=0;i<40;++i) {
            assert(pcm->readAudio(output,1024,1.+i*1024./48000.,48000,1000000));
            for(float value:output)holes+=value==0;
        }
        if(smooth)newHoles=holes;else oldHoles=holes;
    }
    assert(oldHoles>100 && newHoles==0);
    obs::AudioSampleClock gap;
    assert(gap.align(10,1024,48000,1)==10);
    assert(gap.align(10.5,1024,48000,1)==10.5); // real gap is not masked
    assert(gap.align(12,1024,48000,2)==12); // common AV rebase invalidates continuity
    assert(!std::isfinite(gap.align(NAN,1024,48000,2)));
    std::printf("PASS: millisecond AAC timestamps: old PCM holes=%u, sample-continuous holes=%u; discontinuity/epoch retained\n",oldHoles,newHoles);
    // Startup probe backlog puts PTS 860 ms ahead: old admission rejects it
    // (<750 ms required), old reset never fires (only beyond 1000 ms).
    for (double shift : {.680, -.680, .450}) {
        obs::PresentationClock clock;
        clock.schedule(0, 100, false, true);
        unsigned accepted = 0, resets = 0;
        for (unsigned i = 1; i <= 900; ++i) {
            double now = 100 + i / 30., pts = i / 30. + shift;
            double oldDue = 100 + .180 + pts;
            if (shift != .450) assert(!obs::PresentationClock::usable(oldDue, now));
            assert(oldDue >= now - 1 && oldDue <= now + 1);
            auto v = clock.schedule(pts, now, true, true);
            resets += v.rebased;
            accepted += obs::PresentationClock::usable(v.due, now);
            auto a = clock.schedule(pts + .020, now, false, true);
            assert(!a.rebased);
            assert(std::abs(a.due - v.due - .020) < 1e-9); // retain AV offset
        }
        assert(accepted > 880 && resets == 1);
    }
    obs::PresentationClock legacy;
    legacy.schedule(0, 100, false, false);
    for (unsigned i = 1; i <= 90; ++i) {
        auto r = legacy.schedule(i/30. + .680, 100+i/30., true, false);
        assert(!r.rebased); // original TCP policy intentionally unchanged
    }
    obs::PresentationClock jitter;
    jitter.schedule(0, 100, false, true);
    for (unsigned i = 1; i <= 100; ++i) {
        double now = 100+i/30.;
        auto r = jitter.schedule(i/30. + (i%4 ? 0 : .680), now, true, true);
        assert(!r.rebased); // isolated bad arrival does not rebase both tracks
    }
    auto jump = jitter.schedule(500, 110, true, true);
    assert(jump.rebased && std::abs(jump.due-110.180)<1e-9);
    jitter.reset();
    assert(!jitter.schedule(1, 200, true, true).rebased);
    assert(!obs::PresentationClock::usable(NAN, 200));
    assert(!std::isfinite(jitter.schedule(NAN, 200, true, true).due));
    assert(run(true) == 0); // reproduce eviction before eligibility
    assert(run(false) > 250);
    std::deque<int> queue;
    for (unsigned i = 0; i < obs::MaximumPendingFrames; ++i) assert(obs::enqueuePending(queue, int(i)));
    assert(!obs::enqueuePending(queue, 999));
    assert(queue.front() == 0 && queue.back() == int(obs::MaximumPendingFrames-1));
    std::printf("PASS: old 6-frame/180-ms queue reproduces zero publications at 60 FPS; bounded replacement publishes %u\n", run(false));
    std::puts("PASS: sustained early/late RTMP deadband recovery, shared AV offset, jitter, discontinuity, reset; legacy TCP clock unchanged");
}
