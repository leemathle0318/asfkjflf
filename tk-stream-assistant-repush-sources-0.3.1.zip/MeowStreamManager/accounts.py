from pathlib import Path
import json
import sys
import time
from PySide6.QtCore import QObject,Signal
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QLineEdit,QApplication
from account_browser import BrowserWorker

class Bridge(QObject):
    received=Signal(object)

class AccountWindow(QDialog):
    def __init__(self,store,id,parent=None):
        super().__init__(parent)
        self.store=store;self.id=id;self.worker=None;self.last_diagnostic={}
        self.setWindowTitle(f'TikTok 账号 · 通道 {id}');self.resize(800,220)
        root=QVBoxLayout(self);bar=QHBoxLayout();root.addLayout(bar)
        row=store.get(id)
        self.alias=QLineEdit(row.get('account_alias',''));self.alias.setPlaceholderText('账号备注（不代表已登录）')
        bar.addWidget(self.alias)
        for text,fn in [('保存备注',self.save_alias),('官方扫码／控制台',self.home),('打开直播大屏',self.dashboard),('刷新数据',self.read_metrics)]:
            b=QPushButton(text);b.clicked.connect(fn);bar.addWidget(b)
        self.tip=QLabel('每个通道使用独立 Edge 窗口，用手机 TikTok 扫官方二维码。可以最小化，请勿关闭需要读取的大屏标签。')
        self.tip.setWordWrap(True);root.addWidget(self.tip)
        note=QLabel('首次需重新扫码。关闭此设置框不关闭 Edge、不停止读取；退出软件才关闭软件创建的账号浏览器。')
        note.setWordWrap(True);root.addWidget(note)
        copy=QPushButton('复制网页诊断（不含登录凭据）');copy.clicked.connect(self.copy_diagnostic);root.addWidget(copy)
        self.bridge=Bridge(self);self.bridge.received.connect(self.receive)
        base=Path(getattr(sys,'_MEIPASS',Path(__file__).parent))
        self.script=(base/'extractor.js').read_text(encoding='utf-8');self.home()
    def send(self,command):
        if not self.worker or not self.worker.is_alive():
            self.worker=BrowserWorker(self.store.root,self.id,self.script,self.bridge.received.emit);self.worker.start()
        self.worker.submit(command)
    def save_alias(self):self.store.update(self.id,dict(account_alias=self.alias.text().strip()))
    def home(self):self.send('home')
    def dashboard(self):self.send('dashboard')
    def read_metrics(self):self.send('read')
    def receive(self,result):
        if not self.store.get(self.id):return
        if result.get('message'):self.tip.setText(result['message'])
        snapshot=result.get('snapshot')
        if not isinstance(snapshot,dict):return
        metrics=snapshot.get('metrics',{});state=snapshot.get('state','unknown')
        self.last_diagnostic={'channel':self.id,'state':state,'metrics':metrics,'diagnostic':snapshot.get('diagnostic',{}),'updated':time.strftime('%H:%M:%S')}
        self.store.update(self.id,dict(metrics=metrics,metrics_updated=time.time(),account_state=state))
        labels=dict(login='请在 Edge 中完成官方扫码',live='直播中',ended='直播已结束',restricted='账号受限',unknown='直播状态未确认')
        missing=[{'gmv':'归因GMV','items':'归因成交件数','online':'在线人数','views':'浏览人数'}[k]
                 for k in ('gmv','items','online' if state=='live' else 'views') if k not in metrics]
        self.tip.setText(labels.get(state,state)+(' · 未读取到：'+'、'.join(missing)+'。打开官方大屏后刷新数据；仍缺项可复制网页诊断。' if missing else ' · 已按当前大屏实际标签读取。'))
    def copy_diagnostic(self):QApplication.clipboard().setText(json.dumps(self.last_diagnostic,ensure_ascii=False,indent=2))
    def shutdown(self):
        if self.worker:self.worker.stop();self.worker.join(timeout=35)
        self.close()
