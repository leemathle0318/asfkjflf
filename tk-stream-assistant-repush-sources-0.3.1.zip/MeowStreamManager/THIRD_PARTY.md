# 第三方组件与源码

## 账号浏览器更新

- Playwright 1.63.0：Apache-2.0，https://github.com/microsoft/playwright-python/tree/v1.63.0 。随包 driver 目录保留 Node、Playwright 和各依赖原始 LICENSE/NOTICE；不下载或分发 Microsoft Edge，用户安装的 Edge 依其自身条款使用。
- pyee 13.0.1（MIT）、greenlet 3.5.6（MIT/PSF）、typing-extensions 4.16.0（PSF-2.0）：原许可证保留在 licenses 目录。所有依赖版本见 requirements.txt。
- Qt WebEngine 编解码边界：https://doc.qt.io/qtforpython-6/overviews/qtwebengine-features.html 。旧包本机 H.264/AAC 能力测试均为空；新账号网页不再通过 Qt WebEngine 播放。
- Edge 独立持久化上下文：https://playwright.dev/python/docs/api/class-browsertype#browser-type-launch-persistent-context 。每通道使用专用目录，不使用个人默认浏览器目录。

以上是实现依据，不代表已验证用户实际 TikTok 账号或网站所有版本。

本软件自己的源码采用MIT许可；随附第三方库各自许可不变。动态库不加密、不禁止替换或为调试库修改而逆向。

- Qt/PySide6 6.12.0：随附原始LICENSE；源码 https://code.qt.io/cgit/pyside/pyside-setup.git/ 与 https://code.qt.io/cgit/qt/ 。使用动态Qt库，构建依赖锁见配套源码。
- PyAV 19.0.1：BSD，https://github.com/PyAV-Org/PyAV/tree/v19.0.1 ，其FFmpeg动态库许可见原始COPYING文件。
- FFprobe：BtbN的LGPL shared构建；实际版本 n9.0.2-27-g7e93014c5b-20261012。源码 https://github.com/FFmpeg/FFmpeg/tree/7e93014c5b ，构建配置 https://github.com/BtbN/FFmpeg-Builds 。运行库下载来源和原包SHA256在runtime/ffprobe-download.json，原始LGPL3在runtime/licenses/LICENSE.txt。
- 手机FFmpeg为7.1.5，仅LGPL组件；源码和静态库重链接材料由手机编译工作流保留。
- MediaMTX v1.21.2：MIT，https://github.com/bluenviron/mediamtx/tree/v1.21.2 ，原始LICENSE及原包SHA256随runtime提供。
- Pillow、psutil、qrcode、Python、PyInstaller依各自原始许可。PyInstaller bootloader许可允许分发生成的程序。

电脑源码包与Windows包共同构成可重建交付：把Windows包_internal/runtime复制到源码runtime，再按build_windows.ps1构建。勿移除许可证；公开二次分发前检查各组件完整的许可和相应源码要求。
