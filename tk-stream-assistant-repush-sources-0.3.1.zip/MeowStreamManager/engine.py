"""Local channel state and FFmpeg-library packet-copy publisher. No video decoding."""
from __future__ import annotations
import hashlib, json, os, re, secrets, sqlite3, subprocess, sys, tempfile, threading, time
from fractions import Fraction
from contextlib import contextmanager
from pathlib import Path
import av

VERSION = '0.3.1'
CREATE_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

def atomic_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    temp=Path(name)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False))
        for attempt in range(6):
            try:os.replace(temp,path);break
            except PermissionError:
                if attempt==5:raise
                time.sleep(.01*(attempt+1))
    finally:
        if temp.exists():temp.unlink()

def runtime_root():
    return Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)) / 'runtime'

def app_data():
    root = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'MeowStreamManager'
    root.mkdir(parents=True, exist_ok=True)
    return root

def probe(path):
    path = Path(path).resolve()
    if not path.is_file() or path.suffix.lower() != '.mp4':
        raise ValueError('请选择可读取的 MP4 文件')
    tool = runtime_root()/'ffprobe.exe'
    if not tool.is_file(): raise ValueError('软件缺少随附的 ffprobe.exe，请完整解压软件包')
    result = subprocess.run([str(tool), '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)],
        capture_output=True, timeout=30, creationflags=CREATE_NO_WINDOW)
    if result.returncode: raise ValueError('视频检查失败：'+result.stderr.decode('utf-8','replace')[:300])
    info = json.loads(result.stdout); streams = info['streams']
    video = next((s for s in streams if s.get('codec_type')=='video' and not s.get('disposition',{}).get('attached_pic')), None)
    audio = next((s for s in streams if s.get('codec_type')=='audio'), None)
    if not video or video.get('codec_name')!='h264': raise ValueError('视频必须为 H.264；请先离线转换，不会偷偷实时重编码')
    if not audio or audio.get('codec_name')!='aac': raise ValueError('必须包含 AAC 音轨，否则手机无法获得素材声音')
    w,h=int(video['width']),int(video['height'])
    if max(w,h)>2048 or w*h>1920*1080: raise ValueError('超出当前手机解码上限：单边≤2048，总像素≤2073600；比例不限')
    if not 8000 <= int(audio['sample_rate']) <= 96000 or int(audio['channels']) not in (1,2):
        raise ValueError('音频需要 8–96kHz，单声道或双声道')
    signature, extradata = codec_signature(path)
    duration = float(info.get('format',{}).get('duration',0))
    if duration<=0: raise ValueError('无法获取有效的视频时长')
    bitrate=int(info.get('format',{}).get('bit_rate',0) or 0)
    warnings=[]
    if video.get('avg_frame_rate') != video.get('r_frame_rate'): warnings.append('可能是可变帧率，请检查播放节奏')
    if Fraction(video.get('avg_frame_rate','0/1'))>30: warnings.append('高于30fps，手机负载可能增加')
    # Only packet headers in the first 12 seconds: never decode frames.
    sample=subprocess.run([str(tool),'-v','error','-read_intervals','%+12','-show_packets',
        '-show_entries','packet=stream_index,dts_time,pts_time,size,flags','-of','json',str(path)],
        capture_output=True,timeout=30,creationflags=CREATE_NO_WINDOW)
    buckets={}; last={}; peak=0; first_video=False
    if sample.returncode==0:
        for p in json.loads(sample.stdout).get('packets',[]):
            i=int(p['stream_index']); stamp=p.get('dts_time')
            if stamp is None: warnings.append('存在缺少 DTS 的数据包');continue
            d=float(stamp)
            if i in last and d<=last[i]: warnings.append('存在非递增 DTS')
            last[i]=d; b=int(d//1); buckets[b]=buckets.get(b,0)+int(p.get('size',0))*8
            if i==video['index'] and not first_video:
                first_video=True
                if 'K' not in p.get('flags',''): raise ValueError('文件首个视频包不是关键帧，不能安全接入循环流')
        peak=max(buckets.values(),default=0)
    else: warnings.append('未能检查前12秒的峰值码率和时间戳')
    return dict(path=str(path),width=w,height=h,fps=video.get('avg_frame_rate'),
        bitrate=bitrate,peak_sample=peak,duration=duration,sample_rate=int(audio['sample_rate']),
        channels=int(audio['channels']),signature=signature,extradata=extradata,warnings=sorted(set(warnings)))

def codec_signature(path):
    with av.open(str(path)) as src:
        v=next(s for s in src.streams.video if not (int(s.disposition) & 1024))
        a=src.streams.audio[0]
        def desc(s):
            c=s.codec_context
            return [c.name,hashlib.sha256(c.extradata or b'').hexdigest(),
                getattr(c,'width',0),getattr(c,'height',0),getattr(c,'sample_rate',0),
                str(getattr(c,'layout','')),str(s.time_base)]
        data=[desc(v),desc(a)]
        return hashlib.sha256(json.dumps(data).encode()).hexdigest(),data

def compatible(left, right):
    return bool(left.get('signature')) and left['signature']==right.get('signature')

def bandwidth(rows,total,reserve,margin):
    if min(total,reserve)<0 or not 0<=margin<1: raise ValueError('带宽不能为负，安全余量须小于100%')
    budget=max(0,total-reserve)*(1-margin)
    need=sum(max(r.get('metadata',{}).get('bitrate',0),r.get('metadata',{}).get('peak_sample',0))*1.15/1e6 for r in rows if r.get('enabled',True))
    return dict(budget=budget,used=need,remaining=budget-need,
                extra=max(0,int((budget-need)/(5.128*1.15))))

class Store:
    def __init__(self,root=None):
        self.root=Path(root or app_data());self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'channels.sqlite3';self.lock=threading.RLock()
        with self.connection() as db:
            db.execute('CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, data TEXT)')
    @contextmanager
    def connection(self):
        c=sqlite3.connect(self.path,timeout=10);c.row_factory=sqlite3.Row
        try:
            with c:yield c
        finally:c.close()
    def rows(self):
        with self.connection() as c:
            return [dict(json.loads(r['data']),id=r['id']) for r in c.execute('SELECT * FROM channels ORDER BY id')]
    def get(self,id):
        return next((r for r in self.rows() if r['id']==id),None)
    def save(self,row):
        with self.lock,self.connection() as c:
            if row.get('id'):
                c.execute('UPDATE channels SET data=? WHERE id=?',(json.dumps(row,ensure_ascii=False),row['id']))
            else:
                row['id']=c.execute('INSERT INTO channels(data) VALUES(?)',(json.dumps(row,ensure_ascii=False),)).lastrowid
                row.setdefault('stream_path',f"live/phone{row['id']:04d}-"+secrets.token_hex(8))
                c.execute('UPDATE channels SET data=? WHERE id=?',(json.dumps(row,ensure_ascii=False),row['id']))
        return row
    def create(self):
        return self.save(dict(label='',remark='',video='',enabled=True,metadata={},device='',
            account_alias='',metrics={},heartbeat=0,desired_state='stopped',created_at=time.time()))
    def remove(self,id):
        with self.lock,self.connection() as c:c.execute('DELETE FROM channels WHERE id=?',(id,))
    def setting(self,key,default=None):
        with self.connection() as c:r=c.execute('SELECT data FROM settings WHERE key=?',(key,)).fetchone()
        return json.loads(r[0]) if r else default
    def set_setting(self,key,value):
        with self.lock,self.connection() as c:c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,json.dumps(value)))
    def update(self,id,values):
        with self.lock:
            row=self.get(id)
            if row:row.update(values);self.save(row)

class RepushError(RuntimeError):
    """A manual recovery must never silently fall back to playing from zero."""


class Publisher:
    """A single long-lived FLV/RTMP output across loops and compatible switches."""
    def __init__(self,path,url,status=None):
        self.path=path;self.url=url;self.report=status or (lambda v:None)
        self.stop=threading.Event();self.lock=threading.Lock();self.next=None
        self.repush_request=None;self.repush_count=0;self.repush_id=''
        self.position=0.;self.repush_position=0.;self.origin=0.;self.loops=0;self.packets=0;self.bytes=0
        self.command_error_id='';self.command_error=''
    def repush(self,request_id):
        if not isinstance(request_id,str) or not re.fullmatch(r'[a-f0-9]{16,64}',request_id):
            raise ValueError('重推请求标识无效')
        with self.lock:
            if self.next:raise ValueError('正在更换视频，请完成后再重推')
            if self.repush_request:raise ValueError('已在等待关键帧重推，请勿重复点击')
            self.repush_request=dict(id=request_id,position=self.position)
            self.command_error_id='';self.command_error=''
        self.progress('repush_pending')
    def reject_command(self,request_id,error):
        with self.lock:
            self.command_error_id=str(request_id)[:64]
            self.command_error=re.sub(r'rtmp://\S+','[RTMP]',str(error))[:500]
        self.progress('switch_error',error=self.command_error)
    def progress(self,state='running',**extra):
        with self.lock:
            request=dict(self.repush_request or {})
            position=self.position
            error_id=self.command_error_id;error=self.command_error
        self.report(dict(state=state,video=self.path,loops=self.loops,packets=self.packets,
            bytes=self.bytes,position=round(position,3),uptime=round(max(0.,time.monotonic()-self.origin),1),
            repush_count=self.repush_count,repush_id=self.repush_id,
            repush_position=round(self.repush_position,3),pending_repush_id=request.get('id',''),
            requested_position=request.get('position'),command_error_id=error_id,command_error=error,updated=time.time(),**extra))
    def switch(self,path):
        if codec_signature(path)[0]!=codec_signature(self.path)[0]:
            raise ValueError('文件编码参数不同，不能承诺不断流切换；请先统一编码参数')
        with self.lock:
            if self.repush_request:raise ValueError('正在续播重推，请完成后再更换视频')
            self.next=path
    def open_output(self,video,audio):
        output=av.open(self.url,'w',format='flv',options={'flvflags':'no_duration_filesize','flush_packets':'1'},timeout=(8,5))
        try:
            dest={'video':output.add_stream_from_template(video),'audio':output.add_stream_from_template(audio)}
            output.start_encoding();return output,dest
        except Exception:
            try:output.close()
            except Exception:pass
            raise
    def run(self):
        # Input stays open at the current demux cursor during manual repush.
        # Reopen ONLY the RTMP muxer, at the next independently decodable keyframe.
        self.origin=time.monotonic();segment_origin=self.origin;segment_base=Fraction(0)
        offset=Fraction(0);last_dts={};output=None
        with av.open(self.path) as template:
            vt=template.streams.video[0];at=template.streams.audio[0]
            try:
                output,dest=self.open_output(vt,at)
                while not self.stop.is_set():
                    first=None;end=offset;video_seen=False;last_report=0;switched=False
                    with av.open(self.path) as source:
                        material_start=Fraction(source.start_time or 0,av.time_base)
                        tracks=[source.streams.video[0],source.streams.audio[0]]
                        for packet in source.demux(tracks):
                            if self.stop.is_set():break
                            if not packet.size or packet.dts is None or packet.pts is None:continue
                            kind=packet.stream.type
                            if kind=='video':
                                if not video_seen and not packet.is_keyframe:raise ValueError('首个视频包非关键帧')
                                video_seen=True
                                with self.lock:pending=self.next
                                if pending and packet.is_keyframe and self.packets:
                                    switched=True;break
                            tb=packet.time_base
                            stamp=Fraction(packet.dts)*tb
                            if first is None:first=stamp
                            dts=stamp-first+offset;pts=Fraction(packet.pts)*tb-first+offset
                            if kind in last_dts and dts<=last_dts[kind]:raise ValueError('素材时间戳不递增，已停止，避免声音/画面损坏')
                            delay=float(dts-segment_base)-(time.monotonic()-segment_origin)
                            if delay>0 and self.stop.wait(delay):break
                            material_position=max(0.,float(Fraction(packet.pts)*tb-material_start))
                            if kind=='video':
                                with self.lock:self.position=material_position
                            request=None
                            if kind=='video' and packet.is_keyframe:
                                with self.lock:
                                    if self.repush_request and self.packets:
                                        request=dict(self.repush_request)
                            if request:
                                self.progress('repushing')
                                try:
                                    old=output;output=None;old.close()
                                    if self.stop.is_set():break
                                    # MediaMTX may need a brief moment to release the old publisher.
                                    for attempt in range(3):
                                        try:output,dest=self.open_output(vt,at);break
                                        except Exception:
                                            if attempt==2 or self.stop.wait(.2*(attempt+1)):raise
                                except Exception as error:
                                    raise RepushError('续播重推连接失败，已保留位置且禁止自动从头启动：'+str(error)) from error
                                segment_base=dts;segment_origin=time.monotonic()
                                self.repush_count+=1;self.repush_id=request['id'];self.repush_position=material_position
                                with self.lock:self.repush_request=None
                                last_report=0
                            wire_dts=dts-segment_base;wire_pts=pts-segment_base
                            # Discard audio preroll preceding this new keyframe, never
                            # remap old audio into the new segment or change only one track.
                            if self.repush_count and (wire_dts<0 or wire_pts<0):continue
                            duration=Fraction(packet.duration or 0)*tb
                            if duration<=0:duration=Fraction(1,30) if kind=='video' else Fraction(1024,at.codec_context.sample_rate)
                            end=max(end,dts+duration,pts+duration)
                            last_dts[kind]=dts
                            packet.dts=int(wire_dts/tb);packet.pts=int(wire_pts/tb);packet.stream=dest[kind]
                            self.bytes+=packet.size;output.mux(packet);self.packets+=1
                            now=time.monotonic()
                            if now-last_report>=1:
                                self.progress('repush_pending' if self.repush_request else 'running')
                                last_report=now
                    if self.stop.is_set():break
                    if not video_seen or end<=offset:raise ValueError('空素材或没有有效视频包')
                    offset=end;self.loops+=1
                    with self.lock:
                        if self.next:self.path=self.next;self.next=None
                    self.progress('repush_pending' if self.repush_request else 'running',switched=switched)
            finally:
                if output is not None:
                    try:output.close()
                    except Exception:
                        if not self.stop.is_set():raise

def worker(config):
    data=json.loads(Path(config).read_text(encoding='utf-8'));status=data['status']
    pub=Publisher(data['video'],data['url'],lambda s:atomic_json(status,s))
    def commands():
        seen=''
        while not pub.stop.wait(.15):
            c={}
            try:
                raw=Path(data['commands']).read_bytes()
                if len(raw)>8192:continue
                c=json.loads(raw)
                if not isinstance(c,dict):raise ValueError('命令格式无效')
                if c.get('id')==seen:continue
                seen=c.get('id','')
                if c['action']=='stop':pub.stop.set();return
                if c['action']=='switch':pub.switch(c['video'])
                if c['action']=='repush':pub.repush(c['request_id'])
            except (OSError,ValueError,KeyError,TypeError) as e:pub.reject_command(c.get('request_id','') if isinstance(c,dict) else '',e)
    threading.Thread(target=commands,daemon=True).start()
    try:pub.run();atomic_json(status,dict(state='stopped',updated=time.time()))
    except Exception as e:
        # Never log RTMP URLs or account/session tokens.
        atomic_json(status,dict(state='error',error=re.sub(r'rtmp://\S+','[RTMP]',str(e))[:500],
            position=pub.position,resume_required=isinstance(e,RepushError) or bool(pub.repush_request) or pub.repush_count>0,updated=time.time()))
        return 1
    return 0
