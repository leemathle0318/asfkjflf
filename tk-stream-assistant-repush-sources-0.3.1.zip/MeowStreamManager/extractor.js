JSON.stringify((() => {
  // Visible DOM only: no cookies, storage, private endpoints or request interception.
  if (location.hostname !== 'shop.tiktok.com' || !location.pathname.startsWith('/streamer'))
    return {state:'login',metrics:{},diagnostic:{reason:'outside_dashboard'}};
  const visible = e => e.getClientRects().length && getComputedStyle(e).visibility !== 'hidden' && getComputedStyle(e).display !== 'none';
  const normalize = t => t.replace(/\u00a0/g,' ').replace(/（/g,'(').replace(/）/g,')').replace(/\s+/g,' ').trim();
  const text = e => normalize(e.innerText || '');
  const patterns = {
    gmv:/^(?:归因\s*GMV|Attributed\s*GMV)(?:\s*\([^)]{1,15}\))?$/i,
    items:/^(?:归因成交件数|Attributed\s*(?:items sold|units sold))$/i,
    online:/^(?:(?:当前|实时)?在线人数|(?:Current\s*)?(?:concurrent|online)\s*viewers)$/i,
    views:/^(?:浏览人数|Viewers|Total viewers)$/i
  };
  const number = /^(?:(?:US\s*)?[$€£¥₫฿]|USD|GBP|EUR)?\s*\d[\d,]*(?:\.\d+)?\s*(?:[kKmMbB]|万|亿)?(?:\s*(?:USD|GBP|EUR))?$/;
  const elements = [...document.querySelectorAll('span,div,p,h1,h2,h3,h4,dt,dd,th,td,strong,b,label')].filter(visible);
  const metrics = {}, missing = [], ambiguous = [], matched = {};
  const allLabel = e => Object.values(patterns).some(p=>p.test(text(e)));
  function adjacentValue(label) {
    let node = label;
    for (let depth=0; depth<6 && node && node!==document.body; depth++,node=node.parentElement) {
      // Common card structure: title wrapper, numeric wrapper, then other metric pills.
      // Only a purely numeric adjacent branch is accepted, not an unrelated labelled card.
      if(node.parentElement && node.parentElement!==document.body) {
        const siblings=[...node.parentElement.children].filter(e=>e!==node&&visible(e)&&number.test(text(e)));
        const adjacent=[node.nextElementSibling,node.previousElementSibling].filter(e=>e&&visible(e)&&number.test(text(e)));
        if(siblings.length===1 && adjacent.length===1)return {display:text(adjacent[0]),label:text(label)};
        if(siblings.length>1)return null;
      }
      const children = [...node.querySelectorAll('span,div,p,h1,h2,h3,h4,dd,td,strong,b')].filter(visible);
      const otherLabels = children.filter(e=>e!==label && !e.contains(label) && !label.contains(e) && allLabel(e));
      const candidates = children.filter(e=>!e.contains(label) && !label.contains(e) && number.test(text(e)))
        .filter(e=>![...e.children].some(c=>visible(c)&&number.test(text(c))));
      if (!candidates.length) continue;
      // Don't steal values from other labelled cards or guess between several values.
      const clean = candidates.filter(c=>!otherLabels.some(l=>{
        let a=l.parentElement;
        for(let n=0;n<3&&a&&a!==node;n++,a=a.parentElement) if(a.contains(c)&&!a.contains(label))return true;
        return false;
      }));
      if (clean.length===1) return {display:text(clean[0]),label:text(label)};
      if (otherLabels.length || clean.length>1) return null;
    }
    return null;
  }
  for (const [key, pattern] of Object.entries(patterns)) {
    const labels=elements.filter(e=>text(e).length<65 && pattern.test(text(e)))
      .filter(e=>![...e.children].some(c=>visible(c)&&pattern.test(text(c))));
    matched[key]=labels.length;
    const values=labels.map(adjacentValue).filter(Boolean);
    const unique=[...new Set(values.map(v=>v.display))];
    if(unique.length===1)metrics[key]=values[0];
    else if(unique.length>1)ambiguous.push(key);
    else missing.push(key);
  }
  const body=(document.body?.innerText || '').slice(0,160000);
  let state='unknown';
  if(/账号永久受限|账号受限|账号已被封禁|account.*(?:restricted|suspended)/i.test(body))state='restricted';
  else if(metrics.online)state='live';
  else if(metrics.views && /直播回放|直播已结束|LIVE replay|LIVE ended/i.test(body))state='ended';
  else if(/扫码登录|登录TikTok|Log in to TikTok|Scan.*QR/i.test(body) && !metrics.gmv)state='login';
  const has_live_button=[...document.querySelectorAll('a,button,[role="button"]')].some(e=>visible(e)&&/^(直播大屏|LIVE dashboard)$/i.test(text(e)));
  const videos=[...document.querySelectorAll('video')].filter(visible).map(v=>({ready:v.readyState,paused:v.paused,width:v.videoWidth,height:v.videoHeight,error:v.error?.code||0,muted:v.muted}));
  return {state,metrics,has_live_button,diagnostic:{reason:Object.keys(metrics).length?'read':'labels_not_matched',missing,ambiguous,matched,videos,
    h264:document.createElement('video').canPlayType('video/mp4; codecs="avc1.42E01E"'),aac:document.createElement('audio').canPlayType('audio/mp4; codecs="mp4a.40.2"')}};
})())
