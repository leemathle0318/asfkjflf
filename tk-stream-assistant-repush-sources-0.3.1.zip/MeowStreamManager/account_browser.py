"""Dedicated visible Edge profiles. Only authorized, visible dashboard DOM is read."""
import json
import queue
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit

BASE = 'https://shop.tiktok.com/streamer/live/product/dashboard'
CLICK_DASHBOARD = """() => { const e=[...document.querySelectorAll('a,button,[role="button"]')].find(e=>
 e.getClientRects().length && /^(直播大屏|LIVE dashboard)$/i.test(e.innerText.replace(/\\s+/g,' ').trim()));
 if(e){e.click();return true;}return false; }"""

def allowed(url):
    value=urlsplit(url)
    return value.scheme=='https' and value.hostname=='shop.tiktok.com' and value.path.startswith('/streamer')

def select_snapshot(results):
    """Don't let an empty workbench overwrite a populated dashboard in this poll."""
    values=[r for r in results if isinstance(r,dict)]
    if not values:return {'state':'unknown','metrics':{},'diagnostic':{'reason':'no_dashboard_page'}}
    def score(r):
        m=r.get('metrics',{})
        return (r.get('state')=='live', bool(m.get('online')), len(m), r.get('state')=='ended')
    return max(values,key=score)

def browser_check(destination):
    """Optional local codec/driver check. No account, network or default profile."""
    import tempfile
    from playwright.sync_api import sync_playwright
    path=Path(destination)
    path.parent.mkdir(parents=True,exist_ok=True)
    try:
        with sync_playwright() as p,tempfile.TemporaryDirectory(prefix='meow-edge-check-',dir=path.parent) as root:
            context=p.chromium.launch_persistent_context(root,channel='msedge',headless=True)
            try:
                page=context.pages[0];page.set_content('<html><body>Local codec check</body></html>')
                result=page.evaluate('''() => ({h264:document.createElement('video').canPlayType('video/mp4; codecs="avc1.42E01E"'),aac:document.createElement('audio').canPlayType('audio/mp4; codecs="mp4a.40.2"')})''')
                result['ok']=bool(result['h264'] and result['aac'])
            finally:context.close()
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        return 0 if result['ok'] else 1
    except Exception as error:
        path.write_text(json.dumps({'ok':False,'category':type(error).__name__}),encoding='utf-8')
        return 1

class BrowserWorker(threading.Thread):
    def __init__(self,root,channel,script,deliver):
        super().__init__(name=f'account-{int(channel)}',daemon=True)
        self.profile=Path(root)/'accounts-edge'/f'channel-{int(channel)}'
        self.script=script;self.deliver=deliver;self.commands=queue.Queue();self.context=None
        self.stopping=threading.Event();self.last_page=None
    def submit(self,command):self.commands.put(command)
    def stop(self):self.stopping.set();self.commands.put('stop')
    def notify(self,text):self.deliver({'message':text})
    def opened(self,page):self.last_page=page
    def start_context(self,playwright):
        self.profile.mkdir(parents=True,exist_ok=True)
        # Never use the person's default profile or copy its credentials.
        self.context=playwright.chromium.launch_persistent_context(str(self.profile),channel='msedge',
            headless=False,no_viewport=True,accept_downloads=False,timeout=15000)
        self.context.on('page',self.opened)
        self.context.set_default_timeout(5000);self.context.set_default_navigation_timeout(10000)
        self.last_page=self.context.pages[0] if self.context.pages else self.context.new_page()
    def pages(self):return [p for p in self.context.pages if not p.is_closed()]
    def workbench(self):
        pages=self.pages()
        page=next((p for p in pages if p.url==BASE),None) or self.context.new_page()
        page.bring_to_front()
        if page.url!=BASE:page.goto(BASE,wait_until='domcontentloaded')
        self.last_page=page
    def dashboard(self):
        pages=self.pages()
        for page in reversed(pages):
            if not allowed(page.url):continue
            try:
                result=json.loads(page.evaluate(self.script))
                if result.get('state')=='live' and result.get('metrics'):
                    page.bring_to_front();self.last_page=page
                    self.notify('已打开该通道官方大屏，请手动点击播放器播放并开启声音。');return
            except Exception:continue
        for page in reversed(pages):
            if not allowed(page.url):continue
            try:
                if page.evaluate(CLICK_DASHBOARD):
                    page.bring_to_front();self.last_page=page
                    self.notify('已点击官方直播大屏入口，请手动点击播放器播放／开启声音。');return
            except Exception:continue
        self.workbench()
        self.notify('当前未找到官方“直播大屏”按钮，请在 Edge 内完成扫码登录并进入直播控制台，再点直播大屏。')
    def read(self):
        results=[]
        selected=None
        for page in self.pages():
            if not allowed(page.url):continue
            try:
                result=json.loads(page.evaluate(self.script))
                if isinstance(result,dict):
                    results.append(result)
                    if page==self.last_page and result.get('metrics'):selected=result
            except Exception:continue
        # The page opened by this channel's last dashboard command has priority;
        # do not merge fields from historical and current sessions.
        self.deliver({'snapshot':selected or select_snapshot(results)})
    def run(self):
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as playwright:
                next_poll=0.
                while not self.stopping.is_set():
                    try:command=self.commands.get(timeout=.1)
                    except queue.Empty:command=None
                    if command=='stop':break
                    try:
                        if command:
                            if not self.context or not self.pages():
                                if self.context:
                                    try:self.context.close()
                                    except Exception:pass
                                self.context=None;self.start_context(playwright);self.workbench()
                            if command=='home':self.workbench()
                            elif command=='dashboard':self.dashboard()
                            elif command=='reload':
                                page=self.last_page
                                if page and not page.is_closed():page.reload(wait_until='domcontentloaded')
                            next_poll=0.
                        if self.context and self.pages():
                            self.pages()[0].wait_for_timeout(80)
                            if time.monotonic()>=next_poll:self.read();next_poll=time.monotonic()+15
                    except Exception as error:
                        # Exception messages can contain tokens: publish category only.
                        self.notify('账号浏览器操作未完成（'+type(error).__name__+'）。请检查 Edge、网络或扫码页面；可再次点击打开。')
                        if self.context:
                            try:
                                if not self.pages():self.context=None
                            except Exception:self.context=None
                if self.context:
                    try:self.context.close()
                    except Exception:pass
        except Exception as error:
            self.notify('无法启动独立 Edge 账号窗口（'+type(error).__name__+'）。请完整解压新版软件并确认已安装 Microsoft Edge。')
