import sys,tempfile,time,unittest,json,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import Store,bandwidth,compatible,atomic_json
from controller import Manager,PairServer
import urllib.request,urllib.error

class Core(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name);self.manager=Manager(self.store);self.manager.ip='127.0.0.1'
    def tearDown(self):self.manager.close();self.tmp.cleanup()
    def test_ids_not_reused(self):
        a=self.store.create();self.store.remove(a['id']);b=self.store.create();self.assertGreater(b['id'],a['id'])
        self.assertNotEqual(a['stream_path'],b['stream_path'])
    def test_persistence(self):
        r=self.store.create();self.store.update(r['id'],dict(remark='中文备注',video='a.mp4'))
        other=Store(self.tmp.name);self.assertEqual(other.get(r['id'])['remark'],'中文备注')
    def test_atomic_unicode(self):
        p=Path(self.tmp.name)/'status.json';atomic_json(p,dict(a='手机'));self.assertEqual(json.loads(p.read_text(encoding='utf-8'))['a'],'手机')
    def test_bandwidth(self):
        r=dict(metadata=dict(bitrate=5128000,peak_sample=6000000),enabled=True)
        v=bandwidth([r]*5,100,20,.5);self.assertEqual(v['budget'],40);self.assertAlmostEqual(v['used'],34.5);self.assertGreater(v['remaining'],0)
        self.assertEqual(bandwidth([],10,20,.5)['budget'],0)
    def test_compatibility(self):
        self.assertTrue(compatible(dict(signature='x'),dict(signature='x')));self.assertFalse(compatible({},{}))
    def ticket(self,row,token='ticket'):self.manager.tickets[token]=(row['id'],time.time()+120);return token
    def test_pair_once(self):
        r=self.store.create();p=self.manager.claim(self.ticket(r),'device-A');self.assertIn('rtmp://',p['rtmp'])
        with self.assertRaises(ValueError):self.manager.claim('ticket','device-A')
    def test_expired_and_other_device(self):
        r=self.store.create();self.manager.tickets['old']=(r['id'],0)
        with self.assertRaises(ValueError):self.manager.claim('old','device-A')
        self.manager.claim(self.ticket(r),'device-A')
        with self.assertRaises(ValueError):self.manager.claim(self.ticket(r),'device-B')
    def test_one_device_one_channel(self):
        a=self.store.create();b=self.store.create();self.manager.claim(self.ticket(a),'device-A')
        with self.assertRaises(ValueError):self.manager.claim(self.ticket(b),'device-A')
    def test_heartbeat_authorization(self):
        r=self.store.create();p=self.manager.claim(self.ticket(r),'device-A');data=dict(channel_id=r['id'],device='device-A',key=p['heartbeat_key'],receiving=True,bytes=123,videos=12)
        self.assertFalse(self.manager.is_online(self.store.get(r['id'])))
        self.manager.heartbeat(data);self.assertTrue(self.store.get(r['id'])['receiving'])
        self.assertTrue(self.manager.is_online(self.store.get(r['id'])))
        with self.assertRaises(ValueError):self.manager.heartbeat(dict(data,key='wrong'))
        self.store.update(r['id'],dict(device='',heartbeat_key=''))
        with self.assertRaises(ValueError):self.manager.heartbeat(data)
    def test_real_http(self):
        r=self.store.create();self.ticket(r);server=PairServer(('127.0.0.1',0),self.manager)
        t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
        try:
            url=f'http://127.0.0.1:{server.server_port}/pair'
            req=urllib.request.Request(url,json.dumps(dict(token='ticket',device='phone')).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req,timeout=3) as response:self.assertIn('heartbeat_key',json.load(response))
            with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(req,timeout=3)
        finally:server.shutdown();server.server_close();t.join(2)
if __name__=='__main__':unittest.main()
