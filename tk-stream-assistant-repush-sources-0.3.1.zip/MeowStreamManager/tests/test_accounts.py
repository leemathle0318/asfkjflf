import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from account_browser import allowed,select_snapshot,BrowserWorker

class Accounts(unittest.TestCase):
    def test_official_host_only(self):
        self.assertTrue(allowed('https://shop.tiktok.com/streamer/live/product/dashboard'))
        for url in ['https://shop.tiktok.com.evil.test/streamer','http://shop.tiktok.com/streamer','https://elsewhere.test/streamer','file:///streamer','https://shop.tiktok.com/login']:
            self.assertFalse(allowed(url),url)
    def test_empty_workbench_cannot_overwrite_live(self):
        live={'state':'live','metrics':{'online':{'display':'5'},'gmv':{'display':'96'}}}
        blank={'state':'unknown','metrics':{}}
        self.assertEqual(select_snapshot([live,blank]),live)
        self.assertEqual(select_snapshot([blank,live]),live)
    def test_live_prioritized_over_past(self):
        live={'state':'live','metrics':{'online':{'display':'2'}}}
        ended={'state':'ended','metrics':{'gmv':{},'views':{},'items':{}}}
        self.assertEqual(select_snapshot([ended,live]),live)
    def test_no_pages_not_cached_success(self):
        self.assertEqual(select_snapshot([])['metrics'],{})
        self.assertEqual(select_snapshot([])['state'],'unknown')
    def test_profiles_are_dedicated_and_distinct(self):
        a=BrowserWorker('test-root',1,'',lambda _:None);b=BrowserWorker('test-root',2,'',lambda _:None)
        self.assertNotEqual(a.profile,b.profile)
        self.assertEqual(a.profile,Path('test-root/accounts-edge/channel-1'))

if __name__=='__main__':unittest.main()
