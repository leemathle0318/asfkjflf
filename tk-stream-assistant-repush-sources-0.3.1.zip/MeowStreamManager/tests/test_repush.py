"""Real packet-copy files with modeled pacing; not an iPhone/live audience test."""
import array,hashlib,json,math,sys,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from fractions import Fraction
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import av
import engine
from engine import Publisher,RepushError,Store,atomic_json
from controller import Manager

def make_media(path,rate=48000,seconds=8):
    with av.open(str(path),'w') as container:
        video=container.add_stream('libx264',rate=30);video.width=160;video.height=96;video.pix_fmt='yuv420p'
        video.options={'g':'60','keyint_min':'60','sc_threshold':'0','bf':'2','preset':'fast'}
        audio=container.add_stream('aac',rate=rate);audio.layout='stereo';audio.bit_rate=192000
        vi=ai=0
        while vi<30*seconds or ai<rate*seconds:
            if vi<30*seconds and (ai>=rate*seconds or Fraction(vi,30)<=Fraction(ai,rate)):
                frame=av.VideoFrame(160,96,'yuv420p')
                frame.planes[0].update(bytes([20+min(vi//2,200)])*frame.planes[0].buffer_size)
                for plane in frame.planes[1:]:plane.update(bytes([128])*plane.buffer_size)
                frame.pts=vi;frame.time_base=Fraction(1,30);vi+=1
                for packet in video.encode(frame):container.mux(packet)
            else:
                n=min(1024,rate*seconds-ai);frame=av.AudioFrame(format='fltp',layout='stereo',samples=n)
                samples=array.array('f',(.1*math.sin(2*math.pi*(440*(ai+i)/rate+10*((ai+i)/rate)**2)) for i in range(n)))
                for plane in frame.planes:plane.update(samples.tobytes())
                frame.sample_rate=rate;frame.pts=ai;frame.time_base=Fraction(1,rate);ai+=n
                for packet in audio.encode(frame):container.mux(packet)
        for stream in (video,audio):
            for packet in stream.encode(None):container.mux(packet)

class Clock:
    def __init__(self):self.now=1000.
    def monotonic(self):return self.now
    def time(self):return self.now
class FastStop:
    def __init__(self,clock):self.clock=clock;self.stopped=False
    def is_set(self):return self.stopped
    def set(self):self.stopped=True
    def wait(self,delay):self.clock.now+=max(0,delay);return self.stopped

class RepushTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.root=Path(cls.temp.name)
        cls.media=cls.root/'source.mp4';make_media(cls.media)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def run_publisher(self,fail=False,two=False):
        clock=Clock();states=[];requests=[];paths=[]
        class FilePublisher(Publisher):
            def open_output(self,video,audio):
                if fail and paths:raise OSError('local injected reconnect failure')
                p=self_folder/f'{len(paths)}.flv';paths.append(p)
                output=av.open(str(p),'w',format='flv');dest={k:output.add_stream_from_template(s) for k,s in [('video',video),('audio',audio)]}
                output.start_encoding();return output,dest
        self_folder=self.root/str(time.time_ns());self_folder.mkdir()
        def report(state):
            states.append(state)
            target=2.1 if not requests else 4.1
            if state['state']=='running' and state['position']>=target and len(requests)<(2 if two else 1):
                requests.append(state['position']);pub.repush(('%032x'%len(requests)))
            if state['position']>=7.1:pub.stop.set()
        pub=FilePublisher(str(self.media),'unused',report);pub.stop=FastStop(clock)
        with patch.object(engine,'time',clock):
            if fail:
                with self.assertRaises(RepushError):pub.run()
            else:pub.run()
        return pub,states,requests,paths
    def test_real_repush_preserves_encoded_packets_and_position(self):
        pub,states,requests,paths=self.run_publisher()
        self.assertEqual(pub.repush_count,1);self.assertEqual(len(paths),2)
        self.assertGreaterEqual(pub.repush_position,requests[0]);self.assertLess(pub.repush_position-requests[0],2.1)
        source={}
        with av.open(str(self.media)) as c:
            for p in c.demux():
                if p.size and p.pts is not None:source[hashlib.sha256(bytes(p)).digest()]=(p.stream.type,float(p.pts*p.time_base))
        with av.open(str(paths[1])) as c:
            first={};last={}
            for p in c.demux():
                if not p.size or p.dts is None:continue
                kind=p.stream.type;stamp=float(p.dts*p.time_base)
                self.assertGreater(stamp,last.get(kind,-1));last[kind]=stamp
                if kind not in first:
                    self.assertIn(hashlib.sha256(bytes(p)).digest(),source)
                    origin=source[hashlib.sha256(bytes(p)).digest()][1]
                    self.assertGreaterEqual(origin,pub.repush_position-.1)
                    first[kind]=(stamp,origin)
                    if kind=='video':self.assertTrue(p.is_keyframe)
            self.assertEqual(set(first),{'video','audio'})
            self.assertLess(abs(first['video'][1]-first['audio'][1]),.12)
            self.assertLess(first['video'][0],.1);self.assertLess(first['audio'][0],.12)
        with av.open(str(paths[1])) as c:
            first=next(c.decode(video=0));self.assertGreater(first.to_image().getpixel((0,0))[0],60)
    def test_two_repushes_do_not_rewind_or_increment_loop_counter(self):
        pub,states,requests,paths=self.run_publisher(two=True)
        self.assertEqual(pub.repush_count,2);self.assertEqual(len(paths),3);self.assertEqual(pub.loops,0)
        self.assertGreater(pub.repush_position,requests[-1]-.1)
        positions=[s['position'] for s in states];self.assertEqual(positions,sorted(positions))
    def test_failed_reconnect_retains_material_position_and_does_not_reopen_source(self):
        pub,states,requests,paths=self.run_publisher(fail=True)
        self.assertGreaterEqual(pub.position,requests[0]);self.assertEqual(pub.repush_count,0);self.assertEqual(pub.loops,0)
    def test_duplicate_and_invalid_commands_are_rejected(self):
        pub=Publisher(str(self.media),'unused')
        for invalid in ('','abc','x'*32,None):
            with self.assertRaises(ValueError):pub.repush(invalid)
        pub.repush('a'*32)
        with self.assertRaises(ValueError):pub.repush('b'*32)
        with self.assertRaises(ValueError):pub.switch(str(self.media))
    def test_rejected_request_is_durable_and_manager_can_retry(self):
        states=[];pub=Publisher(str(self.media),'unused',states.append)
        pub.reject_command('a'*32,ValueError('正在换片'))
        pub.progress();self.assertEqual(states[-1]['command_error_id'],'a'*32)
        pub.repush('b'*32);self.assertEqual(states[-1]['command_error_id'],'')
        with tempfile.TemporaryDirectory() as folder:
            store=Store(folder);row=store.create();m=Manager(store)
            m.processes[row['id']]=SimpleNamespace(poll=lambda:None,stdin=None)
            m.pending_repush[row['id']]='a'*32
            atomic_json(m.status_path(row['id']),dict(state='running',position=123.,command_error_id='a'*32,updated=time.time()))
            try:
                m.tick();self.assertNotIn(row['id'],m.pending_repush)
                m.repush(row['id']);self.assertIn(row['id'],m.pending_repush)
            finally:m.processes.clear();m.close()
    def test_manager_command_ack_and_failure_never_auto_start_zero(self):
        with tempfile.TemporaryDirectory() as folder:
            store=Store(folder);r=store.create();store.update(r['id'],dict(video=str(self.media),metadata={'ok':True},desired_state='running'))
            m=Manager(store);process=SimpleNamespace(poll=lambda:None,stdin=None);m.processes[r['id']]=process
            atomic_json(m.status_path(r['id']),dict(state='running',position=3600.,updated=time.time()))
            try:
                m.repush(r['id']);request=m.pending_repush[r['id']]
                command=json.loads((store.root/'workers'/f"{r['id']}.command.json").read_text())
                self.assertEqual(command['action'],'repush');self.assertEqual(command['request_id'],request)
                with self.assertRaises(ValueError):m.repush(r['id'])
                atomic_json(m.status_path(r['id']),dict(state='running',position=3602.,repush_position=3601.,repush_id=request,updated=time.time()))
                m.tick();self.assertNotIn(r['id'],m.pending_repush)
                process.poll=lambda:1
                atomic_json(m.status_path(r['id']),dict(state='error',position=3602.,resume_required=True,updated=time.time()))
                m.tick();self.assertNotIn(r['id'],m.retries);self.assertEqual(store.get(r['id'])['desired_state'],'stopped')
            finally:m.processes.clear();m.close()

if __name__=='__main__':unittest.main(verbosity=2)
