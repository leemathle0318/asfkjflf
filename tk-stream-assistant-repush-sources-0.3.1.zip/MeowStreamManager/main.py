import os,sys
from pathlib import Path
if '--worker' in sys.argv:
    from engine import worker
    raise SystemExit(worker(sys.argv[sys.argv.index('--worker')+1]))
if '--edge-check' in sys.argv:
    from account_browser import browser_check
    raise SystemExit(browser_check(sys.argv[sys.argv.index('--edge-check')+1]))
import csv,io,json,re,shutil,time,traceback,uuid
from concurrent.futures import ThreadPoolExecutor
import psutil,qrcode
from PySide6.QtCore import Qt,QAbstractTableModel,QModelIndex,QTimer,Signal,QObject
from PySide6.QtGui import QColor,QFont,QImage,QPixmap
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QSplitter,
    QTableView,QHeaderView,QLineEdit,QPushButton,QLabel,QPlainTextEdit,QDialog,QFileDialog,QMessageBox,
    QInputDialog,QComboBox,QFormLayout,QDoubleSpinBox,QDialogButtonBox,QCheckBox)
from engine import Store,probe,compatible,bandwidth,runtime_root,VERSION
from controller import Manager

class Jobs(QObject):
    result=Signal(object,object)
    def __init__(self,parent=None):super().__init__(parent);self.pool=ThreadPoolExecutor(max_workers=2)
    def submit(self,fn,done):
        f=self.pool.submit(fn)
        def finish(f):
            try:value=f.result();self.result.emit(done,(True,value))
            except Exception as e:self.result.emit(done,(False,str(e)))
        f.add_done_callback(finish)

class Channels(QAbstractTableModel):
    headers=['编号 / 标签','手机备注','视频文件','规格 / 码率','手机状态','推流状态','TikTok账号','归因GMV','归因成交件数','在线 / 浏览人数','绑定账号','直播大屏']
    def __init__(self,manager):super().__init__();self.manager=manager;self.rows=[]
    def rowCount(self,parent=QModelIndex()):return 0 if parent.isValid() else len(self.rows)
    def columnCount(self,parent=QModelIndex()):return len(self.headers)
    def headerData(self,s,o,role=Qt.ItemDataRole.DisplayRole):
        return self.headers[s] if role==Qt.ItemDataRole.DisplayRole and o==Qt.Orientation.Horizontal else None
    def data(self,index,role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():return None
        r=self.rows[index.row()];c=index.column();m=r.get('metadata',{});s=self.manager.status(r['id']);metrics=r.get('metrics',{})
        fresh=r.get('metrics_updated',0)>=self.manager.started and time.time()-r.get('metrics_updated',0)<45
        def metric(k):return metrics.get(k,{}).get('display','—') if fresh else '—'
        paired=bool(r.get('device'));online=self.manager.is_online(r)
        phone='接收中' if online and r.get('receiving') else '在线 / 未接收' if online else '已绑定 / 离线' if paired else '未绑定'
        states=dict(running='推流中',starting='启动中',stopped='已停止',error='失败',stale='状态过期',switch_error='命令失败',repush_pending='等待关键帧重推',repushing='续播重推中')
        state=states.get(s.get('state'),'已停止') if r['id'] in self.manager.processes else '等待重试' if r['id'] in self.manager.retries else '已停止'
        account=r.get('account_alias') or '未设置备注'
        if r.get('account_state')=='login':account+=' · 需登录'
        money=metric('gmv');label=metrics.get('gmv',{}).get('label','');currency=re.search(r'\(([^)]+)\)',label)
        if money!='—':money=(currency.group(1)+' '+money) if currency else money+'（币种待确认）'
        vals=[f"{r['id']:04d}"+(' / '+r['label'] if r.get('label') else ''),r.get('remark',''),Path(s.get('video') or r.get('video','')).name,
            f"{m.get('width','—')}×{m.get('height','—')} / {m.get('bitrate',0)/1e6:.2f}M" if m else '未选视频',
            phone,state,account,money,metric('items'),
            ('在线 '+metric('online') if metrics.get('online') and r.get('account_state')=='live' else '浏览 '+metric('views') if r.get('account_state')=='ended' else '—'),'[官方扫码]','[打开大屏]']
        if role==Qt.ItemDataRole.DisplayRole:return vals[c]
        if role==Qt.ItemDataRole.ToolTipRole:
            return s.get('error','') or ('数据更新时间：'+time.strftime('%H:%M:%S',time.localtime(r['metrics_updated'])) if c>=7 and r.get('metrics_updated') else vals[c])
        if role==Qt.ItemDataRole.ForegroundRole and c in (4,5):
            return QColor('#16a085' if (c==4 and online) or (c==5 and s.get('state')=='running') else '#64748b')
    def refresh(self,rows):
        if [r['id'] for r in rows]==[r['id'] for r in self.rows]:
            self.rows=rows
            if rows:self.dataChanged.emit(self.index(0,0),self.index(len(rows)-1,len(self.headers)-1))
        else:self.beginResetModel();self.rows=rows;self.endResetModel()

class Window(QMainWindow):
    def __init__(self,root=None):
        super().__init__();self.store=Store(root);self.manager=Manager(self.store);self.accounts={};self.jobs=Jobs(self)
        self.jobs.result.connect(lambda fn,result:fn(*result));self.qr_dialogs=[]
        self.setWindowTitle('Meow Stream Manager · RTMP 多手机管理 '+VERSION);self.resize(1560,930)
        rootwidget=QWidget();self.setCentralWidget(rootwidget);root=QVBoxLayout(rootwidget);root.setContentsMargins(24,20,24,16);root.setSpacing(14)
        top=QHBoxLayout();root.addLayout(top);title=QLabel('Meow Stream Manager');title.setFont(QFont('Microsoft YaHei UI',22,QFont.Weight.Bold));top.addWidget(title)
        top.addStretch();self.ip=QLineEdit(self.manager.ip);self.ip.setMaximumWidth(170);top.addWidget(QLabel('电脑局域网 IPv4'));top.addWidget(self.ip)
        b=QPushButton('保存IP');b.clicked.connect(self.save_ip);top.addWidget(b)
        self.overview=QLabel();root.addWidget(self.overview)
        toolbar=QHBoxLayout();root.addLayout(toolbar)
        actions=[('新增通道',self.add),('批量创建',self.batch),('批量导入MP4',self.import_videos),('全部启动',self.start_all),('全部停止',self.stop_all),('带宽预算',self.budget),('配置 / 导出',self.export_menu)]
        for title,fn in actions:b=QPushButton(title);b.clicked.connect(fn);toolbar.addWidget(b)
        toolbar.addStretch();self.search=QLineEdit();self.search.setPlaceholderText('搜索编号、手机备注、账号、视频');self.search.textChanged.connect(self.refresh);toolbar.addWidget(self.search)
        self.filter=QComboBox();self.filter.addItems(['全部','推流中','已停止','手机在线','未绑定','已禁用']);self.filter.currentTextChanged.connect(self.refresh);toolbar.addWidget(self.filter)
        split=QSplitter();root.addWidget(split,1)
        self.model=Channels(self.manager);self.table=QTableView();self.table.setModel(self.model);self.table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableView.SelectionMode.ExtendedSelection);self.table.setAlternatingRowColors(True);self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive);self.table.setSortingEnabled(False)
        for i,width in enumerate([100,135,170,155,140,100,145,95,100,150]):self.table.setColumnWidth(i,width)
        self.table.selectionModel().selectionChanged.connect(self.details);self.table.doubleClicked.connect(lambda _:self.edit());split.addWidget(self.table)
        self.table.clicked.connect(self.row_action)
        self.sort_column=0;self.sort_reverse=False;self.table.horizontalHeader().sectionClicked.connect(self.sort_rows)
        panel=QWidget();side=QVBoxLayout(panel);self.detail=QPlainTextEdit();self.detail.setReadOnly(True);side.addWidget(self.detail,1)
        playback=QHBoxLayout();side.addLayout(playback)
        for title,fn in [('启动',self.start_selected),('续播重推',self.repush_selected),('停止',self.stop_selected)]:
            b=QPushButton(title);b.clicked.connect(fn);playback.addWidget(b)
            if title=='续播重推':b.setToolTip('保持当前素材进度，在下一关键帧重建RTMP连接；会短暂中断，不从视频开头播放。')
        for title,fn in [('选择 / 更换视频',self.choose),
            ('视频通道配对二维码',self.qr),('复制RTMP地址',self.copy_url),('绑定TikTok账号（官方扫码）',self.account),
            ('打开该账号直播大屏',self.dashboard),('编辑标签 / 备注',self.edit),('启用 / 禁用',self.toggle),
            ('复制通道',self.duplicate),('解绑手机',self.unpair),('删除所选通道',self.remove)]:
            b=QPushButton(title);b.clicked.connect(fn);side.addWidget(b)
        split.addWidget(panel);split.setSizes([1130,360])
        self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(120);root.addWidget(self.log)
        self.health=QLabel();root.addWidget(self.health)
        self.timer=QTimer(self);self.timer.setInterval(1000);self.timer.timeout.connect(self.tick);self.timer.start()
        self.refresh();self.last_log='';self.net=psutil.net_io_counters();self.last_net=time.monotonic()
        QApplication.instance().setStyleSheet('''QMainWindow,QDialog{background:#f5f7fa;} QLabel{color:#152b42;} QTableView,QPlainTextEdit,QLineEdit,QComboBox{background:white;border:1px solid #dce3eb;border-radius:5px;padding:5px;} QPushButton{background:white;border:1px solid #cbd5e1;border-radius:5px;padding:8px 12px;color:#173d59;} QPushButton:hover{background:#e7f3f2;border-color:#1f9e98;} QHeaderView::section{background:#edf2f6;border:0;padding:10px;font-weight:bold;} QTableView::item{padding:7px;}''')
    def error(self,e):QMessageBox.warning(self,'操作未完成',str(e))
    def selected(self):return [self.model.rows[i.row()]['id'] for i in self.table.selectionModel().selectedRows()]
    def one(self):
        ids=self.selected()
        if len(ids)!=1:raise ValueError('请选中一行通道')
        return self.store.get(ids[0])
    def safe(self,fn):
        try:return fn()
        except Exception as e:self.error(e)
    def refresh(self,*args):
        ids=self.selected() if hasattr(self,'table') else [];q=self.search.text().strip().lower();kind=self.filter.currentText();rows=self.store.rows()
        def match(r):
            if q and q not in ' '.join(str(r.get(k,'')) for k in ['id','label','remark','account_alias','video']).lower():return False
            running=r['id'] in self.manager.processes;online=self.manager.is_online(r)
            return kind=='全部' or kind=='推流中' and running or kind=='已停止' and not running or kind=='手机在线' and online or kind=='未绑定' and not r.get('device') or kind=='已禁用' and not r.get('enabled',True)
        fields=['id','remark','video','id','heartbeat','desired_state','account_alias','id','id','id','id','id']
        rows=sorted(rows,key=lambda r: r['id'] if fields[self.sort_column]=='id' else str(r.get(fields[self.sort_column],'')),reverse=self.sort_reverse)
        self.model.refresh([r for r in rows if match(r)])
        live=sum(r['id'] in self.manager.processes for r in rows);online=sum(self.manager.is_online(r) for r in rows)
        server='运行中' if self.manager.server and self.manager.server.poll() is None else '未启动'
        self.overview.setText(f'RTMP服务器：{server}     通道 {len(rows)}     推流 {live}     绑定 {sum(bool(r.get("device")) for r in rows)}     手机在线 {online}     登录与视频配对相互独立')
    def tick(self):
        self.manager.tick();self.refresh();now=time.monotonic();net=psutil.net_io_counters();speed=(net.bytes_sent-self.net.bytes_sent)*8/1e6/max(.01,now-self.last_net)
        self.net=net;self.last_net=now
        self.health.setText(f'电脑整体 CPU {psutil.cpu_percent():.0f}%   内存 {psutil.virtual_memory().percent:.0f}%   网卡发送 {speed:.2f} Mbps   本软件不进行视频实时重编码；每个已打开的账号网页都会占用浏览器资源')
        text='\n'.join(self.manager.events)
        if text!=self.last_log:self.log.setPlainText(text);self.last_log=text;self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())
        if self.selected():self.details()
    def add(self):self.store.create();self.refresh()
    def row_action(self,index):
        if index.column() not in (10,11):return
        self.table.selectRow(index.row())
        if index.column()==10:self.account()
        else:self.dashboard()
    def sort_rows(self,column):
        if self.sort_column==column:self.sort_reverse=not self.sort_reverse
        else:self.sort_column=column;self.sort_reverse=False
        self.refresh()
    def batch(self):
        n,ok=QInputDialog.getInt(self,'批量创建','本次新增通道数',5,1,1000)
        if ok:
            for _ in range(n):self.store.create()
            self.refresh()
    def edit(self):self.safe(self._edit)
    def _edit(self):
        r=self.one();d=QDialog(self);d.setWindowTitle('手机标识与备注');layout=QFormLayout(d)
        label=QLineEdit(r.get('label',''));remark=QLineEdit(r.get('remark',''));account=QLineEdit(r.get('account_alias',''))
        layout.addRow('物理标签，例如 A01',label);layout.addRow('手机备注',remark);layout.addRow('TikTok账号备注',account)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);layout.addRow(buttons);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject)
        if d.exec():self.store.update(r['id'],dict(label=label.text().strip(),remark=remark.text().strip(),account_alias=account.text().strip()));self.refresh()
    def choose(self):self.safe(self._choose)
    def _choose(self):
        r=self.one();path,_=QFileDialog.getOpenFileName(self,'选择 MP4','','视频 (*.mp4)')
        if path:self.load_video(r,path)
    def load_video(self,r,path):
        self.manager.log(f'通道 {r["id"]} 正在检查素材')
        def done(ok,value):
            if not ok:self.error(value);return
            old=self.store.get(r['id'])
            if not old:return
            try:
                if r['id'] in self.manager.processes:
                    if not compatible(old['metadata'],value):raise ValueError('新素材参数不兼容不断流切换；请先统一编码配置，或明确停止本通道后换片。其他通道不受影响。')
                    self.manager.switch(r['id'],path)
                self.store.update(r['id'],dict(video=path,metadata=value));self.manager.log(f'通道 {r["id"]} 素材已检查；运行中会在关键帧边界切换')
                if value['warnings']:self.error('\n'.join(value['warnings']))
                self.refresh()
            except Exception as e:self.error(e)
        self.jobs.submit(lambda:probe(path),done)
    def import_videos(self):
        paths,_=QFileDialog.getOpenFileNames(self,'批量导入：每个文件建立一个独立通道','','视频 (*.mp4)')
        for path in paths:self.load_video(self.store.create(),path)
        self.refresh()
    def start_selected(self):
        for id in self.selected():self.safe(lambda id=id:self.manager.start(id))
        self.refresh()
    def stop_selected(self):
        for id in self.selected():self.safe(lambda id=id:self.manager.stop(id))
        self.refresh()
    def repush_selected(self):
        ids=self.selected()
        if not ids:self.error('请先选中需要恢复的通道');return
        for id in ids:self.safe(lambda id=id:self.manager.repush(id))
        self.refresh()
    def start_all(self):
        for row in self.store.rows():
            if row.get('enabled',True) and row.get('video'):self.safe(lambda r=row:self.manager.start(r['id']))
    def stop_all(self):
        for id in list(self.manager.processes):self.safe(lambda id=id:self.manager.stop(id))
    def qr(self):self.safe(self._qr)
    def _qr(self):
        r=self.one();url=self.manager.ticket(r['id']);image=qrcode.make(url);buf=io.BytesIO();image.save(buf,format='PNG');data=buf.getvalue()
        d=QDialog(self);d.resize(460,560);d.setWindowTitle(f'手机视频通道配对 · {r["id"]}');root=QVBoxLayout(d)
        label=QLabel('有效期120秒，只能用一次。用 RTMP 画面设置扫码；不是TikTok账号登录二维码。');label.setWordWrap(True);root.addWidget(label)
        picture=QLabel();picture.setAlignment(Qt.AlignmentFlag.AlignCenter);pix=QPixmap();pix.loadFromData(data);picture.setPixmap(pix.scaled(380,380,Qt.AspectRatioMode.KeepAspectRatio));root.addWidget(picture)
        def save():
            f,_=QFileDialog.getSaveFileName(d,'导出配对码',f'phone{r["id"]}.png','PNG (*.png)')
            if f:Path(f).write_bytes(data)
        for text,fn in [('复制配对文字',lambda:QApplication.clipboard().setText(url)),('复制二维码图片',lambda:QApplication.clipboard().setImage(QImage.fromData(data))),('导出PNG',save)]:
            b=QPushButton(text);b.clicked.connect(fn);root.addWidget(b)
        d.exec()
    def copy_url(self):self.safe(lambda:QApplication.clipboard().setText(self.manager.url(self.one())))
    def account(self):self.safe(self._account)
    def _account(self):
        from accounts import AccountWindow
        r=self.one();id=r['id']
        if id not in self.accounts:self.accounts[id]=AccountWindow(self.store,id,self)
        w=self.accounts[id];w.show();w.raise_();w.activateWindow();return w
    def dashboard(self):
        def go():w=self._account();w.dashboard()
        self.safe(go)
    def duplicate(self):
        def go():
            r=self.one();n=self.store.create()
            self.store.update(n['id'],{k:r.get(k) for k in ['label','remark','video','metadata','enabled']});self.refresh()
        self.safe(go)
    def toggle(self):
        def go():
            r=self.one();enabled=not r.get('enabled',True)
            if not enabled:self.manager.stop(r['id'])
            self.store.update(r['id'],dict(enabled=enabled));self.refresh()
        self.safe(go)
    def unpair(self):
        def go():
            r=self.one()
            if QMessageBox.question(self,'解绑手机','解除此通道的手机绑定？旧配对心跳将失效。')!=QMessageBox.StandardButton.Yes:return
            self.store.update(r['id'],dict(device='',heartbeat=0,heartbeat_key='',receiving=False));self.refresh()
        self.safe(go)
    def remove(self):
        ids=self.selected()
        if not ids:return
        if QMessageBox.question(self,'删除通道',f'删除 {len(ids)} 路并停止推流？已绑定手机的旧地址将不可用。')!=QMessageBox.StandardButton.Yes:return
        for id in ids:
            self.manager.stop(id);self.store.remove(id)
            if id in self.accounts:self.accounts.pop(id).shutdown()
        self.refresh()
    def save_ip(self):
        def go():
            import ipaddress
            value=str(ipaddress.IPv4Address(self.ip.text().strip()))
            if self.manager.processes:raise ValueError('请先停止全部通道再更改IP；改变后需重新配对手机')
            self.manager.close();self.manager=Manager(self.store);self.model.manager=self.manager
            self.manager.ip=value;self.store.set_setting('server_ip',value);self.refresh()
        self.safe(go)
    def details(self,*args):
        ids=self.selected()
        if len(ids)!=1:return
        r=self.store.get(ids[0]);s=self.manager.status(r['id']);m=r.get('metadata',{})
        self.detail.setPlainText(f"通道 {r['id']}   {r.get('label','')}\n{r.get('remark','')}\n\nRTMP地址\n{self.manager.url(r)}\n\n视频\n{r.get('video','未选择')}\n\n规格\n{m.get('width','—')} × {m.get('height','—')}\n帧率 {m.get('fps','—')}\n音频 AAC / {m.get('sample_rate','—')} Hz / {m.get('channels','—')}声道\n码率 {m.get('bitrate',0)/1e6:.2f} Mbps\n前12秒采样峰值 {m.get('peak_sample',0)/1e6:.2f} Mbps\n\n运行 {s.get('uptime',0)}秒 / 循环 {s.get('loops',0)}次\n素材位置 {s.get('position',0):.1f}秒 / 续播重推 {s.get('repush_count',0)}次\n{ s.get('error','') }\n\n手机最近心跳\n"+(time.strftime('%H:%M:%S',time.localtime(r['heartbeat'])) if r.get('heartbeat') else '尚未收到')+'\n\n大屏数据按实际网页标签读取；无数据不等于零。')
    def budget(self):
        d=QDialog(self);d.setWindowTitle('手动带宽预算（估算，不是保证）');form=QFormLayout(d)
        total=QDoubleSpinBox();total.setRange(0,100000);total.setValue(self.store.setting('bandwidth_total',100))
        reserve=QDoubleSpinBox();reserve.setRange(0,100000);reserve.setValue(self.store.setting('bandwidth_reserve',0))
        margin=QDoubleSpinBox();margin.setRange(0,99);margin.setValue(self.store.setting('bandwidth_margin',50))
        form.addRow('WiFi实测持续可用 Mbps',total);form.addRow('其他传输预留 Mbps',reserve);form.addRow('安全余量 %',margin);result=QLabel();result.setWordWrap(True);form.addRow(result)
        def calculate():
            b=bandwidth(self.store.rows(),total.value(),reserve.value(),margin.value()/100)
            result.setText(f"可用预算 {b['budget']:.2f} Mbps\n启用通道需求 {b['used']:.2f} Mbps\n剩余 {b['remaining']:.2f} Mbps\n按5000k视频+128k音频，建议再加≤{b['extra']}路\n包含1.15协议开销；峰值只采样前12秒，WiFi竞争仍需实测。")
            for k,v in [('total',total.value()),('reserve',reserve.value()),('margin',margin.value())]:self.store.set_setting('bandwidth_'+k,v)
        for field in (total,reserve,margin):field.valueChanged.connect(calculate)
        calculate();d.exec()
    def export_menu(self):
        action,ok=QInputDialog.getItem(self,'配置与导出','选择操作',['导出配置JSON','导入配置JSON','导出通道CSV','导出日志'],editable=False)
        if not ok:return
        self.safe(lambda:self.do_export(action))
    def do_export(self,action):
        if action=='导入配置JSON':
            f,_=QFileDialog.getOpenFileName(self,'导入配置','','JSON (*.json)')
            if not f:return
            raw=Path(f).read_bytes()
            if len(raw)>10*1024*1024:raise ValueError('配置文件过大')
            data=json.loads(raw)
            if not isinstance(data,list) or len(data)>10000:raise ValueError('配置格式不正确')
            for r in data:
                if not isinstance(r,dict):raise ValueError('配置条目不是对象')
                n=self.store.create();self.store.update(n['id'],{k:r.get(k,'') for k in ['label','remark','video','account_alias']})
                if r.get('video'):self.load_video(n,r['video'])
            self.refresh();return
        f,_=QFileDialog.getSaveFileName(self,'导出', 'meow-channels.json' if 'JSON' in action else 'meow-channels.csv' if 'CSV' in action else 'meow-log.txt')
        if not f:return
        rows=[{k:r.get(k) for k in ['id','label','remark','video','stream_path','enabled','metadata','account_alias']} for r in self.store.rows()]
        if 'JSON' in action:Path(f).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
        elif 'CSV' in action:
            with open(f,'w',encoding='utf-8-sig',newline='') as out:
                w=csv.DictWriter(out,fieldnames=['id','label','remark','video','stream_path','account_alias'],extrasaction='ignore');w.writeheader();w.writerows(rows)
        else:Path(f).write_text('\n'.join(self.manager.events),encoding='utf-8')
    def closeEvent(self,event):
        if self.manager.processes and QMessageBox.question(self,'退出','退出将停止全部视频通道，确认退出？')!=QMessageBox.StandardButton.Yes:event.ignore();return
        self.timer.stop()
        for w in self.accounts.values():w.shutdown()
        self.manager.close();self.jobs.pool.shutdown(wait=False,cancel_futures=True);super().closeEvent(event)

def main():
    app=QApplication(sys.argv);app.setApplicationName('Meow Stream Manager');app.setFont(QFont('Microsoft YaHei UI',10))
    w=Window(Path(sys.argv[sys.argv.index('--data')+1]) if '--data' in sys.argv else None);w.show()
    if '--smoke' in sys.argv:
        if not w.store.rows():w.store.create();w.refresh()
        target=w
        if '--browser-smoke' in sys.argv:
            from accounts import AccountWindow
            # Smoke testing must not launch or log into a real account website.
            from unittest.mock import patch
            with patch.object(AccountWindow,'home',lambda self:None):
                target=AccountWindow(w.store,w.store.rows()[0]['id'],w)
            target.show()
        def finish():
            target.grab().save(sys.argv[sys.argv.index('--smoke')+1]);target.close();w.close();app.quit()
        QTimer.singleShot(4000 if '--browser-smoke' in sys.argv else 1500,finish)
    return app.exec()
if __name__=='__main__':raise SystemExit(main())
