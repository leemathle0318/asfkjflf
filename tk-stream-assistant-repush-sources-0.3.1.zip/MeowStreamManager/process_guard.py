"""Windows job object: owned server/workers die if the manager crashes/exits."""
import os,ctypes
from ctypes import wintypes

class ProcessGuard:
    def __init__(self):
        self.handle=None
        if os.name!='nt':return
        class Basic(ctypes.Structure):
            _fields_=[('user',ctypes.c_int64),('kernel',ctypes.c_int64),('flags',wintypes.DWORD),
                ('min_work',ctypes.c_size_t),('max_work',ctypes.c_size_t),('active',wintypes.DWORD),
                ('affinity',ctypes.c_size_t),('priority',wintypes.DWORD),('scheduling',wintypes.DWORD)]
        class IO(ctypes.Structure):
            _fields_=[(x,ctypes.c_uint64) for x in ['read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes']]
        class Extended(ctypes.Structure):
            _fields_=[('basic',Basic),('io',IO),('process_limit',ctypes.c_size_t),('job_limit',ctypes.c_size_t),
                ('peak_process',ctypes.c_size_t),('peak_job',ctypes.c_size_t)]
        self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.kernel.CreateJobObjectW.restype=wintypes.HANDLE
        self.kernel.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR]
        self.kernel.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
        self.kernel.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE]
        self.kernel.CloseHandle.argtypes=[wintypes.HANDLE]
        handle=self.kernel.CreateJobObjectW(None,None)
        info=Extended();info.basic.flags=0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if handle and self.kernel.SetInformationJobObject(handle,9,ctypes.byref(info),ctypes.sizeof(info)):self.handle=handle
        elif handle:self.kernel.CloseHandle(handle)
    def assign(self,process):
        return bool(self.handle and self.kernel.AssignProcessToJobObject(self.handle,int(process._handle)))
    def close(self):
        if self.handle:self.kernel.CloseHandle(self.handle);self.handle=None
