import collections, hashlib, http.server, ipaddress, json, os, re, secrets, socket, subprocess, sys, threading, time
from pathlib import Path
from engine import Store, atomic_json, runtime_root, CREATE_NO_WINDOW
from process_guard import ProcessGuard

class Manager:
    def __init__(self,store):
        self.store=store;self.processes={};self.server=None;self.http=None;self.http_thread=None
        self.tickets={};self.ticket_lock=threading.Lock();self.failures={};self.retries={};self.closing=False
        self.events=collections.deque(maxlen=300)
        self.pending_repush={}
        self.ip=store.setting('server_ip',self.detect_ip());self.port=1935;self.control_port=8320
        self.guard=ProcessGuard()
        self.started=time.time();self.seen_heartbeats={}
    def is_online(self,row):
        received=self.seen_heartbeats.get(row['id'])
        return bool(row.get('device') and received is not None and time.monotonic()-received<15)
    @staticmethod
    def detect_ip():
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        try:s.connect(('192.0.2.1',1));return s.getsockname()[0]
        except OSError:return '127.0.0.1'
        finally:s.close()
    def log(self,text):
        self.events.append(time.strftime('%H:%M:%S')+' '+str(text)[:500])
    def url(self,row):return f"rtmp://{self.ip}:{self.port}/{row['stream_path']}"
    def start_server(self):
        if self.server and self.server.poll() is None:return
        ports=[(self.port,self.ip),(9997,'127.0.0.1')]
        if not self.http:ports.append((self.control_port,self.ip))
        for port,host in ports:
            with socket.socket() as s:
                try:s.bind((host,port))
                except OSError as e:raise ValueError(f'地址 {host}:{port} 不可用，请检查本机IP、端口占用和防火墙') from e
        runtime=runtime_root();binary=runtime/'mediamtx.exe'
        if not binary.is_file():raise ValueError('缺少随附的 MediaMTX，必须完整解压软件包')
        # Only RTMP is exposed to LAN. Publishing and administrative API are loopback-only.
        text=f'''logLevel: info
logDestinations: [stdout]
readTimeout: 10s
writeTimeout: 10s
api: yes
apiAddress: 127.0.0.1:9997
rtsp: no
rtmp: yes
rtmpAddress: :{self.port}
hls: no
webrtc: no
srt: no
moq: no
authMethod: internal
authInternalUsers:
  - user: any
    ips: [127.0.0.1, "::1"]
    permissions:
      - action: publish
      - action: api
  - user: any
    ips: [10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 127.0.0.1/32]
    permissions:
      - action: read
pathDefaults:
  source: publisher
  overridePublisher: no
paths:
  all_others:
'''
        config=self.store.root/'mediamtx.yml';config.write_text(text,encoding='utf-8')
        self.server=subprocess.Popen([str(binary),str(config)],stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=CREATE_NO_WINDOW)
        if not self.guard.assign(self.server):self.log('系统未允许进程退出保护；正常退出仍会主动清理进程')
        process=self.server
        def server_log():
            try:
                for line in process.stdout:
                    self.log(re.sub(r'live/[a-zA-Z0-9_-]+','live/[通道]',line.decode('utf-8','replace').strip()))
            finally:process.stdout.close()
        threading.Thread(target=server_log,daemon=True).start()
        deadline=time.monotonic()+4
        while time.monotonic()<deadline:
            if self.server.poll() is not None:raise ValueError('MediaMTX 启动失败，请检查配置或端口')
            try:
                with socket.create_connection(('127.0.0.1',self.port),timeout=.2):break
            except OSError:time.sleep(.1)
        else:self.server.terminate();raise ValueError('MediaMTX 未能建立监听')
        if not self.http:
            self.http=PairServer((self.ip,self.control_port),self)
            self.http_thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.http_thread.start()
        self.log('RTMP 服务器已启动；仅用于可信局域网，不要做公网端口转发')
    def ticket(self,id):
        self.start_server()
        row=self.store.get(id)
        if not row:raise ValueError('通道已删除')
        token=secrets.token_urlsafe(24)
        with self.ticket_lock:
            self.tickets={k:v for k,v in self.tickets.items() if v[1]>time.time() and v[0]!=id}
            self.tickets[token]=(id,time.time()+120)
        return f'meowrtmp://pair?server={self.ip}&port={self.control_port}&token={token}'
    def claim(self,token,device):
        if not isinstance(device,str) or len(device)>100 or not device:raise ValueError('设备标识无效')
        with self.ticket_lock:
            t=self.tickets.pop(token,None)
            if not t or t[1]<time.time():raise ValueError('配对码已过期或已使用，请重新生成')
            row=self.store.get(t[0])
            if not row:raise ValueError('通道已删除')
            if row.get('device') and row['device']!=device:raise ValueError('通道已绑定其他设备，请在电脑上先解绑')
            for other in self.store.rows():
                if other['id']!=row['id'] and other.get('device')==device:raise ValueError('设备已绑定其他通道，请先解绑')
            key=secrets.token_urlsafe(32)
            self.store.update(row['id'],dict(device=device,heartbeat=0,heartbeat_key=hashlib.sha256(key.encode()).hexdigest()))
        return dict(version=1,channel_id=str(row['id']),remark=row.get('remark',''),
            rtmp=self.url(row),server=self.ip,port=self.control_port,heartbeat_key=key)
    def heartbeat(self,data):
        row=self.store.get(int(data.get('channel_id',0)))
        key=str(data.get('key',''))
        if not row or row.get('device')!=data.get('device') or not secrets.compare_digest(
            row.get('heartbeat_key',''),hashlib.sha256(key.encode()).hexdigest()):raise ValueError('设备配对已失效')
        self.store.update(row['id'],dict(heartbeat=time.time(),receiving=bool(data.get('receiving')),
            received_bytes=max(0,int(data.get('bytes',0))),decoded_video=max(0,int(data.get('videos',0)))))
        self.seen_heartbeats[row['id']]=time.monotonic()
        return dict(ok=True)
    def status_path(self,id):return self.store.root/'workers'/f'{id}.status.json'
    def status(self,id):
        p=self.status_path(id)
        try:
            if p.stat().st_size>65536:return {}
            d=json.loads(p.read_text(encoding='utf-8'))
            if time.time()-d.get('updated',0)>15:return dict(state='stale')
            return d
        except (OSError,ValueError):return {}
    def start(self,id):
        row=self.store.get(id)
        if not row or not row.get('video') or not row.get('metadata'):raise ValueError('请先为通道选择检查合格的 MP4')
        if not row.get('enabled',True):raise ValueError('通道已禁用')
        p=self.processes.get(id)
        if p and p.poll() is None:return
        self.start_server()
        config=self.store.root/'workers'/f'{id}.json'
        command_file=self.store.root/'workers'/f'{id}.command.json'
        atomic_json(command_file,dict(id=secrets.token_hex(8),action='noop'))
        atomic_json(config,dict(video=row['video'],url=f"rtmp://127.0.0.1:{self.port}/{row['stream_path']}",status=str(self.status_path(id)),commands=str(command_file)))
        atomic_json(self.status_path(id),dict(state='starting',updated=time.time()))
        args=([sys.executable] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).parent/'main.py')])+['--worker',str(config)]
        self.processes[id]=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,creationflags=CREATE_NO_WINDOW)
        if not self.guard.assign(self.processes[id]):self.log(f'通道 {id} 未加入系统退出保护')
        self.store.update(id,dict(desired_state='running'));self.log(f'通道 {id} 启动')
    def command(self,id,data):
        p=self.processes.get(id)
        if not p or p.poll() is not None:raise ValueError('通道进程未运行')
        atomic_json(self.store.root/'workers'/f'{id}.command.json',dict(data,id=secrets.token_hex(8)))
    def switch(self,id,path):self.command(id,dict(action='switch',video=path))
    def repush(self,id):
        row=self.store.get(id);p=self.processes.get(id);status=self.status(id)
        if not row or not p or p.poll() is not None:raise ValueError('请先启动要重推的通道')
        if id in self.pending_repush or status.get('state') in ('repush_pending','repushing'):
            raise ValueError('此通道正在续播重推，请等待完成')
        if status.get('state')!='running' or 'position' not in status:
            raise ValueError('当前进度尚未就绪，请等待通道正常推流后再试')
        request=secrets.token_hex(16)
        self.command(id,dict(action='repush',request_id=request))
        self.pending_repush[id]=request
        self.log(f'通道 {id} 已请求续播重推：等待下一关键帧，不从片头播放')
    def stop(self,id):
        self.store.update(id,dict(desired_state='stopped'));self.retries.pop(id,None);self.failures.pop(id,None);self.pending_repush.pop(id,None)
        p=self.processes.pop(id,None)
        if not p:return
        try:
            if p.poll() is None:atomic_json(self.store.root/'workers'/f'{id}.command.json',dict(id=secrets.token_hex(8),action='stop'))
            p.wait(timeout=8)
        except (OSError,subprocess.TimeoutExpired):p.kill();p.wait(timeout=3)
        finally:
            if p.stdin:p.stdin.close()
        self.log(f'通道 {id} 已停止')
    def tick(self):
        now=time.time()
        for id,p in list(self.processes.items()):
            if p.poll() is None:
                status=self.status(id)
                if id in self.pending_repush and status.get('command_error_id')==self.pending_repush[id]:
                    self.pending_repush.pop(id,None)
                    self.log(f"通道 {id} 重推请求未接受：{status.get('command_error','请稍后重试')}")
                if id in self.pending_repush and status.get('repush_id')==self.pending_repush[id]:
                    self.pending_repush.pop(id,None)
                    self.log(f"通道 {id} 续播重推完成，素材位置 {status.get('repush_position',0):.1f} 秒")
                if status.get('uptime',0)>120:self.failures.pop(id,None)
                continue
            self.processes.pop(id,None)
            if p.stdin:p.stdin.close()
            row=self.store.get(id)
            if not row or row.get('desired_state')!='running' or self.closing:continue
            status=self.status(id);self.log(f"通道 {id} 异常退出：{status.get('error','无详细错误')}")
            was_repush=self.pending_repush.pop(id,None)
            if status.get('resume_required') or was_repush:
                self.retries.pop(id,None);self.store.update(id,dict(desired_state='stopped'))
                self.log(f'通道 {id} 续播重推未完成，已停止自动重试，避免意外从片头播放')
                continue
            attempts=self.failures.get(id,0)+1;self.failures[id]=attempts
            if attempts<=5:self.retries[id]=now+min(60,2**attempts)+secrets.randbelow(1000)/1000
            else:self.store.update(id,dict(desired_state='stopped'));self.log(f'通道 {id} 连续失败5次，已停止自动重试')
        for id,due in list(self.retries.items()):
            if now>=due:
                self.retries.pop(id,None)
                try:self.start(id)
                except Exception as e:self.log(str(e));self.store.update(id,dict(desired_state='stopped'))
    def close(self):
        self.closing=True
        for id in list(self.processes):self.stop(id)
        if self.http:self.http.shutdown();self.http.server_close();self.http=None
        if self.server and self.server.poll() is None:
            self.server.terminate()
            try:self.server.wait(timeout=4)
            except subprocess.TimeoutExpired:self.server.kill();self.server.wait(timeout=3)
        self.guard.close()

class PairServer(http.server.ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,manager):
        self.manager=manager;self.rates={};self.rate_lock=threading.Lock();super().__init__(address,PairHandler)

class PairHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass  # Never persist tokens in HTTP access logs.
    def do_POST(self):
        self.connection.settimeout(4)
        try:
            with self.server.rate_lock:
                now=time.monotonic();key=self.client_address[0]
                queue=self.server.rates.setdefault(key,collections.deque(maxlen=60))
                while queue and now-queue[0]>60:queue.popleft()
                if len(queue)>=60:raise ValueError('请求过于频繁')
                queue.append(now)
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=8192:raise ValueError('请求大小无效')
            d=json.loads(self.rfile.read(n))
            if self.path=='/pair':value=self.server.manager.claim(str(d.get('token','')),d.get('device'))
            elif self.path=='/heartbeat':value=self.server.manager.heartbeat(d)
            else:self.send_error(404);return
            self.reply(200,value)
        except (ValueError,KeyError,TypeError,OSError) as e:self.reply(400,dict(error=str(e)[:200]))
    def reply(self,status,data):
        b=json.dumps(data,ensure_ascii=False).encode();self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
