from pathlib import Path
from PyInstaller.utils.hooks import collect_all
source=Path(SPECPATH)
data,binaries,hidden=collect_all('av')
pdata,pbinaries,phidden=collect_all('playwright')
data+=pdata;binaries+=pbinaries;hidden+=phidden
data += [(str(source/'runtime'),'runtime'),(str(source/'extractor.js'),'.')]
a=Analysis([str(source/'main.py')],pathex=[str(source)],binaries=binaries,datas=data,
    hiddenimports=hidden+['accounts','account_browser'],hookspath=[],runtime_hooks=[],
    excludes=['PySide6.QtWebEngineCore','PySide6.QtWebEngineWidgets','PySide6.QtWebEngineQuick'],noarchive=False)
# Qt uses the Windows OS ICU API. A different ICU build found on PATH exports
# version-suffixed symbols and must not shadow System32/icuuc.dll.
a.binaries=[e for e in a.binaries if Path(e[0]).name.lower() not in ('icuuc.dll','icudt78.dll')]
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='MeowStreamManager',debug=False,
    strip=False,upx=False,console=False,disable_windowed_traceback=False)
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='MeowStreamManager')
