$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath 'runtime/mediamtx.exe') -or -not (Test-Path -LiteralPath 'runtime/ffprobe.exe')) {
    throw '请先将交付的 Windows 软件包中 _internal/runtime 的完整内容复制到本源码的 runtime 目录。必须保留动态库和许可证。'
}
python -m venv .build-env
if ($LASTEXITCODE -ne 0) { throw '创建构建环境失败，需要 Python 3.12 x64' }
& .build-env/Scripts/python.exe -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw '依赖安装失败' }
& .build-env/Scripts/python.exe -m PyInstaller --noconfirm MeowStreamManager.spec
if ($LASTEXITCODE -ne 0) { throw 'EXE构建失败' }
Write-Host '输出：dist/MeowStreamManager/MeowStreamManager.exe；整个目录一起交付。'
