#pragma once
#include <algorithm>
namespace obs {
// A published stream ended: promptly build a fresh session, keeping replacement
// enabled. Repeated failures retain bounded backoff, never a reconnect busy loop.
struct RtmpReconnectState { unsigned failures=0,quickRetries=0; };
inline double rtmpReconnectDelay(bool receivedMedia,RtmpReconnectState &state) {
    if(receivedMedia){state.failures=0;state.quickRetries=4;return .25;}
    // A new publisher needs time to expose tracks. A short, bounded grace
    // window avoids turning one expected not-ready response into a long wait.
    if(state.quickRetries){--state.quickRetries;return .5;}
    state.failures=std::min(state.failures,6u)+1;
    return double(std::min(15u,2u+state.failures*2u));
}
}
