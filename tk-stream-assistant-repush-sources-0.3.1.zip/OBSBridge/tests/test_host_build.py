"""Portable source regressions; not execution of the macOS toolchain."""
from pathlib import Path
import hashlib,re,unittest

ROOT=Path(__file__).resolve().parents[1]

class HostBuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=(ROOT/'scripts/run_new_audio_tests.sh').read_text(encoding='utf-8')
        cls.commands=re.sub(r'#.*','',cls.source).replace('\\\n',' ')

    def test_explicit_macos_sdk_and_tools(self):
        self.assertIn('HOST_SDK="$(xcrun --sdk macosx --show-sdk-path)"',self.commands)
        for tool in ('clang','clang++','ar','ranlib'):
            self.assertIn('xcrun --sdk macosx --find '+tool,self.commands)
        self.assertIn('export SDKROOT="$HOST_SDK"',self.commands)

    def test_configure_target_and_host_helpers_both_get_sdk(self):
        command=self.commands.split('  "$SOURCE/configure" --prefix=',1)[1].split('make -j',1)[0]
        for flag in ('--target-os=darwin','--arch="$HOST_ARCH"','--sysroot="$HOST_SDK"',
                     '--cc="$HOST_CC"','--ld="$HOST_CC"','--extra-cflags="$HOST_FLAGS"',
                     '--extra-cxxflags="$HOST_FLAGS"','--extra-ldflags="$HOST_FLAGS"',
                     '--host-cc="$HOST_CC"','--host-ld="$HOST_CC"',
                     '--host-cflags="$HOST_FLAGS"','--host-ldflags="$HOST_FLAGS"'):
            self.assertIn(flag,command)
        self.assertIn('-isysroot $HOST_SDK',self.commands)
        self.assertNotIn('--enable-cross-compile',self.commands)

    def test_probe_and_actual_cpp_tests_use_same_sdk(self):
        for compiler,ending in (('HOST_CC','"$BUILD/compiler-smoke"'),('HOST_CXX','"work/${NAME}_tests"')):
            command=self.commands.split('"$'+compiler+'" -arch',1)[1].split(ending,1)[0]
            self.assertIn('-isysroot "$HOST_SDK"',command)
            self.assertIn('-mmacosx-version-min="$MACOSX_DEPLOYMENT_TARGET"',command)
        self.assertLess(self.commands.index('"$BUILD/compiler-smoke"\n'),self.commands.index('  "$SOURCE/configure" --prefix='))

    def test_inherited_mobile_flags_are_not_used(self):
        self.assertIn('unset SDKROOT CC CXX LD AR RANLIB CFLAGS CPPFLAGS CXXFLAGS LDFLAGS',self.commands)
        self.assertIn('unset IPHONEOS_DEPLOYMENT_TARGET TVOS_DEPLOYMENT_TARGET WATCHOS_DEPLOYMENT_TARGET',self.commands)
        self.assertIn('export MACOSX_DEPLOYMENT_TARGET=13.0',self.commands)
        self.assertIn('case "$HOST_ARCH" in arm64|x86_64)',self.commands)

    def test_failures_visible_and_long_tests_retained(self):
        self.assertIn('trap host_failure EXIT',self.commands)
        self.assertIn('STATUS=$?',self.commands)
        self.assertIn('tail -n 100 "$LOG"',self.commands)
        self.assertIn('set -euo pipefail',self.commands)
        self.assertIn('capture_clock capture_wire common_clock ffmpeg_timeline prepared_capture full_audio_pipeline',self.commands)
        self.assertIn('"work/full_audio_pipeline_tests" 14400 both',self.commands)
        workflow=(ROOT/'.github/workflows/build-deb.yml').read_text(encoding='utf-8')
        self.assertIn('/work/ffmpeg-host-build/compiler-smoke.log',workflow)
        self.assertIn('python3 -m unittest discover -s tests -p test_host_build.py -v',workflow)

    def test_ios_dependency_build_not_modified(self):
        self.assertEqual(hashlib.sha256((ROOT/'scripts/build_ffmpeg.sh').read_bytes()).hexdigest(),
                         '2c39be05b848f36b9e6a10f885c707e0bd7b18dac289a08bf092ef343a9a31b4')

if __name__=='__main__':unittest.main(verbosity=2)
