"""Check actual .deb payloads, not just source-tree files. No extraction to disk."""
import io
import plistlib
import struct
import sys
import tarfile
from pathlib import Path, PurePosixPath

# Current runtime splits slow control work from PCM preparation. This is a
# package-content contract, not proof of device execution or audience audio.
LIVE_AUDIO_MARKERS = (
    b"local.xiaoguai.obsbridge.live.control",
    b"local.xiaoguai.obsbridge.live.prepare",
    b"local.xiaoguai.obsbridge.capture.v1.sequence",
    b"AudioUnitRender", b"libSandy_applyProfile",
    b"local.xiaoguai.obsbridge.live.mapping",
    b"local.xiaoguai.obsbridge.media-v5.dat",
)


def macho_slices(raw, name):
    if raw[:4] != b"\xca\xfe\xba\xbe" or len(raw) < 8:
        raise ValueError("expected universal arm64/arm64e Mach-O: " + name)
    count = struct.unpack_from(">I", raw, 4)[0]
    end = 8 + 20 * count
    if not count or count > 32 or end > len(raw):
        raise ValueError("invalid Mach-O architecture table: " + name)
    result = {}
    regions = []
    for i in range(count):
        cpu, subtype, start, size, align = struct.unpack_from(">IIIII", raw, 8 + 20 * i)
        key = (cpu, subtype & 0xffffff)
        if (start < end or size < 32 or start + size > len(raw) or
                raw[start:start + 4] != b"\xcf\xfa\xed\xfe" or key in result or
                any(start < last and first < start + size for first, last in regions)):
            raise ValueError("invalid Mach-O slice: " + name)
        actual_cpu, actual_subtype = struct.unpack_from("<II", raw, start + 4)
        if (actual_cpu, actual_subtype & 0xffffff) != key:
            raise ValueError("Mach-O slice architecture mismatch: " + name)
        result[key] = raw[start:start + size]
        regions.append((start, start + size))
    if (0x0100000c, 0) not in result or (0x0100000c, 2) not in result:
        raise ValueError("missing arm64/arm64e architecture: " + name)
    return result


def payload(path, with_metadata=False):
    raw = Path(path).read_bytes()
    if raw[:8] != b"!<arch>\n":
        raise ValueError("not a Debian ar archive")
    offset = 8
    result = {}
    metadata = {}
    while offset < len(raw):
        header = raw[offset:offset + 60]
        if len(header) != 60 or header[-2:] != b"`\n":
            raise ValueError("invalid ar header")
        name = header[:16].decode("ascii").strip().rstrip("/")
        size = int(header[48:58])
        start = offset + 60
        if start + size > len(raw):
            raise ValueError("truncated ar member")
        if name.startswith("data.tar"):
            with tarfile.open(fileobj=io.BytesIO(raw[start:start + size])) as archive:
                for member in archive.getmembers():
                    if not member.isfile():
                        continue
                    key = PurePosixPath(member.name).as_posix().removeprefix("./")
                    result[key] = archive.extractfile(member).read()
                    metadata[key] = (member.uid, member.gid, member.mode)
        offset = start + size + size % 2
    return (result, metadata) if with_metadata else result


def check(path):
    files, metadata = payload(path, with_metadata=True)
    prefix = "var/jb/Library/"
    required = [
        "MobileSubstrate/DynamicLibraries/OBSBridge.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridge.plist",
        "MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist",
        "PreferenceBundles/OBSBridgePrefs.bundle/OBSBridgePrefs",
        "PreferenceBundles/OBSBridgePrefs.bundle/Info.plist",
        "PreferenceBundles/OBSBridgePrefs.bundle/Root.plist",
        "PreferenceLoader/Preferences/OBSBridge.plist",
        "libSandy/local.xiaoguai.obsbridge.media-read.plist",
        "MobileSubstrate/DynamicLibraries/OBSBridgeLive.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridgeLive.plist",
        "libSandy/local.xiaoguai.obsbridge.live-read.plist",
        "libSandy/local.xiaoguai.obsbridge.control-read.plist",
    ]
    missing = [prefix + name for name in required if prefix + name not in files]
    if missing:
        raise ValueError("missing packaged files: " + ", ".join(missing))
    app="var/jb/Applications/OBSBridgeControl.app/"
    if app+"OBSBridgeControl" not in files or app+"Info.plist" not in files:
        raise ValueError("missing packaged RTMP control app")
    info=plistlib.loads(files[app+"Info.plist"])
    if info.get("CFBundleIdentifier")!="local.xiaoguai.obsbridge.control" or not info.get("NSCameraUsageDescription"):
        raise ValueError("incorrect RTMP control app identity/camera declaration")
    if info.get("CFBundleDisplayName") != "tk直播推流助手" or "CFBundleURLTypes" in info:
        raise ValueError("incorrect app display name or legacy URL route still registered")
    rule=plistlib.loads(files[prefix+required[12]])
    if rule!={"AllowedProcesses":["local.xiaoguai.obsbridge.control"],"Extensions":[{"type":"file","extension_class":"com.apple.app-sandbox.read","path":"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}]}:
        raise ValueError("control app profile grants more than the single readonly media cache")
    uid,gid,mode=metadata[prefix+required[12]]
    if uid!=0 or gid!=0 or mode & 0o022:raise ValueError("control profile must be root:root and not writable by group/others")
    profile_key = prefix + required[8]
    uid, gid, mode = metadata[profile_key]
    if uid != 0 or gid != 0 or mode & 0o022:
        raise ValueError(f"libSandy profile must be root:root and not writable by group/others; actual uid={uid}, gid={gid}, mode={mode:04o}")
    profile = plistlib.loads(files[profile_key])
    if profile.get("AllowedProcesses") != ["com.apple.mediaserverd"] or profile.get("Extensions") != [
        {"type": "file", "extension_class": "com.apple.app-sandbox.read",
         "path": "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}]:
        raise ValueError("libSandy profile is missing/nonspecific or grants more than the media read path")
    daemon = plistlib.loads(files[prefix + required[1]])
    shortcut = plistlib.loads(files[prefix + required[3]])
    if daemon.get("Filter") != {"Executables": ["mediaserverd"]}:
        raise ValueError("incorrect media-service filter")
    if shortcut.get("Filter") != {"Bundles": ["com.apple.springboard"]}:
        raise ValueError("incorrect SpringBoard filter")
    for name in [prefix+required[0], prefix+required[2], prefix+required[4], prefix+required[9],app+"OBSBridgeControl"]:
        macho_slices(files[name], name)
    media = files[prefix + required[0]]
    receiver = files[prefix + required[2]]
    if b"SBVolumeControl" in receiver:
        raise ValueError("legacy volume menu still present in receiver")
    if b"BWNodeOutput" not in media or b"emitSampleBuffer:" not in media:
        raise ValueError("media dylib is not the v2 node consumer")
    if b"local.xiaoguai.obsbridge.receive" not in receiver:
        raise ValueError("SpringBoard dylib does not contain the independent receiver")
    marker = b"local.xiaoguai.obsbridge.media-v5.dat"
    if marker not in media or marker not in receiver:
        raise ValueError("missing v5 read-only-consumer transport in one or both modules")
    if b"libSandy_applyProfile" not in media:
        raise ValueError("missing scoped libSandy integration in media module")
    if b"local.xiaoguai.obsbridge.v5.audio.phase" not in media or b"local.xiaoguai.obsbridge.v5.audio.phase" not in receiver:
        raise ValueError("missing native-audio diagnostics in one or both modules")
    live = plistlib.loads(files[prefix + required[10]])
    if live.get("Filter") != {"Bundles": ["com.zhiliaoapp.musically"]}:
        raise ValueError("incorrect TikTok live audio filter")
    profile_key = prefix + required[11]
    uid, gid, mode = metadata[profile_key]
    if uid != 0 or gid != 0 or mode & 0o022:
        raise ValueError("live libSandy profile must be root:root and not writable by group/others")
    live_profile = plistlib.loads(files[profile_key])
    if live_profile.get("AllowedProcesses") != ["com.zhiliaoapp.musically"] or live_profile.get("Extensions") != [
        {"type": "file", "extension_class": "com.apple.app-sandbox.read", "path": "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}]:
        raise ValueError("live libSandy profile grants more than TikTok read-only media")
    app_audio = files[prefix + required[9]]
    slices = macho_slices(app_audio, "OBSBridgeLive.dylib")
    for subtype, label in ((0, "arm64"), (2, "arm64e")):
        for marker in LIVE_AUDIO_MARKERS:
            if marker not in slices[(0x0100000c, subtype)]:
                raise ValueError("missing live audio entry integration (" + label + "): " + marker.decode())
    return len(files)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: check_deb.py PACKAGE.deb [...]")
    for name in sys.argv[1:]:
        try:
            count = check(name)
        except (ValueError, OSError, tarfile.TarError, struct.error) as error:
            raise SystemExit(f"PACKAGE CHECK FAILED: {name}: {error}")
        print(f"PASS: {Path(name).name}: {count} files; v5 read-only transport + media consumer + independent receiver + settings present")
