#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/RtmpReconnect.hpp"
#include <cassert>
#include <cstdio>
int main(){
    obs::RtmpReconnectState state;
    assert(obs::rtmpReconnectDelay(true,state)==.25 && state.failures==0);
    for(unsigned i=0;i<4;++i)assert(obs::rtmpReconnectDelay(false,state)==.5);
    assert(obs::rtmpReconnectDelay(false,state)==4. && state.failures==1);
    assert(obs::rtmpReconnectDelay(false,state)==6. && state.failures==2);
    for(unsigned i=0;i<100000;++i){double delay=obs::rtmpReconnectDelay(false,state);assert(delay>=4 && delay<=15 && state.failures<=7);}
    assert(obs::rtmpReconnectDelay(true,state)==.25 && state.failures==0);
    for(unsigned i=0;i<1000;++i)assert(obs::rtmpReconnectDelay(true,state)==.25 && !state.failures);
    std::puts("PASS RTMP media-session restart: prompt bounded reconnect; repeated failure backoff and overflow guards");
}
