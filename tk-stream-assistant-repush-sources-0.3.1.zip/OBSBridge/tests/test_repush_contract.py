"""Source contracts only; not real iPhone reconnection verification."""
from pathlib import Path
import re,unittest
ROOT=Path(__file__).resolve().parents[1]
class RepushContract(unittest.TestCase):
    def test_reconnect_resets_audio_without_explicit_camera_restore(self):
        text=(ROOT/'Receiver.mm').read_text(encoding='utf-8')
        pull=text.split('void pullRTMP(',1)[1].split('BOOL OBEnabled',1)[0]
        pull=re.sub(r'//[^\n]*|/\*.*?\*/','',pull,flags=re.S)
        self.assertIn('e.clearLocked();if(receivedMedia)++e.rtmpRebuilds',pull)
        self.assertIn('obs::rtmpReconnectDelay(receivedMedia,reconnect)',pull)
        self.assertNotIn('OBStop(',pull);self.assertNotIn('OBBusEnable(NO)',pull)
        clear=text.split('void clearLocked()',1)[1].split('double scheduleLocked',1)[0]
        self.assertIn('clock.reset()',clear);self.assertIn('OBBusResetAudio()',clear)
    def test_short_retry_window_is_bounded_and_observable(self):
        policy=(ROOT/'core/RtmpReconnect.hpp').read_text(encoding='utf-8')
        self.assertIn('state.quickRetries=4',policy);self.assertIn('--state.quickRetries',policy)
        self.assertIn('std::min(15u',policy)
        self.assertIn('RTMP 接收重建',(ROOT/'Receiver.mm').read_text(encoding='utf-8'))
        self.assertIn('OB_VERSION_CODE 0x00030005u',(ROOT/'Shared.h').read_text(encoding='utf-8'))
    def test_workflow_retains_pinned_audio_tests_and_new_reconnect_test(self):
        flow=(ROOT/'.github/workflows/build-deb.yml').read_text(encoding='utf-8')
        script=(ROOT/'scripts/run_new_audio_tests.sh').read_text(encoding='utf-8')
        for name in ('core/RtmpReconnect.hpp','tests/rtmp_reconnect_tests.cpp','tests/test_repush_contract.py'):
            self.assertIn(name,flow);self.assertTrue((ROOT/name).is_file())
        self.assertIn('full_audio_pipeline rtmp_reconnect; do',script)
        self.assertIn('"work/full_audio_pipeline_tests" 14400 both',script)
        self.assertIn('test_repush_contract.py -v',flow)
if __name__=='__main__':unittest.main(verbosity=2)
