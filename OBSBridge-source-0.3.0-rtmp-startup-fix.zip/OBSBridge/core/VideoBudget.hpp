#pragma once
#include <cstdint>
#include <cmath>
namespace obs {
struct VideoBudget { unsigned edge, fps; };
inline VideoBudget videoBudget(unsigned profile, unsigned thermal) {
    if (thermal >= 3) return {640, 15};
    if (thermal >= 2) return {800, 20};
    return profile ? VideoBudget{1280, 30} : VideoBudget{960, 30};
}
struct FrameGate {
    double last = 0;
    bool valid = false;
    bool admit(double pts, unsigned fps) {
        if (!std::isfinite(pts) || !fps) return false;
        if (valid && pts >= last && pts - last < 1. / fps - .00001) return false;
        last = pts; valid = true; return true;
    }
};
}
