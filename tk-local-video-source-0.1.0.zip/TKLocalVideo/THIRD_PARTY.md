# 本地文件版的第三方依赖与边界

- 工程代码以本包 LICENSE 为准。测试 MP4 是本次生成的灰色视频与 440Hz 合成音，不含用户素材。
- 本版使用设备自带 AVFoundation、CoreMedia、CoreVideo、CoreImage、AudioToolbox 等系统框架。没有捆绑 FFmpeg、libx264、MediaMTX 或苹果 SDK；也不调用 FFmpeg 自动时间戳选项。本地调度和读时钟校正在本工程实现。
- 系统 `BWNodeOutput emitSampleBuffer:` 接口研究沿用先前分支参考：EthanArbuckle/vcam-ios、GUSHU101/VCamLab-2.0。仅参考公开接口和架构，未从无明确许可项目复制媒体实现或二进制。上游接口可用不代表本机兼容性已经验证。
- libSandy：只动态调用设备安装的公开接口，不捆绑二进制。曾审查提交 `9c77311172485e92bf0c439391be5a9565c877e4`，MIT Copyright (c) 2022 Lars Fröder，许可见 LICENSE-libSandy.txt。两个 profile 仅授权 mediaserverd 或 TikTok 读取本插件单个共享媒体文件，不授权读取用户素材目录。
- https://github.com/opa334/libSandy
- https://github.com/theos/theos
- Actions 固定 Theos `304e0799973e8145f32e4ca2de6c747a84b758ce`、SDK 仓库 `0222fd5413cf4b9af096f37b4621afa2688572f7`。源码包不分发它们。使用相关系统工具及 SDK 须遵守其各自条款。
- `prepare_packaging.py` 仅在核对固定 dm.pl 哈希后修正 tar 数字属主，保留上游源码及许可，不自带 dm.pl；测试有未修正/修正对照。
