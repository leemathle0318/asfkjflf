#import <UIKit/UIKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import "../Client.h"
#import "../LocalImport.h"

@interface OBLocalController : UITableViewController <UIDocumentPickerDelegate>
@property(nonatomic, strong) OBLocalImport *importer;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, copy) NSString *importText;
@end
@implementation OBLocalController
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = @"本地视频";
    __weak OBLocalController *weakSelf = self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer *timer) {
        (void)timer; if (weakSelf.navigationController.topViewController == weakSelf)
            [weakSelf.tableView reloadSections:[NSIndexSet indexSetWithIndex:3] withRowAnimation:UITableViewRowAnimationNone];
    }];
}
- (void)dealloc { [self.timer invalidate]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { (void)tableView; return 4; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    (void)tableView; return section == 0 ? (self.importer ? 3 : 1) : section == 1 ? 3 : section == 2 ? 3 : 2;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    (void)tableView; return @[@"素材", @"播放", @"设置", @"状态"][section];
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    (void)tableView;
    if (section == 0) return @"MP4 · H.264 / AAC。后台导入保存一份副本，不加载整段视频到内存。";
    if (section == 2) return @"视频声音加入直播采音，不通过手机扬声器外放。请用另一台设备确认观众端画面和声音。";
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)path {
    (void)tableView;
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.textLabel.numberOfLines = 0; cell.detailTextLabel.numberOfLines = 0;
    if (path.section == 0) {
        if (path.row == 0) { cell.textLabel.text = OBCDisplayName(); cell.selectionStyle = UITableViewCellSelectionStyleNone; }
        else if (path.row == 1) { cell.textLabel.text = self.importText ?: @"正在准备文件"; cell.selectionStyle = UITableViewCellSelectionStyleNone; }
        else { cell.textLabel.text = @"取消导入"; cell.textLabel.textColor = UIColor.systemRedColor; }
    } else if (path.section == 1) {
        cell.textLabel.text = @[@"从文件导入 MP4", @"开始播放 / 从头重播", @"停止并恢复摄像头"][path.row];
        cell.textLabel.textColor = path.row == 2 ? UIColor.systemRedColor : UIColor.systemBlueColor;
        if (path.row == 0 && self.importer) { cell.textLabel.textColor = UIColor.secondaryLabelColor; cell.userInteractionEnabled = NO; }
    } else if (path.section == 2) {
        if (path.row < 2) {
            UISwitch *toggle = [UISwitch new];
            cell.textLabel.text = path.row == 0 ? @"循环播放" : @"视频声音";
            toggle.on = path.row == 0 ? OBCLoop() : OBCLiveAudioEnabled();
            [toggle addTarget:self action:path.row == 0 ? @selector(loopChanged:) : @selector(audioChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = toggle; cell.selectionStyle = UITableViewCellSelectionStyleNone;
        } else { cell.textLabel.text = @"额外旋转 +90°"; cell.detailTextLabel.text = [NSString stringWithFormat:@"当前 %ld°", (long)OBCVideoRotation()*90]; }
    } else {
        cell.textLabel.text = path.row ? @"完整状态" : OBCSummary();
        cell.accessoryType = path.row ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
        if (!path.row) cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}
- (void)message:(NSString *)text {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"tk本地直播助手" message:text preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)loopChanged:(UISwitch *)sender { NSString *error = OBCSetLoop(sender.on); if (error) { sender.on = !sender.on; [self message:error]; } }
- (void)audioChanged:(UISwitch *)sender { NSString *error = OBCSetLiveAudioEnabled(sender.on); if (error) { sender.on = !sender.on; [self message:error]; } }
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)path {
    [tableView deselectRowAtIndexPath:path animated:YES];
    if (path.section == 0 && path.row == 2) { [self.importer cancel]; self.importText = @"正在取消，等待文件操作返回"; [self.tableView reloadData]; }
    else if (path.section == 1 && path.row == 0 && !self.importer) {
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTTypeMPEG4Movie] asCopy:NO];
        picker.delegate = self; picker.allowsMultipleSelection = NO; [self presentViewController:picker animated:YES completion:nil];
    } else if (path.section == 1 && path.row > 0) {
        NSString *error = OBCSendLocalCommand(path.row == 1);
        [self message:error ?: (path.row == 1 ? @"播放请求已发送，请检查实际画面和直播声音" : @"停止请求已发送")];
    } else if (path.section == 2 && path.row == 2) {
        NSString *error = OBCSetVideoRotation((OBCVideoRotation()+1)&3);
        if (error) [self message:error]; else [self.tableView reloadData];
    } else if (path.section == 3 && path.row == 1) {
        UIViewController *detail = [UIViewController new]; detail.title = @"完整状态";
        UITextView *text = [UITextView new]; text.editable = NO; text.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
        text.text = OBCStatus(); text.backgroundColor = UIColor.systemBackgroundColor; detail.view = text;
        detail.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"复制" style:UIBarButtonItemStylePlain target:self action:@selector(copyStatus)];
        [self.navigationController pushViewController:detail animated:YES];
    }
}
- (void)copyStatus {
    UIViewController *top = self.navigationController.topViewController;
    UIPasteboard.generalPasteboard.string = [top.view isKindOfClass:UITextView.class] ? ((UITextView *)top.view).text : OBCStatus();
    top.navigationItem.rightBarButtonItem.title = @"已复制";
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    (void)controller; if (!urls.count || self.importer) return;
    self.importer = [OBLocalImport new]; self.importText = @"等待文件提供者，正在准备导入";
    __weak OBLocalController *weakSelf = self;
    self.importer.progress = ^(double fraction, NSString *phase) {
        weakSelf.importText = [NSString stringWithFormat:@"%@ · %.0f%%", phase, fraction*100];
        [weakSelf.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
    };
    self.importer.completion = ^(NSString *name, NSString *displayName, NSString *error) {
        OBLocalController *strongSelf = weakSelf; if (!strongSelf) return;
        if (!error) error = OBCSaveSelection(name,displayName);
        strongSelf.importer = nil; [strongSelf.tableView reloadData];
        [strongSelf message:error ?: @"导入完成。点“开始播放”使用新素材，当前播放不会自动切换。"];
    };
    [self.tableView reloadData]; [self.importer start:urls.firstObject];
}
@end

@interface OBLocalApp : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation OBLocalApp
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    (void)application; (void)options;
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [[UINavigationController alloc] initWithRootViewController:[[OBLocalController alloc] initWithStyle:UITableViewStyleInsetGrouped]];
    [self.window makeKeyAndVisible]; return YES;
}
@end
int main(int argc, char **argv) {
    @autoreleasepool { return UIApplicationMain(argc,argv,nil,NSStringFromClass(OBLocalApp.class)); }
}
