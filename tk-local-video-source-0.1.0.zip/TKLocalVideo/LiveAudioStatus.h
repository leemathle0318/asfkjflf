#pragma once
#import <Foundation/Foundation.h>
FOUNDATION_EXPORT NSString *OBLiveAudioStatus(void);
// Called on the media health queue, never in a PCM callback.
FOUNDATION_EXPORT void OBRefreshLiveAudioOwner(void);
FOUNDATION_EXPORT BOOL OBLiveAudioOwnsCapture(void);

FOUNDATION_EXPORT BOOL OBProgramAudioEnabled(void);
