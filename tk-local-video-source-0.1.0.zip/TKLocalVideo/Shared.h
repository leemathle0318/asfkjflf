#pragma once
#define OB_DOMAIN CFSTR("local.xiaoguai.tk.local")
#define OB_NOTIFY "local.xiaoguai.tk.local.changed"
#define OB_CONFIG @"/var/mobile/Library/Preferences/local.xiaoguai.tk.local.plist"
#define OB_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.tk.local.status.plist"
#define OB_VERSION @"0.1.0-local"
#define OB_VERSION_CODE 0x00010001u
#define OB_AUDIO_NOTIFY "local.xiaoguai.tk.local.v6.audio"
#define OB_VIDEO_ROTATION_NOTIFY "local.xiaoguai.tk.local.v6.video.rotation"
#define OB_ACCESS_PROFILE "local.xiaoguai.tk.local.media-read"
#define OB_ACCESS_NOTIFY "local.xiaoguai.tk.local.v6.media.read-permission"
#define OB_BUS_FILE "/var/mobile/Library/Preferences/local.xiaoguai.tk.local.media-local-v1.dat"
#define OB_BUS_NOTIFY "local.xiaoguai.tk.local.v6.bus"
#define OB_MEDIA_HEARTBEAT "local.xiaoguai.tk.local.v2.media.heartbeat"
#define OB_MEDIA_HOOKS "local.xiaoguai.tk.local.v2.media.hooks"
#define OB_MEDIA_COUNTS "local.xiaoguai.tk.local.v2.media.counts"
#define OB_MEDIA_MAPPING "local.xiaoguai.tk.local.v6.media.mapping"
#if OB_APP_AUDIO
// Separate diagnosis/authorization channels: the app must not overwrite media
// service mapping status, identity or health notifications.
#undef OB_ACCESS_PROFILE
#define OB_ACCESS_PROFILE "local.xiaoguai.tk.local.live-read"
#undef OB_ACCESS_NOTIFY
#define OB_ACCESS_NOTIFY "local.xiaoguai.tk.local.live.read-permission"
#undef OB_MEDIA_MAPPING
#define OB_MEDIA_MAPPING "local.xiaoguai.tk.local.live.mapping"
#endif
#define OB_SHORTCUT_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.tk.local.shortcut.status.plist"

#define OB_LOCAL_LIBRARY @"/var/mobile/Library/Preferences/local.xiaoguai.tk.local.files"
#if OB_LOCAL_TEST
// Test-only builds never touch the device's managed import directory.
#undef OB_LOCAL_LIBRARY
#define OB_LOCAL_LIBRARY [NSProcessInfo.processInfo.environment objectForKey:@"OB_LOCAL_TEST_LIBRARY"]
#endif
