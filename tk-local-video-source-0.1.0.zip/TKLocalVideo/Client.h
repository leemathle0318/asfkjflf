#pragma once
#import <Foundation/Foundation.h>
FOUNDATION_EXPORT NSString *OBCSelectedFile(void);
FOUNDATION_EXPORT NSString *OBCDisplayName(void);
FOUNDATION_EXPORT NSString *OBCSaveSelection(NSString *name, NSString *displayName);
FOUNDATION_EXPORT BOOL OBCLoop(void);
FOUNDATION_EXPORT NSString *OBCSetLoop(BOOL loop);
FOUNDATION_EXPORT NSInteger OBCVideoRotation(void);
FOUNDATION_EXPORT NSString *OBCSetVideoRotation(NSInteger turns);
FOUNDATION_EXPORT BOOL OBCLiveAudioEnabled(void);
FOUNDATION_EXPORT NSString *OBCSetLiveAudioEnabled(BOOL enabled);
FOUNDATION_EXPORT NSString *OBCSendLocalCommand(BOOL enabled);
FOUNDATION_EXPORT NSString *OBCStatus(void);
FOUNDATION_EXPORT NSString *OBCSummary(void);
