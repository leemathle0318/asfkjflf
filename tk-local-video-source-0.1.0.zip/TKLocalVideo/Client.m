#import "Client.h"
#import "Shared.h"
#import "LocalFiles.h"
#if OB_CONTROL_IN_SPRINGBOARD
#import "Receiver.h"
#endif
#include <notify.h>
#include <sys/stat.h>
#include <math.h>
#include <errno.h>
#include <string.h>
// Both control UIs and mediaserverd use this explicit shared path. A successful
// CFPreferences synchronize is not proof that this particular file was written.
static NSMutableDictionary *OBCReadConfig(void) {
    return [[NSDictionary dictionaryWithContentsOfFile:OB_CONFIG] mutableCopy] ?: [NSMutableDictionary dictionary];
}
static NSString *OBCWriteConfig(NSDictionary *config) {
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:config
        format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    if (!data) return [NSString stringWithFormat:@"无法生成控制配置：%@ (%@/%ld)",
        error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    if (![data writeToFile:OB_CONFIG options:NSDataWritingAtomic error:&error])
        return [NSString stringWithFormat:@"无法写入共享配置：%@\n%@ (%@/%ld)\n暂未发送通知。",
            OB_CONFIG, error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    if (chmod(OB_CONFIG.fileSystemRepresentation, 0644) != 0) {
        int code = errno;
        return [NSString stringWithFormat:@"配置已保存，但无法设置读取权限：%s (errno %d)\n暂未发送通知。",
            strerror(code), code];
    }
    NSDictionary *saved = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    if (![saved isEqualToDictionary:config])
        return @"共享配置写入后校验失败，暂未发送通知。请截图此提示。";
    return nil;
}


NSString *OBCSelectedFile(void) { id v = OBCReadConfig()[@"SelectedFile"]; return [v isKindOfClass:NSString.class] ? v : @""; }
NSString *OBCDisplayName(void) { id v = OBCReadConfig()[@"DisplayName"]; return [v isKindOfClass:NSString.class] ? v : @"尚未导入素材"; }
NSString *OBCSaveSelection(NSString *name, NSString *displayName) {
    NSString *error = OBValidateManagedFile(name); if (error) return error;
    NSMutableDictionary *config = OBCReadConfig(); config[@"SelectedFile"] = name;
    config[@"DisplayName"] = displayName ?: name; return OBCWriteConfig(config);
}
BOOL OBCLoop(void) { id v = OBCReadConfig()[@"Loop"]; return ![v isKindOfClass:NSNumber.class] || [v boolValue]; }
NSString *OBCSetLoop(BOOL loop) {
    NSMutableDictionary *config = OBCReadConfig(); config[@"Loop"] = @(loop);
    NSString *error = OBCWriteConfig(config); if (!error) notify_post(OB_NOTIFY); return error;
}
NSInteger OBCVideoRotation(void) { return [OBCReadConfig()[@"VideoRotation"] integerValue] & 3; }
NSString *OBCSetVideoRotation(NSInteger turns) {
    NSMutableDictionary *config = OBCReadConfig(); config[@"VideoRotation"] = @(turns & 3);
    NSString *error = OBCWriteConfig(config); if (!error) notify_post(OB_NOTIFY); return error;
}
BOOL OBCLiveAudioEnabled(void) { id v = OBCReadConfig()[@"LiveAudio"]; return ![v isKindOfClass:NSNumber.class] || [v boolValue]; }
NSString *OBCSetLiveAudioEnabled(BOOL enabled) {
    NSMutableDictionary *config = OBCReadConfig(); config[@"LiveAudio"] = @(enabled);
    NSString *error = OBCWriteConfig(config); if (!error) notify_post(OB_NOTIFY); return error;
}
NSString *OBCSendLocalCommand(BOOL enabled) {
    NSMutableDictionary *config = OBCReadConfig();
    if (enabled) { NSString *error = OBValidateManagedFile(config[@"SelectedFile"]); if (error) return error; }
    config[@"Enabled"] = @(enabled); config[@"RequestID"] = NSUUID.UUID.UUIDString; config[@"RequestDate"] = [NSDate date];
    NSString *error = OBCWriteConfig(config); if (error) return error;
    return notify_post(OB_NOTIFY) == NOTIFY_STATUS_OK ? nil : @"请求已保存，等待播放服务读取";
}
#if !OB_CONTROL_IN_SPRINGBOARD
static NSDictionary *OBCFreshStatus(void) {
    NSDictionary *s = [NSDictionary dictionaryWithContentsOfFile:OB_STATUS]; id d = s[@"Date"];
    return [d isKindOfClass:NSDate.class] && fabs([d timeIntervalSinceNow]) <= 8 ? s : nil;
}
#endif
NSString *OBCStatus(void) {
#if OB_CONTROL_IN_SPRINGBOARD
    return OBControlStatus();
#else
    id v = OBCFreshStatus()[@"Text"]; return [v isKindOfClass:NSString.class] ? v : @"播放服务暂无新状态，安装后请重启用户空间";
#endif
}
NSString *OBCSummary(void) {
#if OB_CONTROL_IN_SPRINGBOARD
    return OBSummary();
#else
    id v = OBCFreshStatus()[@"Summary"]; return [v isKindOfClass:NSString.class] ? v : @"播放服务暂无新状态";
#endif
}
