#import "LocalImport.h"
#import "LocalFiles.h"
#import "Shared.h"
#import <AVFoundation/AVFoundation.h>
#include "core/LocalPlayback.hpp"
#include <atomic>
#include <vector>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>
#include <cerrno>
@implementation OBLocalImport {
    std::atomic<bool> _cancelled;
}
- (void)cancel { _cancelled.store(true); }
- (void)start:(NSURL *)url {
    _cancelled.store(false);
    BOOL scoped = [url startAccessingSecurityScopedResource];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @autoreleasepool {
            NSString *error = nil, *name = nil, *temporary = nil, *publishedPath = nil;
            if (!url.isFileURL || ![url.pathExtension.lowercaseString isEqualToString:@"mp4"]) error = @"请选择 MP4 文件";
            if (!error) error = OBPrepareLibrary();
            if (!error && !self->_cancelled.load()) {
                name = [NSUUID.UUID.UUIDString stringByAppendingString:@".mp4"];
                NSString *destination = OBManagedPath(name);
                temporary = [[destination stringByDeletingPathExtension] stringByAppendingString:@".importing.mp4"];
                __block NSString *copyError = nil;
                NSError *coordinateError = nil;
                NSFileCoordinator *coordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
                [coordinator coordinateReadingItemAtURL:url options:0 error:&coordinateError byAccessor:^(NSURL *source) {
                    if (self->_cancelled.load()) return;
                    int input = open(source.fileSystemRepresentation, O_RDONLY | O_CLOEXEC);
                    struct stat info{}; struct statvfs space{};
                    if (input < 0 || fstat(input, &info) || !S_ISREG(info.st_mode) || info.st_size <= 0) {
                        if (input >= 0) close(input); copyError = @"无法读取完整视频，请先将文件下载到本机"; return;
                    }
                    if (!statvfs(OB_LOCAL_LIBRARY.fileSystemRepresentation, &space) &&
                        uint64_t(info.st_size) + 16 * 1024 * 1024 > uint64_t(space.f_bavail) * space.f_frsize) {
                        close(input); copyError = @"手机剩余空间不足，导入需要保存一份视频副本"; return;
                    }
                    int output = open(temporary.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
                    if (output < 0) { close(input); copyError = @"无法写入素材副本"; return; }
                    std::vector<uint8_t> buffer(1024 * 1024); // never NSData(contentsOfFile:) for the whole movie
                    double lastUpdate = 0;
                    bool ok = obs::local::copyChunks(buffer.data(), buffer.size(), uint64_t(info.st_size),
                        [&](uint8_t *p, size_t n) { ssize_t k; do { k = read(input, p, n); } while (k < 0 && errno == EINTR); return k; },
                        [&](const uint8_t *p, size_t n) { ssize_t k; do { k = write(output, p, n); } while (k < 0 && errno == EINTR); return k; },
                        [&] { return self->_cancelled.load(); }, [&](uint64_t copied, uint64_t total) {
                            double now = NSProcessInfo.processInfo.systemUptime;
                            if (now-lastUpdate < .1 && copied != total) return;
                            lastUpdate = now; double fraction = double(copied)/double(total);
                            dispatch_async(dispatch_get_main_queue(), ^{ if (self.progress) self.progress(fraction, @"正在导入"); });
                        });
                    if (ok && fsync(output)) ok = false;
                    close(output); close(input);
                    if (!ok && !self->_cancelled.load()) copyError = @"视频复制未完成，原素材和当前播放不受影响";
                }];
                error = copyError ?: (coordinateError ? coordinateError.localizedDescription : nil);
                if (!error && !self->_cancelled.load()) {
                    dispatch_async(dispatch_get_main_queue(), ^{ if (self.progress) self.progress(1, @"正在检查音视频轨道"); });
                    AVURLAsset *asset = [AVURLAsset URLAssetWithURL:[NSURL fileURLWithPath:temporary] options:nil];
                    AVAssetTrack *video = [asset tracksWithMediaType:AVMediaTypeVideo].firstObject;
                    AVAssetTrack *audio = [asset tracksWithMediaType:AVMediaTypeAudio].firstObject;
                    CMFormatDescriptionRef vf = video.formatDescriptions.count ? (__bridge CMFormatDescriptionRef)video.formatDescriptions.firstObject : nullptr;
                    CMFormatDescriptionRef af = audio.formatDescriptions.count ? (__bridge CMFormatDescriptionRef)audio.formatDescriptions.firstObject : nullptr;
                    if (!vf || !af || CMFormatDescriptionGetMediaSubType(vf) != kCMVideoCodecType_H264 ||
                        CMFormatDescriptionGetMediaSubType(af) != kAudioFormatMPEG4AAC)
                        error = @"本版要求 MP4 内含 H.264 视频和 AAC 声音；不会自动转码";
                    else if (rename(temporary.fileSystemRepresentation, destination.fileSystemRepresentation)) error = @"保存素材失败";
                    else publishedPath = destination;
                }
            }
            if (self->_cancelled.load()) error = @"已取消导入";
            if (error && publishedPath) unlink(publishedPath.fileSystemRepresentation);
            if (error && temporary) unlink(temporary.fileSystemRepresentation); // only our UUID staging file
            if (scoped) [url stopAccessingSecurityScopedResource];
            NSString *result = error ? nil : name;
            dispatch_async(dispatch_get_main_queue(), ^{ if (self.completion) self.completion(result, url.lastPathComponent, error); });
        }
    });
}
@end
