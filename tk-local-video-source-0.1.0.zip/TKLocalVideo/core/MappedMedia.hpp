#pragma once
#include "SharedMedia.hpp"
#include <new>
namespace obs {
constexpr uint32_t FileMagic = 0x4f424c31, FileVersion = 7;
// Capacity is chosen from the received frame, not a fixed resolution preset.
constexpr size_t PixelBytes = sizeof(std::atomic<uint32_t>);
static_assert(PixelBytes == 4, "32-bit pixel atomics required");
struct FrameGeometry {
    uint32_t width, height, stride;
    bool valid() const {
        return width && height && width <= UINT32_MAX / 4 && stride == width * 4 &&
            uint64_t(width) * height <= SIZE_MAX / PixelBytes;
    }
};
// Writer invalidates the slot sequence before changing any payload. Readers
// only load atomic words and verify the sequence again after copying. They
// never modify leases or any mapped memory (PROT_READ is sufficient).
struct RawVideo {
    std::atomic<uint32_t> width{0}, height{0}, stride{0};
    // Immutable relative offsets, validated against the full mapped file before use.
    uint64_t capacity = 0, offset = 0;
    const std::atomic<uint32_t> *pixels() const {
        return reinterpret_cast<const std::atomic<uint32_t> *>(reinterpret_cast<const uint8_t *>(this) + offset);
    }
    std::atomic<uint32_t> *pixels() {
        return reinterpret_cast<std::atomic<uint32_t> *>(reinterpret_cast<uint8_t *>(this) + offset);
    }
    FrameGeometry geometry() const {
        return {width.load(std::memory_order_relaxed), height.load(std::memory_order_relaxed), stride.load(std::memory_order_relaxed)};
    }
    bool valid() const { auto g = geometry(); return g.valid() && uint64_t(g.width) * g.height <= capacity; }
    bool write(const uint8_t *source, size_t row, uint32_t w, uint32_t h) {
        if (!source || !w || !h || w > UINT32_MAX / 4 || uint64_t(w) * h > capacity ||
            row < size_t(w)*4 || row > SIZE_MAX / h)
            return false;
        width.store(w, std::memory_order_relaxed); height.store(h, std::memory_order_relaxed);
        stride.store(w*4, std::memory_order_relaxed);
        for (uint32_t y = 0; y < h; ++y) for (uint32_t x = 0; x < w; ++x) {
            uint32_t word; std::memcpy(&word, source+size_t(y)*row+size_t(x)*4, 4);
            pixels()[size_t(y)*w+x].store(word, std::memory_order_relaxed);
        }
        return true;
    }
    void clear() {
        width.store(0, std::memory_order_relaxed); height.store(0, std::memory_order_relaxed); stride.store(0, std::memory_order_relaxed);
        for (size_t i = 0; i < capacity; ++i) pixels()[i].store(0, std::memory_order_relaxed);
    }
    bool copy(FrameGeometry g, uint8_t *destination, size_t row, size_t capacity) const {
        if (!g.valid() || uint64_t(g.width) * g.height > this->capacity || !destination || row < g.stride || row > SIZE_MAX / g.height || capacity < row * g.height)
            return false;
        for (uint32_t y = 0; y < g.height; ++y) for (uint32_t x = 0; x < g.width; ++x) {
            uint32_t word = pixels()[size_t(y)*g.width+x].load(std::memory_order_relaxed);
            std::memcpy(destination+size_t(y)*row+size_t(x)*4, &word, 4);
        }
        return true;
    }
};
struct alignas(64) MappedMedia {
    std::atomic<uint32_t> magic{0};
    uint32_t version = FileVersion;
    uint64_t bytes = sizeof(MappedMedia), cookie = 0;
    SharedMedia state;
    std::array<RawVideo, 3> frames;
    static constexpr size_t allocationBytes(size_t pixels) {
        return pixels > (SIZE_MAX - sizeof(MappedMedia)) / (3 * PixelBytes) ? 0 :
            sizeof(MappedMedia) + pixels * 3 * PixelBytes;
    }
    void initialize(uint64_t session, size_t capacityPixels) {
        bytes = allocationBytes(capacityPixels); cookie = session;
        for (unsigned i = 0; i < 3; ++i) {
            auto &raw = frames[i]; raw.capacity = capacityPixels;
            raw.offset = sizeof(MappedMedia) + i * capacityPixels * PixelBytes -
                size_t(reinterpret_cast<uint8_t *>(&raw) - reinterpret_cast<uint8_t *>(this));
            for (size_t j = 0; j < capacityPixels; ++j)
                new (&raw.pixels()[j]) std::atomic<uint32_t>(0);
        }
        state.initialize(); magic.store(FileMagic, std::memory_order_release);
    }
    bool valid(uint64_t session, size_t mappedBytes) const {
        if (magic.load(std::memory_order_acquire) != FileMagic || version != FileVersion ||
            bytes != mappedBytes || cookie != session || !session || mappedBytes < sizeof(MappedMedia)) return false;
        const size_t capacityPixels = frames[0].capacity;
        if (allocationBytes(capacityPixels) != mappedBytes) return false;
        for (unsigned i = 0; i < 3; ++i) {
            const auto &raw = frames[i];
            const size_t expected = sizeof(MappedMedia) + i * capacityPixels * PixelBytes -
                size_t(reinterpret_cast<const uint8_t *>(&raw) - reinterpret_cast<const uint8_t *>(this));
            if (raw.capacity != capacityPixels || raw.offset != expected) return false;
        }
        return true;
    }
};
struct FrameTicket {
    unsigned slot;
    uint32_t sequence, generation;
    uint64_t due;
    FrameGeometry geometry;
};
inline void beginFrameWrite(VideoSlot &slot) {
    slot.sequence.store(0, std::memory_order_relaxed);
    // A reader that observes any of the following atomic payload stores must
    // also observe this invalidation before its final sequence check.
    std::atomic_thread_fence(std::memory_order_release);
}
inline bool captureFrame(const MappedMedia &bus, unsigned index, uint64_t now, FrameTicket &ticket) {
    if (index >= 3 || !bus.state.fresh(now)) return false;
    const auto &slot = bus.state.video[index];
    uint32_t sequence = slot.sequence.load(std::memory_order_acquire);
    if (!sequence || slot.lease.load(std::memory_order_acquire) == WriterLease) return false;
    uint32_t generation = bus.state.generation.load(std::memory_order_acquire);
    uint64_t due = slot.dueUS.load(std::memory_order_relaxed);
    FrameGeometry geometry = bus.frames[index].geometry();
    if (!geometry.valid() || uint64_t(geometry.width) * geometry.height > bus.frames[index].capacity || slot.surface.load(std::memory_order_relaxed) != index+1 ||
        slot.generation.load(std::memory_order_relaxed) != generation || due > now || now-due >= 500000)
        return false;
    ticket = {index, sequence, generation, due, geometry};
    return true;
}
inline bool frameUnchanged(const MappedMedia &bus, const FrameTicket &ticket, uint64_t now) {
    if (ticket.slot >= 3) return false;
    // Order all payload reads before the second sequence check.
    std::atomic_thread_fence(std::memory_order_acq_rel);
    const auto &slot = bus.state.video[ticket.slot];
    return slot.sequence.load(std::memory_order_acquire) == ticket.sequence && ticket.sequence &&
        slot.lease.load(std::memory_order_acquire) != WriterLease &&
        slot.generation.load(std::memory_order_acquire) == ticket.generation &&
        bus.state.generation.load(std::memory_order_acquire) == ticket.generation && bus.state.fresh(now);
}
template<class Clock> inline bool copyFrameTimed(const MappedMedia &bus, const FrameTicket &ticket, Clock clock,
                                                uint8_t *destination, size_t row, size_t capacity) {
    if (!frameUnchanged(bus, ticket, clock()) ||
        !bus.frames[ticket.slot].copy(ticket.geometry, destination, row, capacity)) return false;
    return frameUnchanged(bus, ticket, clock());
}
inline bool copyFrame(const MappedMedia &bus, const FrameTicket &ticket, uint64_t now,
                      uint8_t *destination, size_t row, size_t capacity) {
    return copyFrameTimed(bus, ticket, [now] { return now; }, destination, row, capacity);
}
}
