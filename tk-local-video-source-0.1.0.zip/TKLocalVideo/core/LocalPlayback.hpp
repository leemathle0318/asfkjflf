#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <string>
namespace obs::local {
constexpr double Prefetch = .300, StartLead = .350;
struct PlaybackClock {
    double source = 0, host = 0, end = 0;
    bool valid = false;
    bool begin(double firstPTS, double now, bool nextLoop = false) {
        if (!std::isfinite(firstPTS) || !std::isfinite(now) || now < 0) return false;
        double target = valid && nextLoop ? end : now + StartLead;
        if (target < now + .025) target = now + StartLead;
        source = firstPTS; host = target; end = target; valid = true; return true;
    }
    double due(double pts) const { return valid && std::isfinite(pts) ? host + pts - source : NAN; }
    void observe(double pts, double duration) {
        if (std::isfinite(pts) && std::isfinite(duration) && duration > 0)
            end = std::max(end, due(pts) + duration);
    }
    bool late(double pts, double now) const { return valid && due(pts) < now - .500; }
    void rebuffer(double pts, double now) { begin(pts, now); }
};
inline bool managedName(const std::string &name) {
    if (name.size() != 40 || name.substr(36) != ".mp4") return false;
    for (size_t i = 0; i < 36; ++i) {
        if (i == 8 || i == 13 || i == 18 || i == 23) { if (name[i] != '-') return false; }
        else if (!((name[i] >= '0' && name[i] <= '9') || (name[i] >= 'a' && name[i] <= 'f') ||
                   (name[i] >= 'A' && name[i] <= 'F'))) return false;
    }
    return true;
}
// Bounded memory regardless of input length. The adapter owns file descriptors,
// handles errors/cancellation and keeps all I/O off the UI thread.
template<class Read, class Write, class Cancel, class Progress>
bool copyChunks(uint8_t *buffer, size_t capacity, uint64_t expected,
                Read read, Write write, Cancel cancelled, Progress progress) {
    if (!buffer || !capacity || !expected) return false;
    uint64_t total = 0;
    while (!cancelled()) {
        auto n = read(buffer, capacity);
        if (n < 0 || uint64_t(n) > capacity) return false;
        if (!n) return total == expected;
        if (uint64_t(n) > expected - total) return false;
        size_t offset = 0;
        while (offset < size_t(n)) {
            if (cancelled()) return false;
            auto written = write(buffer + offset, size_t(n) - offset);
            if (written <= 0 || uint64_t(written) > size_t(n) - offset) return false;
            offset += size_t(written);
        }
        total += uint64_t(n); progress(total, expected);
    }
    return false;
}
}
