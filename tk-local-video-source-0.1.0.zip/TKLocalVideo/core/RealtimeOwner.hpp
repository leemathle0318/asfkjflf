#pragma once
#include <atomic>
#include <memory>
namespace obs::local {
// A non-waiting RT lease. Only the background writer changes shared ownership;
// readers touch neither reference counts nor destructors. One current owner,
// no lifetime session table and no unbounded retired-mapping list.
template<class T> class RealtimeOwner {
    std::atomic_flag gate = ATOMIC_FLAG_INIT;
    std::shared_ptr<T> owner;
public:
    class Read {
        RealtimeOwner *source;
        const T *pointer;
    public:
        Read(RealtimeOwner *s, const T *p) : source(s), pointer(p) {}
        Read(const Read &) = delete;
        Read &operator=(const Read &) = delete;
        ~Read() { if (source) source->gate.clear(std::memory_order_release); }
        bool acquired() const { return source != nullptr; }
        const T *get() const { return pointer; }
    };
    Read tryRead() {
        if (gate.test_and_set(std::memory_order_acquire)) return Read(nullptr,nullptr);
        return Read(this,owner.get());
    }
    bool replace(std::shared_ptr<T> next) {
        if (gate.test_and_set(std::memory_order_acquire)) return false;
        owner=std::move(next); // destruction can occur only on the writer
        gate.clear(std::memory_order_release); return true;
    }
};
}
