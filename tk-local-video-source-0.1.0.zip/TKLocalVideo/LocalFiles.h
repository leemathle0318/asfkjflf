#pragma once
#import <Foundation/Foundation.h>
FOUNDATION_EXPORT NSString *OBManagedPath(NSString *name);
FOUNDATION_EXPORT NSString *OBValidateManagedFile(NSString *name);
FOUNDATION_EXPORT NSString *OBPrepareLibrary(void);
