#import "LocalFiles.h"
#import "Shared.h"
#include "core/LocalPlayback.hpp"
#include <sys/stat.h>
#include <unistd.h>
NSString *OBManagedPath(NSString *name) {
    if (![name isKindOfClass:NSString.class] || !obs::local::managedName(name.UTF8String ?: "")) return nil;
    return [OB_LOCAL_LIBRARY stringByAppendingPathComponent:name];
}
NSString *OBPrepareLibrary(void) {
    struct stat info{};
    if (lstat(OB_LOCAL_LIBRARY.fileSystemRepresentation, &info)) {
        if (errno != ENOENT || mkdir(OB_LOCAL_LIBRARY.fileSystemRepresentation, 0700)) return @"无法建立本地素材目录";
        if (lstat(OB_LOCAL_LIBRARY.fileSystemRepresentation, &info)) return @"无法检查素材目录";
    }
    if (!S_ISDIR(info.st_mode) || info.st_uid != geteuid() || (info.st_mode & 0022)) return @"素材目录权限或类型不安全";
    return nil;
}
NSString *OBValidateManagedFile(NSString *name) {
    NSString *path = OBManagedPath(name); if (!path) return @"请选择已导入的 MP4";
    struct stat dir{}, info{};
    if (lstat(OB_LOCAL_LIBRARY.fileSystemRepresentation, &dir) || !S_ISDIR(dir.st_mode) ||
        dir.st_uid != geteuid() || (dir.st_mode & 0022)) return @"素材目录不可用";
    if (lstat(path.fileSystemRepresentation, &info) || !S_ISREG(info.st_mode) || info.st_nlink != 1 ||
        info.st_uid != geteuid() || (info.st_mode & 0022) || info.st_size <= 0) return @"素材丢失、为空或权限不符，请重新导入";
    return nil;
}
