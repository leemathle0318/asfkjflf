#import "Receiver.h"
#import "MediaBus.h"
#import "Shared.h"
#include <notify.h>
#include <cmath>
#include <algorithm>
#include <mutex>

namespace {
dispatch_source_t tickTimer;
dispatch_queue_t producerQueue;
std::mutex diagnosticLock;
NSString *lastRequest;
NSString *commandError = @"";
NSString *statusWriteError = @"";
void videoRotation(NSDictionary *config) {
    id value = config[@"VideoRotation"];
    unsigned turns = [value isKindOfClass:NSNumber.class] ? unsigned([value unsignedIntegerValue] & 3) : 0;
    OBBusSetVideoRotation(turns);
    id loop = config[@"Loop"];
    OBSetLocalLoop(![loop isKindOfClass:NSNumber.class] || [loop boolValue]);
    id live = config[@"LiveAudio"];
    OBBusSetLiveAudioEnabled(![live isKindOfClass:NSNumber.class] || [live boolValue]);
}
void control(void) {
    NSDictionary *config = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    videoRotation(config); // Does not stop/restart OBS or replay a saved command.
    NSString *request = config[@"RequestID"];
    NSDate *date = config[@"RequestDate"];
    if (![request isKindOfClass:NSString.class] || [request isEqual:lastRequest] ||
        ![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow) > 15) return;
    lastRequest = request;
    BOOL enabled = [config[@"Enabled"] boolValue];
    NSString *name = config[@"SelectedFile"];
    if (enabled && ![name isKindOfClass:NSString.class]) {
        std::lock_guard<std::mutex> lock(diagnosticLock); commandError = @"请选择已导入的 MP4"; return;
    }
    { std::lock_guard<std::mutex> lock(diagnosticLock); commandError = @""; }
    if (enabled) OBStartLocal(name, ![config[@"Loop"] isKindOfClass:NSNumber.class] || [config[@"Loop"] boolValue]);
    else OBStop();
}
void saveStatus(void) {
    NSDictionary *status = @{@"Version": OB_VERSION, @"Date": [NSDate date],
        @"Text": OBControlStatus(), @"Summary": OBSummary(), @"Enabled": @(OBEnabled())};
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:status
        format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    BOOL ok = data && [data writeToFile:OB_STATUS options:NSDataWritingAtomic error:&error];
    NSString *result = ok ? @"" : [NSString stringWithFormat:@"接收层状态文件写入失败：%@ (%@/%ld)",
        error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    std::lock_guard<std::mutex> lock(diagnosticLock);
    if (![result isEqual:statusWriteError]) {
        statusWriteError = result;
        if (!ok) NSLog(@"[OBSBridge] %@", result);
    }
}
}
NSString *OBControlStatus(void) {
    NSString *command, *file;
    { std::lock_guard<std::mutex> lock(diagnosticLock); command = commandError; file = statusWriteError; }
    return [NSString stringWithFormat:@"%@\n额外旋转 %u°\n%@\n%@", OBStatus(), OBBusVideoRotation() * 90, command, file];
}
__attribute__((constructor)) static void OBProducerInitialize(void) {
    producerQueue = dispatch_queue_create("local.xiaoguai.tk.local.producer", DISPATCH_QUEUE_SERIAL);
    dispatch_async(producerQueue, ^{
        @autoreleasepool {
            NSString *error = OBBusCreate();
            if (error) NSLog(@"[OBSBridge] %@", error);
            // Never auto-start an old saved command after SpringBoard restarts.
            NSDictionary *old = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
            videoRotation(old);
            NSString *request = old[@"RequestID"];
            if ([request isKindOfClass:NSString.class]) lastRequest = request;
            int token;
            uint32_t rc = notify_register_dispatch(OB_NOTIFY, &token, producerQueue, ^(int value) {
                (void)value; control();
            });
            if (rc != NOTIFY_STATUS_OK) {
                std::lock_guard<std::mutex> lock(diagnosticLock);
                commandError = [NSString stringWithFormat:@"命令通知注册失败：%u；使用控制文件轮询", rc];
            }
            tickTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, producerQueue);
            dispatch_source_set_timer(tickTimer, dispatch_time(DISPATCH_TIME_NOW, 0),
                                      NSEC_PER_SEC / 2, NSEC_PER_SEC / 20);
            dispatch_source_set_event_handler(tickTimer, ^{
                @autoreleasepool {
                    OBProducerTick();
                    static double lastControl = 0, lastStatus = 0;
                    double now = OBNow();
                    if (now - lastControl >= .45) { control(); lastControl = now; }
                    if (now - lastStatus >= 1. && (OBEnabled() || now - lastStatus >= 5.)) { saveStatus(); lastStatus = now; }
                    // One-shot wakeup at the next frame deadline; heartbeat at
                    // least twice a second. No fixed video FPS ceiling.
                    uint64_t delay = uint64_t(OBProducerDelay() * NSEC_PER_SEC);
                    dispatch_source_set_timer(tickTimer, dispatch_time(DISPATCH_TIME_NOW, int64_t(std::max(uint64_t(1), delay))),
                                              DISPATCH_TIME_FOREVER, 0);
                }
            });
            dispatch_resume(tickTimer);
            NSLog(@"[OBSBridge] %@ SpringBoard local player initialized", OB_VERSION);
        }
    });
}

void OBRequestVideoTick(void) {
    dispatch_async(producerQueue, ^{
        if (tickTimer) dispatch_source_set_timer(tickTimer, dispatch_time(DISPATCH_TIME_NOW, 0),
                                                DISPATCH_TIME_FOREVER, 0);
    });
}
