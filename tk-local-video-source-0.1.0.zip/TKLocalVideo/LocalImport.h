#pragma once
#import <Foundation/Foundation.h>
@interface OBLocalImport : NSObject
@property(nonatomic, copy) void (^progress)(double fraction, NSString *phase);
@property(nonatomic, copy) void (^completion)(NSString *managedName, NSString *displayName, NSString *error);
- (void)start:(NSURL *)url;
- (void)cancel;
@end
