#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import "../Client.h"
@interface OBPrefs : PSListController
@end
@implementation OBPrefs
- (NSArray *)specifiers { if (!_specifiers) _specifiers=[self loadSpecifiersFromPlistName:@"Root" target:self]; return _specifiers; }
- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key=[specifier propertyForKey:@"key"];
    return [key isEqualToString:@"LiveAudio"] ? @(OBCLiveAudioEnabled()) : @(OBCLoop());
}
- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key=[specifier propertyForKey:@"key"];
    NSString *error=[key isEqualToString:@"LiveAudio"] ? OBCSetLiveAudioEnabled([value boolValue]) : OBCSetLoop([value boolValue]);
    if (error) [self message:error];
}
- (void)message:(NSString *)text {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"tk本地直播助手" message:text preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]]; [self presentViewController:alert animated:YES completion:nil];
}
- (void)startLive { [self message:OBCSendLocalCommand(YES) ?: @"播放请求已发送"]; }
- (void)stopLive { [self message:OBCSendLocalCommand(NO) ?: @"停止请求已发送"]; }
- (void)showStatus { [self message:OBCSummary()]; }
- (void)copyStatus { UIPasteboard.generalPasteboard.string=OBCStatus(); [self message:@"状态已复制"]; }
- (void)rotateVideo { [self message:OBCSetVideoRotation((OBCVideoRotation()+1)&3) ?: @"旋转已保存"]; }
@end
