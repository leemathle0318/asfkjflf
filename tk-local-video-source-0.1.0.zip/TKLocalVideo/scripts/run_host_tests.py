"""Portable host tests; does not claim iOS runtime validation."""
import argparse, os, pathlib, subprocess, sys
p=argparse.ArgumentParser();p.add_argument('--cxx',default='clang++');p.add_argument('--output',type=pathlib.Path);a=p.parse_args()
r=pathlib.Path(__file__).resolve().parents[1];out=(a.output or r/'work/host-tests').resolve();out.mkdir(parents=True,exist_ok=True)
assert out.is_relative_to(r.parent.resolve())
env=dict(os.environ)
temporary=out/'tmp';temporary.mkdir(exist_ok=True)
env['TEMP']=str(temporary);env['TMP']=str(temporary)
if os.name=='nt':
 env['ZIG_LOCAL_CACHE_DIR']=str(r.parents[1]/'zig-cache');env['ZIG_GLOBAL_CACHE_DIR']=str(r.parents[1]/'zig-global-cache')
tests=('timeline','shared_media','pending_frames','mapped_media','access_attempt','video_continuity','native_audio','audio_list_contract','live_audio','source_video','local_pipeline')
for name in tests:
 cmd=[a.cxx]
 if pathlib.Path(a.cxx).name.lower()=='zig.exe':cmd+=['c++']
 cmd+=['-std=c++17','-UNDEBUG','-Wall','-Wextra','-Werror','-O2']
 if name in ('timeline','shared_media'):cmd+=[str(r/'core/Timeline.cpp')]
 cmd+=[str(r/'tests'/f'{name}_tests.cpp')]
 if os.name=='nt' and name in ('shared_media','mapped_media'):cmd+=['-municode']
 if os.name=='nt' and name=='nonblocking_read':cmd+=['-lws2_32']
 exe=out/(name+('.exe' if os.name=='nt' else ''))
 subprocess.run(cmd+['-o',str(exe)],env=env,check=True)
 result=subprocess.run([str(exe)],env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',check=False)
 if result.returncode:
  print(result.stdout+result.stderr,flush=True)
  raise SystemExit(result.returncode)
 (out/(name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
 print(result.stdout.strip(),flush=True)
subprocess.run([sys.executable,'-X','utf8','tests/check_project.py'],cwd=r,env=env,check=True)
for name in ('test_deb_checker.py','test_packaging.py'):
 subprocess.run([sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-p',name,'-v'],cwd=r,env=env,check=True)
