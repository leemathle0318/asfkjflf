#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test "$(uname -s)" = Darwin
mkdir -p work/native-local
SDK="$(xcrun --sdk macosx --show-sdk-path)"
unset SDKROOT IPHONEOS_DEPLOYMENT_TARGET CFLAGS CXXFLAGS LDFLAGS
xcrun --sdk macosx clang++ -std=c++17 -UNDEBUG -Wall -Wextra -Werror -Wno-deprecated-declarations \
  -O2 -fobjc-arc -fblocks -isysroot "$SDK" -DOB_LOCAL_TEST=1 \
  LocalPlayer.mm LocalFiles.mm AudioSample.mm tests/local_player_native_tests.mm \
  -framework Foundation -framework AVFoundation -framework CoreMedia -framework CoreVideo \
  -framework CoreGraphics -framework AudioToolbox -o work/local-native-tests
work/local-native-tests "$PWD/tests/fixtures/sample.mp4" "$PWD/work/native-local" 2>&1 | tee work/local-native-test.log
