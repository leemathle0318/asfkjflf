#import "LiveAudioStatus.h"
#import "MediaBus.h"
#include <notify.h>
#include <atomic>
#include <mutex>
namespace {
const char *names[] = {"local.xiaoguai.tk.local.live.heart", "local.xiaoguai.tk.local.live.owner",
    "local.xiaoguai.tk.local.live.calls", "local.xiaoguai.tk.local.live.mixed",
    "local.xiaoguai.tk.local.live.misses", "local.xiaoguai.tk.local.live.format",
    "local.xiaoguai.tk.local.live.phase", "local.xiaoguai.tk.local.live.read-permission",
    "local.xiaoguai.tk.local.live.mapping", "local.xiaoguai.tk.local.live.partial", "local.xiaoguai.tk.local.live.reanchor",
    "local.xiaoguai.tk.local.live.position", "local.xiaoguai.tk.local.live.mappingbusy"};
int tokens[13] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
std::mutex statusLock;
uint64_t read(unsigned i) {
    std::lock_guard<std::mutex> lock(statusLock);
    uint64_t value = 0;
    if (tokens[i] < 0 && notify_register_check(names[i], &tokens[i])) { tokens[i] = -1; return 0; }
    if (notify_get_state(tokens[i], &value)) return 0;
    return value;
}
std::atomic<uint64_t> owner{0};
std::atomic<bool> programEnabled{true};
}
void OBRefreshLiveAudioOwner(void) { owner.store(read(1), std::memory_order_release); programEnabled.store(OBBusLiveAudioEnabled(),std::memory_order_release); }
BOOL OBProgramAudioEnabled(void) { return programEnabled.load(std::memory_order_acquire); }
BOOL OBLiveAudioOwnsCapture(void) {
    // Cached notification state; no IPC, allocation, filesystem or lock here.
    return obs::heartbeatFresh(owner.load(std::memory_order_acquire), OBNow());
}
NSString *OBLiveAudioStatus(void) {
    uint64_t heart = read(0), calls = read(2), mixed = read(3), misses = read(4), format = read(5), phase = read(6);
    if (!obs::heartbeatFresh(heart, OBNow())) return @"直播音频模块：没有新心跳。请完全退出再打开 TikTok；不能据此认定观众端无声音。";
    NSArray<NSString *> *reasons = @[@"等待麦克风输入", @"已在应用 RemoteIO/VoiceIO 输入加入视频声音 PCM（需观众端确认）",
        @"共享音频尚未就绪，保持原麦克风", @"原生格式/缓冲不匹配，保持原麦克风",
        @"直播混音已关闭", @"等待只读共享映射/授权", @"并发音频单元超过预算，保持原麦克风",
        @"媒体服务版本未确认，暂不混音；安装后请重启用户空间", @"共享映射正在切换，保留本次麦克风"];
    uint64_t access = read(7), mapping = read(8);
    uint64_t coverage=read(9), position=read(11);
    return [NSString stringWithFormat:@"TikTok 音频入口 · PID %u\n%@\n成功输入 %llu / 实际加入视频声音 %llu\n缺音频 %u / 格式或忙碌跳过 %u\n原生 %u Hz / %u 位 / %u 通道\n授权阶段 %u / 详情 %d；映射阶段 %u / 详情 %u\n部分缺音块 %u / 缺失样本 %u / 重新对时 %llu / 映射切换跳过 %llu\n读位置偏差 %.2f ms / 写音频末端提前 %.2f ms\n诊断计数不是观众端播放成功证明。",
        unsigned(heart >> 32), phase < reasons.count ? reasons[unsigned(phase)] : @"未知状态",
        (unsigned long long)calls, (unsigned long long)mixed, unsigned(misses >> 32), unsigned(misses),
        unsigned(format >> 32), unsigned((format >> 16) & 65535), unsigned(format & 65535),
        unsigned(access >> 32), int32_t(access), unsigned(mapping >> 32), uint32_t(mapping),
        uint32_t(coverage>>32),uint32_t(coverage),(unsigned long long)read(10),(unsigned long long)read(12),
        int32_t(position>>32)/1000., int32_t(uint32_t(position))/1000.];
}
