#import "Receiver.h"
#import "MediaBus.h"
#import <CoreImage/CoreImage.h>
#include "core/Timeline.hpp"
#include "core/VideoContinuity.hpp"
#include "core/VideoCopy.hpp"
#include "core/NativePCM.hpp"
#import "AudioSample.h"
#import "Shared.h"
#import <objc/runtime.h>
#include <atomic>
#include <mutex>
#include <array>
#include <vector>
#include <cstring>
#include <cmath>

BOOL OBEnabled(void) {
    auto mapping = OBBusConsumer();
    BOOL enabled = mapping && mapping->data->fresh(uint64_t(OBNow() * 1000000));
    if (!enabled) OBBusClearVideoSnapshot();
    return enabled;
}

namespace {
std::atomic<uint64_t> newRenders{0}, cacheCopies{0}, blackFrames{0}, renderFailures{0};
struct RenderCache {
    std::mutex mutex;
    CVPixelBufferRef source = nullptr, output = nullptr;
    unsigned rotation = 0;
    bool ready = false;
    ~RenderCache() { if (source) CVPixelBufferRelease(source); if (output) CVPixelBufferRelease(output); }
};
RenderCache &renderCache() { static RenderCache value; return value; }
bool copyPixels(CVPixelBufferRef source, CVPixelBufferRef target) {
    if (!source || !target || CVPixelBufferGetWidth(source) != CVPixelBufferGetWidth(target) ||
        CVPixelBufferGetHeight(source) != CVPixelBufferGetHeight(target) ||
        CVPixelBufferGetPixelFormatType(source) != CVPixelBufferGetPixelFormatType(target)) return false;
    if (CVPixelBufferLockBaseAddress(source, kCVPixelBufferLock_ReadOnly) != kCVReturnSuccess) return false;
    if (CVPixelBufferLockBaseAddress(target, 0) != kCVReturnSuccess) {
        CVPixelBufferUnlockBaseAddress(source, kCVPixelBufferLock_ReadOnly); return false;
    }
    struct Unlock {
        CVPixelBufferRef source, target;
        ~Unlock() { CVPixelBufferUnlockBaseAddress(target, 0); CVPixelBufferUnlockBaseAddress(source, kCVPixelBufferLock_ReadOnly); }
    } unlock{source, target};
    size_t count = CVPixelBufferIsPlanar(source) ? CVPixelBufferGetPlaneCount(source) : 1;
    if (!count || count > 2 || CVPixelBufferIsPlanar(source) != CVPixelBufferIsPlanar(target) ||
        (CVPixelBufferIsPlanar(source) && count != CVPixelBufferGetPlaneCount(target))) return false;
    const uint8_t *from[2]{}; uint8_t *to[2]{};
    size_t sourceStride[2]{}, targetStride[2]{}, heights[2]{}, bytes[2]{};
    for (size_t i = 0; i < count; ++i) {
        if (CVPixelBufferIsPlanar(source)) {
            if (CVPixelBufferGetWidthOfPlane(source, i) != CVPixelBufferGetWidthOfPlane(target, i) ||
                CVPixelBufferGetHeightOfPlane(source, i) != CVPixelBufferGetHeightOfPlane(target, i)) return false;
            from[i] = static_cast<const uint8_t *>(CVPixelBufferGetBaseAddressOfPlane(source, i));
            to[i] = static_cast<uint8_t *>(CVPixelBufferGetBaseAddressOfPlane(target, i));
            sourceStride[i] = CVPixelBufferGetBytesPerRowOfPlane(source, i);
            targetStride[i] = CVPixelBufferGetBytesPerRowOfPlane(target, i);
            heights[i] = CVPixelBufferGetHeightOfPlane(source, i);
            bytes[i] = CVPixelBufferGetWidthOfPlane(source, i) * (i ? 2 : 1); // NV12 UV pairs
        } else {
            from[i] = static_cast<const uint8_t *>(CVPixelBufferGetBaseAddress(source));
            to[i] = static_cast<uint8_t *>(CVPixelBufferGetBaseAddress(target));
            sourceStride[i] = CVPixelBufferGetBytesPerRow(source); targetStride[i] = CVPixelBufferGetBytesPerRow(target);
            heights[i] = CVPixelBufferGetHeight(source); bytes[i] = CVPixelBufferGetWidth(source) * 4;
        }
        if (!from[i] || !to[i] || !heights[i] || sourceStride[i] < bytes[i] || targetStride[i] < bytes[i] ||
            sourceStride[i] > SIZE_MAX / heights[i] || targetStride[i] > SIZE_MAX / heights[i]) return false;
    }
    // Validate EVERY plane before touching any real-camera pixel.
    obs::VideoPlane planes[2];
    for (size_t i = 0; i < count; ++i)
        planes[i] = {from[i], to[i], sourceStride[i], targetStride[i], heights[i], bytes[i]};
    return obs::copyVideoPlanes(planes, count);
}
}
void OBPublishVideoDiagnostics(void) {
    OBMediaVideoCounters(newRenders.load(), cacheCopies.load(), blackFrames.load(), renderFailures.load());
}
BOOL OBReplaceVideo(CMSampleBufferRef sample) {
    if (!OBEnabled() || !sample) return NO;
    CVPixelBufferRef dest = CMSampleBufferGetImageBuffer(sample);
    if (!dest) return NO;
    OSType type = CVPixelBufferGetPixelFormatType(dest);
    if (type != kCVPixelFormatType_32BGRA && type != kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange &&
        type != kCVPixelFormatType_420YpCbCr8BiPlanarFullRange) { ++renderFailures; return NO; }
    auto chosen = OBBusCopyVideo();
    // During an active, fresh session, empty/expired/transition frames become
    // black instead of one real-camera flash. Explicit stop or dead producer
    // still restores real capture. Not a privacy/security guarantee.
    auto &cache = renderCache(); std::lock_guard<std::mutex> lock(cache.mutex);
    size_t width = CVPixelBufferGetWidth(dest), height = CVPixelBufferGetHeight(dest);
    if (cache.output && (CVPixelBufferGetWidth(cache.output) != width || CVPixelBufferGetHeight(cache.output) != height ||
        CVPixelBufferGetPixelFormatType(cache.output) != type)) {
        CVPixelBufferRelease(cache.output); cache.output = nullptr; cache.ready = false;
    }
    if (!cache.output) {
        NSDictionary *attrs = @{(id)kCVPixelBufferIOSurfacePropertiesKey: @{}};
        if (CVPixelBufferCreate(kCFAllocatorDefault, width, height, type, (__bridge CFDictionaryRef)attrs,
            &cache.output) != kCVReturnSuccess) { ++renderFailures; return NO; }

    }
    CVPixelBufferRef source = chosen ? chosen->pixel : nullptr;
    unsigned rotation = OBBusVideoRotation(); // cached, no per-frame notify IPC
    if (!cache.ready || source != cache.source || rotation != cache.rotation) {
        // The cache must use the capture buffer's color conversion hints; NV12
        // bytes rendered as BT.601 must not later be advertised as BT.709.
        CFStringRef keys[] = {kCVImageBufferYCbCrMatrixKey, kCVImageBufferColorPrimariesKey,
            kCVImageBufferTransferFunctionKey};
        for (CFStringRef key : keys) {
            CFTypeRef value = CVBufferCopyAttachment(dest, key, nullptr);
            if (value) { CVBufferSetAttachment(cache.output, key, value, kCVAttachmentMode_ShouldPropagate); CFRelease(value); }
            else CVBufferRemoveAttachment(cache.output, key);
        }
        static CIContext *context; static CGColorSpaceRef space; static dispatch_once_t once;
        dispatch_once(&once, ^{
            context = [CIContext contextWithOptions:@{kCIContextUseSoftwareRenderer: @NO, kCIContextCacheIntermediates: @NO}];
            space = CGColorSpaceCreateDeviceRGB();
        });
        @try {
            CIImage *image;
            if (source) {
                image = [CIImage imageWithCVPixelBuffer:source]; CGRect from = image.extent;
                if ((from.size.width < from.size.height) != (width < height)) {
                    image = [image imageByApplyingOrientation:obs::sensorOrientation(
                        uint32_t(from.size.width), uint32_t(from.size.height), uint32_t(width), uint32_t(height))];
                }
                image = [image imageByApplyingOrientation:obs::extraOrientation(OBBusVideoRotation())];
                from = image.extent;
                image = [image imageByApplyingTransform:CGAffineTransformMakeTranslation(-from.origin.x, -from.origin.y)];
                CGFloat scale = MAX(width / from.size.width, height / from.size.height);
                image = [image imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
                image = [image imageByApplyingTransform:CGAffineTransformMakeTranslation(
                    (width - from.size.width * scale) / 2, (height - from.size.height * scale) / 2)];
            } else {
                image = [[CIImage imageWithColor:[CIColor colorWithRed:0 green:0 blue:0 alpha:1]]
                    imageByCroppingToRect:CGRectMake(0, 0, width, height)];
            }
            [context render:image toCVPixelBuffer:cache.output bounds:CGRectMake(0, 0, width, height) colorSpace:space];
            ++newRenders;
            if (cache.source) CVPixelBufferRelease(cache.source);
            cache.source = source ? CVPixelBufferRetain(source) : nullptr;
            cache.rotation = rotation; cache.ready = true;
        } @catch (NSException *exception) { (void)exception; cache.ready = false; ++renderFailures; return NO; }
    } else ++cacheCopies;
    // Camera may request 60 fps while OBS provides 30 fps: rerender only when
    // the validated private OBS source changes, copy rows on duplicate pulls.
    bool copied = cache.ready && copyPixels(cache.output, dest);
    if (copied && !source) ++blackFrames;
    if (!copied) ++renderFailures;
    return copied;
}

namespace {
std::atomic<uint64_t> audioPhase{0}, audioFormat{0}, audioLayout{0}, audioTiming{0};
void audioNote(obs::AudioPhase phase, OSStatus code = 0) {
    audioPhase.store((uint64_t(phase) << 32) | uint32_t(code), std::memory_order_release);
}
obs::NativePCM nativeFormat(const AudioStreamBasicDescription *f) {
    obs::NativePCM pcm;
    if (!f) return pcm;
    pcm.bits = f->mBitsPerChannel; pcm.channels = f->mChannelsPerFrame;
    pcm.frameBytes = f->mBytesPerFrame;
    pcm.floating = (f->mFormatFlags & kAudioFormatFlagIsFloat) != 0;
    pcm.signedInteger = (f->mFormatFlags & kAudioFormatFlagIsSignedInteger) != 0;
    pcm.planar = (f->mFormatFlags & kAudioFormatFlagIsNonInterleaved) != 0;
    pcm.bigEndian = (f->mFormatFlags & kAudioFormatFlagIsBigEndian) != 0;
    pcm.highAligned = (f->mFormatFlags & kAudioFormatFlagIsAlignedHigh) != 0;
    pcm.fractionBits = (f->mFormatFlags & kLinearPCMFormatFlagsSampleFractionMask) >> kLinearPCMFormatFlagsSampleFractionShift;
    unsigned channels = pcm.planar ? 1 : pcm.channels;
    if (channels && !(pcm.frameBytes % channels)) pcm.bytes = pcm.frameBytes / channels;
    return pcm;
}
void recordAudioFormat(const AudioStreamBasicDescription *f, UInt32 frames, unsigned buffers) {
    if (!f) return;
    audioFormat.store((uint64_t(f->mFormatID) << 32) | f->mFormatFlags, std::memory_order_relaxed);
    audioLayout.store((uint64_t(f->mBitsPerChannel & 65535) << 48) |
        (uint64_t(f->mChannelsPerFrame & 255) << 40) | (uint64_t(buffers & 255) << 32) |
        f->mBytesPerFrame, std::memory_order_relaxed);
    uint32_t rate = std::isfinite(f->mSampleRate) && f->mSampleRate >= 0 && f->mSampleRate <= 192000 ?
        uint32_t(std::llround(f->mSampleRate)) : 0;
    audioTiming.store((uint64_t(rate) << 32) | frames, std::memory_order_relaxed);
}
}
@interface OBSystemAudioContext : NSObject {
@public
    std::mutex mutex;
    obs::AudioDeliveryCursor cursor;
}
@end
@implementation OBSystemAudioContext
@end
namespace {
char audioContextKey;
OBSystemAudioContext *contextForAudio(id node) {
    if (!node) {
        static OBSystemAudioContext *fallback; static dispatch_once_t once;
        dispatch_once(&once, ^{ fallback = [OBSystemAudioContext new]; });
        return fallback;
    }
    OBSystemAudioContext *context = objc_getAssociatedObject(node, &audioContextKey);
    if (context) return context;
    @synchronized (node) {
        context = objc_getAssociatedObject(node, &audioContextKey);
        if (!context) {
            context = [OBSystemAudioContext new];
            objc_setAssociatedObject(node, &audioContextKey, context, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    }
    return context;
}
struct BlockOwner {
    CMBlockBufferRef block = nullptr;
    ~BlockOwner() { if (block) CFRelease(block); }
};
}
void OBPublishAudioDiagnostics(void) {
    OBMediaAudioState(audioPhase.load(std::memory_order_acquire), audioFormat.load(),
        audioLayout.load(), audioTiming.load());
}
BOOL OBMixABL(AudioBufferList *abl, UInt32 frames, const AudioStreamBasicDescription *f, double time) {
    if (!OBEnabled()) { audioNote(obs::AudioPhase::Inactive); return NO; }
    if (!f || f->mFormatID != kAudioFormatLinearPCM) { audioNote(obs::AudioPhase::Format); return NO; }
    if (!abl || !abl->mNumberBuffers || abl->mNumberBuffers > 8 || !frames || frames > 8192) {
        audioNote(obs::AudioPhase::Layout); return NO;
    }
    obs::NativePCM pcm = nativeFormat(f);
    obs::PCMBuffer buffers[8];
    for (unsigned i = 0; i < abl->mNumberBuffers; ++i)
        buffers[i] = {abl->mBuffers[i].mData, abl->mBuffers[i].mDataByteSize, abl->mBuffers[i].mNumberChannels};
    if (!obs::nativeLayout(pcm, buffers, abl->mNumberBuffers, frames)) {
        audioNote(obs::AudioPhase::Layout); return NO;
    }
    thread_local std::array<float, 8192> scratch;
    auto mapping = OBBusConsumer();
    if (!mapping || !mapping->data->readAudio(scratch.data(), frames, time, f->mSampleRate,
        uint64_t(OBNow() * 1000000))) { audioNote(obs::AudioPhase::Underflow); return NO; }
    // Unity microphone gain avoids pumping when OBS buffers momentarily run dry.
    // OBS adds at 0.70; saturation bounds prevent integer overflow.
    if (!obs::mixNative(scratch.data(), buffers, abl->mNumberBuffers, frames, pcm, 1., .70)) {
        audioNote(obs::AudioPhase::Layout); return NO;
    }
    return YES;
}
CMSampleBufferRef OBCopyAudio(CMSampleBufferRef mic) { return OBCopyAudioForNode(mic, nil); }
CMSampleBufferRef OBCopyAudioForNode(CMSampleBufferRef mic, id node) {
    if (!OBEnabled() || !mic) { audioNote(obs::AudioPhase::Inactive); return nullptr; }
    if (CMGetAttachment(mic, CFSTR("local.xiaoguai.tk.local.mixed"), nullptr)) {
        audioNote(obs::AudioPhase::AlreadyMixed); return nullptr;
    }
    auto format = CMSampleBufferGetFormatDescription(mic);
    const auto *f = format && CMFormatDescriptionGetMediaType(format) == kCMMediaType_Audio ?
        CMAudioFormatDescriptionGetStreamBasicDescription(format) : nullptr;
    CMItemCount count = CMSampleBufferGetNumSamples(mic);
    recordAudioFormat(f, count > 0 && count <= 8192 ? UInt32(count) : 0, 0);
    if (!f || f->mFormatID != kAudioFormatLinearPCM) { audioNote(obs::AudioPhase::Format); return nullptr; }
    if (count <= 0 || count > 8192) { audioNote(obs::AudioPhase::FrameCount); return nullptr; }
    obs::NativePCM pcm = nativeFormat(f);
    if (!pcm.valid() || !std::isfinite(f->mSampleRate) || f->mSampleRate < 8000 || f->mSampleRate > 192000) {
        audioNote(obs::AudioPhase::Layout); return nullptr;
    }
    if (!CMSampleBufferDataIsReady(mic)) { audioNote(obs::AudioPhase::NotReady); return nullptr; }
    __attribute__((objc_precise_lifetime)) OBSystemAudioContext *context = contextForAudio(node);
    std::unique_lock<std::mutex> lock(context->mutex, std::try_to_lock);
    if (!lock.owns_lock()) { audioNote(obs::AudioPhase::Busy); return nullptr; }
    alignas(16) std::array<uint8_t, OBAudioListCapacity> storage{};
    auto *abl = reinterpret_cast<AudioBufferList *>(storage.data());
    BlockOwner original;
    size_t needed = 0;
    OSStatus rc = OBGetAudioBufferList(mic, abl, storage.size(), &needed, &original.block);
    if (rc || !original.block || needed > storage.size() || !abl->mNumberBuffers || abl->mNumberBuffers > 8) {
        audioNote(obs::AudioPhase::BufferList, rc); return nullptr;
    }
    recordAudioFormat(f, UInt32(count), abl->mNumberBuffers);
    obs::PCMBuffer buffers[8];
    for (unsigned i = 0; i < abl->mNumberBuffers; ++i)
        buffers[i] = {abl->mBuffers[i].mData, abl->mBuffers[i].mDataByteSize, abl->mBuffers[i].mNumberChannels};
    if (!obs::nativeLayout(pcm, buffers, abl->mNumberBuffers, size_t(count))) {
        audioNote(obs::AudioPhase::Layout); return nullptr;
    }
    std::vector<uint8_t> copies[8];
    size_t planeBytes = size_t(count) * pcm.frameBytes;
    for (unsigned i = 0; i < abl->mNumberBuffers; ++i) {
        copies[i].resize(planeBytes);
        memcpy(copies[i].data(), abl->mBuffers[i].mData, planeBytes);
        abl->mBuffers[i].mData = copies[i].data(); abl->mBuffers[i].mDataByteSize = UInt32(planeBytes);
    }
    auto mapping = OBBusConsumer();
    if (!mapping) { audioNote(obs::AudioPhase::Inactive); return nullptr; }
    double when = context->cursor.begin(mapping->memory->cookie,
        mapping->data->generation.load(std::memory_order_acquire), OBNow(), size_t(count), f->mSampleRate);
    if (!OBMixABL(abl, UInt32(count), f, when)) return nullptr;
    // Supplying an owned data block before CreateReady avoids incomplete PCM
    // output descriptions. Non-interleaved samples must not have size entries.
    CMSampleBufferRef result = OBCopyMixedAudioSample(mic, abl, &rc);
    if (!result) { audioNote(obs::AudioPhase::Build, rc); return nullptr; }
    CMSetAttachment(result, CFSTR("local.xiaoguai.tk.local.mixed"), kCFBooleanTrue, kCMAttachmentMode_ShouldPropagate);
    audioNote(obs::AudioPhase::Mixed);
    return result;
}
