#import "Receiver.h"
#import "MediaBus.h"
#import "AudioSample.h"
#import "LocalFiles.h"
#import "Shared.h"
#import "LiveAudioStatus.h"
#import <AVFoundation/AVFoundation.h>
#include "core/LocalPlayback.hpp"
#include "core/PendingFrames.hpp"
#include "core/VideoSchedule.hpp"
#include <atomic>
#include <array>
#include <deque>
#include <memory>
#include <mutex>
#include <time.h>

namespace {
struct Image {
    CVPixelBufferRef pixel;
    double due;
    Image(CVPixelBufferRef p, double t) : pixel(CVPixelBufferRetain(p)), due(t) {}
    ~Image() { CVPixelBufferRelease(pixel); }
};
struct Sample {
    CMSampleBufferRef value = nullptr;
    ~Sample() { reset(nullptr); }
    void reset(CMSampleBufferRef next) { if (value) CFRelease(value); value = next; }
    double pts() const { return value ? CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(value)) : INFINITY; }
};
struct Engine {
    std::atomic<bool> enabled{false}, loop{true};
    std::atomic<uint64_t> generation{0}, videos{0}, audioBlocks{0}, audioFrames{0}, published{0}, failed{0}, dropped{0}, loops{0}, rebuffers{0};
    std::atomic<double> lastAudioWrite{0}, lastAudioEnd{0}, inputFPS{0};
    std::atomic<uint32_t> width{0}, height{0};
    std::mutex mutex;
    NSString *__strong message = @"尚未开始播放", *__strong selected = @"";
    AVAssetReader *__strong reader = nil;
    std::deque<std::shared_ptr<Image>> images;
    std::shared_ptr<Image> current, delivered;
    dispatch_queue_t queue = dispatch_queue_create("local.xiaoguai.tk.local.playback", DISPATCH_QUEUE_SERIAL);
    bool active(uint64_t g) const { return enabled.load() && generation.load() == g; }
    void note(uint64_t g, NSString *text) { std::lock_guard<std::mutex> lock(mutex); if (generation == g) message = text; }
};
Engine &engine() { static Engine value; return value; }
void nap(double seconds) {
    timespec delay{0, long(std::max(.0001, std::min(.010, seconds))*1e9)}; nanosleep(&delay, nullptr);
}
bool waitAhead(uint64_t g, double due) {
    auto &e = engine();
    while (e.active(g)) {
        double wait = due - OBNow() - obs::local::Prefetch;
        if (wait <= 0) return true;
        nap(wait);
    }
    return false;
}
struct AudioSample {
    alignas(16) std::array<uint8_t, OBAudioListCapacity> storage{};
    CMBlockBufferRef retained = nullptr;
    const float *samples = nullptr;
    size_t count = 0, offset = 0;
    ~AudioSample() { clear(); }
    void clear() { if (retained) CFRelease(retained); retained = nullptr; samples = nullptr; count = offset = 0; }
    bool load(CMSampleBufferRef sample) {
        clear(); if (!sample) return false;
        auto desc = CMSampleBufferGetFormatDescription(sample);
        const auto *f = desc ? CMAudioFormatDescriptionGetStreamBasicDescription(desc) : nullptr;
        if (!f || f->mFormatID != kAudioFormatLinearPCM || f->mSampleRate != 48000 ||
            !(f->mFormatFlags & kAudioFormatFlagIsFloat) || (f->mFormatFlags & kAudioFormatFlagIsBigEndian) ||
            f->mBitsPerChannel != 32 || f->mChannelsPerFrame != 1 || f->mBytesPerFrame != 4) return false;
        auto *list = reinterpret_cast<AudioBufferList *>(storage.data()); size_t needed = 0;
        if (OBGetAudioBufferList(sample, list, storage.size(), &needed, &retained, nullptr) ||
            list->mNumberBuffers != 1 || !list->mBuffers[0].mData) return false;
        CMItemCount frames = CMSampleBufferGetNumSamples(sample);
        if (frames <= 0 || uint64_t(frames) > list->mBuffers[0].mDataByteSize/4) return false;
        count = size_t(frames); samples = static_cast<const float *>(list->mBuffers[0].mData); return true;
    }
};
void finish(uint64_t g, NSString *message) {
    auto &e = engine(); std::lock_guard<std::mutex> lock(e.mutex);
    if (e.generation != g) return;
    e.enabled = false; e.reader = nil; e.images.clear(); e.current.reset(); e.delivered.reset();
    OBBusEnable(NO); e.message = message;
}
void play(NSString *name, uint64_t g) {
    auto &e = engine(); if (!e.active(g)) return;
    NSString *invalid = OBValidateManagedFile(name);
    if (invalid) { finish(g, invalid); return; }
    NSURL *url = [NSURL fileURLWithPath:OBManagedPath(name)];
    obs::local::PlaybackClock clock;
    bool firstCycle = true;
    do {
        @autoreleasepool {
            if (!e.active(g)) return;
            AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:nil];
            AVAssetTrack *video = [asset tracksWithMediaType:AVMediaTypeVideo].firstObject;
            AVAssetTrack *audio = [asset tracksWithMediaType:AVMediaTypeAudio].firstObject;
            CMFormatDescriptionRef vf = video.formatDescriptions.count ? (__bridge CMFormatDescriptionRef)video.formatDescriptions.firstObject : nullptr;
            CMFormatDescriptionRef af = audio.formatDescriptions.count ? (__bridge CMFormatDescriptionRef)audio.formatDescriptions.firstObject : nullptr;
            if (!vf || !af || CMFormatDescriptionGetMediaSubType(vf) != kCMVideoCodecType_H264 ||
                CMFormatDescriptionGetMediaSubType(af) != kAudioFormatMPEG4AAC) {
                finish(g, @"素材需要 H.264 视频和 AAC 声音"); return;
            }
            CMVideoDimensions dimensions = CMVideoFormatDescriptionGetDimensions(vf);
            bool capacityOK = false;
            {
                std::lock_guard<std::mutex> lock(e.mutex); if (!e.active(g)) return;
                CGRect bounds=CGRectApplyAffineTransform(CGRectMake(0,0,dimensions.width,dimensions.height),video.preferredTransform);
                double w=std::round(bounds.size.width),h=std::round(bounds.size.height);
                if(dimensions.width>0 && dimensions.height>0 && std::isfinite(w) && std::isfinite(h) &&
                   w>0 && h>0 && w<=UINT32_MAX/4 && h<=UINT32_MAX && w*h<=double(SIZE_MAX/12)) {
                    size_t pixels=std::max(size_t(dimensions.width)*size_t(dimensions.height),size_t(w)*size_t(h));
                    capacityOK=OBBusPrepareVideo(pixels);
                }
            }
            if (!capacityOK) {
                finish(g, @"视频超出本机缓存资源预算"); return;
            }
            NSError *error = nil;
            AVAssetReader *reader = [[AVAssetReader alloc] initWithAsset:asset error:&error];
            NSDictionary *videoSettings = @{(id)kCVPixelBufferPixelFormatTypeKey: @(kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange),
                (id)kCVPixelBufferIOSurfacePropertiesKey: @{}};
            NSDictionary *audioSettings = @{AVFormatIDKey: @(kAudioFormatLinearPCM), AVSampleRateKey: @48000,
                AVNumberOfChannelsKey: @1, AVLinearPCMBitDepthKey: @32, AVLinearPCMIsFloatKey: @YES,
                AVLinearPCMIsBigEndianKey: @NO, AVLinearPCMIsNonInterleaved: @NO};
            AVAssetReaderTrackOutput *vo = [AVAssetReaderTrackOutput assetReaderTrackOutputWithTrack:video outputSettings:videoSettings];
            AVAssetReaderTrackOutput *ao = [AVAssetReaderTrackOutput assetReaderTrackOutputWithTrack:audio outputSettings:audioSettings];
            vo.alwaysCopiesSampleData = NO; ao.alwaysCopiesSampleData = NO;
            if (!reader || ![reader canAddOutput:vo] || ![reader canAddOutput:ao]) {
                finish(g, error.localizedDescription ?: @"无法建立系统音视频解码器"); return;
            }
            [reader addOutput:vo]; [reader addOutput:ao];
            {
                std::lock_guard<std::mutex> lock(e.mutex); if (!e.active(g)) return;
                e.reader = reader;
                // File orientation is applied before the existing sensor transform.
                OBBusSetSourceTransform(video.preferredTransform);
                e.inputFPS = video.nominalFrameRate;
            }
            if (![reader startReading]) { finish(g, reader.error.localizedDescription ?: @"素材解码启动失败"); return; }
            Sample vs, as; AudioSample pcm;
            vs.reset([vo copyNextSampleBuffer]); as.reset([ao copyNextSampleBuffer]);
            double first = std::min(vs.pts(), as.pts());
            double previousEnd=clock.end; bool nextLoop=!firstCycle;
            if (!std::isfinite(first) || !clock.begin(first, OBNow(), nextLoop)) { finish(g, @"素材没有有效时间戳"); return; }
            if(nextLoop && clock.host>previousEnd+.005) {
                std::lock_guard<std::mutex> lock(e.mutex);if(!e.active(g))return;
                ++e.rebuffers;e.images.clear();e.current.reset();e.delivered.reset();OBBusResetAudio();
            }
            firstCycle = false;
            if (as.value && !pcm.load(as.value)) { finish(g, @"系统未能输出 48kHz 单声道浮点 PCM"); return; }
            bool madeProgress = false;
            while (e.active(g) && (vs.value || as.value)) {
                @autoreleasepool {
                    double ap = as.value ? as.pts() + double(pcm.offset)/48000. : INFINITY;
                    double vp = vs.pts(); bool isVideo = vp <= ap; double pts = isVideo ? vp : ap;
                    if (!std::isfinite(pts)) { finish(g, @"素材包含无效时间戳"); return; }
                    if (clock.late(pts, OBNow())) {
                        std::lock_guard<std::mutex> lock(e.mutex); if (!e.active(g)) return;
                        clock.rebuffer(pts, OBNow()); ++e.rebuffers;
                        e.images.clear(); e.current.reset(); e.delivered.reset(); OBBusResetAudio();
                    }
                    const double due = clock.due(pts);
                    if (!waitAhead(g, due)) { [reader cancelReading]; return; }
                    if (isVideo) {
                        CVPixelBufferRef pixel = CMSampleBufferGetImageBuffer(vs.value);
                        if (!pixel) { finish(g, @"视频解码没有输出画面"); return; }
                        size_t w = CVPixelBufferGetWidth(pixel), h = CVPixelBufferGetHeight(pixel);
                        if (!w || !h || w > SIZE_MAX/h/4) { finish(g, @"视频尺寸无效"); return; }
                        {
                            std::lock_guard<std::mutex> lock(e.mutex); if (!e.active(g)) return;
                            e.width = uint32_t(w); e.height = uint32_t(h);
                            const size_t capacity = size_t(std::max(uint64_t(1), NSProcessInfo.processInfo.physicalMemory/8/(uint64_t(w)*h*4)));
                            if (obs::enqueuePending(e.images, std::make_shared<Image>(pixel, due), capacity)) OBRequestVideoTick();
                            else ++e.dropped;
                            ++e.videos;
                        }
                        double duration = CMTimeGetSeconds(CMSampleBufferGetDuration(vs.value));
                        if (!std::isfinite(duration) || duration <= 0) duration = 1./std::max(1., double(video.nominalFrameRate));
                        clock.observe(pts, duration); vs.reset([vo copyNextSampleBuffer]);
                    } else {
                        size_t count = std::min(size_t(1024), pcm.count - pcm.offset);
                        if (!count) { finish(g, @"素材音频数据为空"); return; }
                        {
                            std::lock_guard<std::mutex> lock(e.mutex); if (!e.active(g)) return;
                            OBBusWriteAudio(pcm.samples+pcm.offset, count, due);
                            ++e.audioBlocks; e.audioFrames += count;
                            e.lastAudioWrite = OBNow(); e.lastAudioEnd = due+double(count)/48000.;
                        }
                        clock.observe(pts, double(count)/48000.); pcm.offset += count;
                        if (pcm.offset == pcm.count) {
                            pcm.clear(); as.reset([ao copyNextSampleBuffer]);
                            if (as.value && !pcm.load(as.value)) { finish(g, @"音频 PCM 布局发生变化"); return; }
                        }
                    }
                    if (!madeProgress) { e.note(g, @"本地播放中"); madeProgress = true; }
                }
            }
            if (!e.active(g)) return;
            if (reader.status == AVAssetReaderStatusFailed) { finish(g, reader.error.localizedDescription ?: @"读取素材失败"); return; }
            if (!madeProgress) { finish(g, @"素材未输出可播放内容"); return; }
            if (!e.loop) {
                while (e.active(g) && OBNow() < clock.end) nap(clock.end - OBNow());
                finish(g, @"播放结束，已恢复摄像头"); return;
            }
            ++e.loops;
        }
    } while (e.active(g));
}
}
BOOL OBEnabled(void) { return engine().enabled.load(); }
void OBSetLocalLoop(BOOL loop) { engine().loop = loop; }
void OBStartLocal(NSString *name, BOOL loop) {
    OBStop(); auto &e = engine(); uint64_t g = ++e.generation;
    e.videos = 0; e.audioBlocks = 0; e.audioFrames = 0; e.published = 0; e.failed = 0; e.dropped = 0;
    e.loops = 0; e.rebuffers = 0; e.lastAudioWrite = 0; e.lastAudioEnd = 0; e.width = 0; e.height = 0; e.loop = loop;
    { std::lock_guard<std::mutex> lock(e.mutex); e.selected = name ?: @""; e.message = @"正在准备本地素材"; }
    OBBusEnable(YES); e.enabled = true;
    dispatch_async(e.queue, ^{ @autoreleasepool { play(name, g); } });
}
void OBStop(void) {
    auto &e = engine(); e.enabled = false; ++e.generation;
    AVAssetReader *reader;
    {
        std::lock_guard<std::mutex> lock(e.mutex); reader = e.reader; e.reader = nil;
        e.images.clear(); e.current.reset(); e.delivered.reset(); OBBusEnable(NO); e.message = @"已停止，已恢复摄像头";
    }
    [reader cancelReading];
}
void OBProducerTick(void) {
    OBBusHeartbeat(); auto &e=engine();
    std::shared_ptr<Image> frame;uint64_t g=0;
    {
        std::lock_guard<std::mutex> lock(e.mutex);if(!e.enabled)return;
        double now=OBNow();
        while(!e.images.empty() && e.images.front()->due<=now){e.current=e.images.front();e.images.pop_front();}
        if(e.current && e.current!=e.delivered && now-e.current->due<.5){frame=e.current;g=e.generation.load();}
    }
    if(!frame)return;
    // Expensive CI/pixel publishing must not hold the file/audio scheduling lock.
    BOOL ok=OBBusPublishVideo(frame->pixel,frame->due);
    std::lock_guard<std::mutex> lock(e.mutex);
    if(e.active(g) && e.current==frame){if(ok){++e.published;e.delivered=frame;}else ++e.failed;}
}

double OBProducerDelay(void) {
    auto &e = engine(); std::lock_guard<std::mutex> lock(e.mutex);
    return e.enabled ? obs::nextVideoDelay(e.images, OBNow()) : .5;
}
NSString *OBSummary(void) {
    auto &e = engine(); std::lock_guard<std::mutex> lock(e.mutex);
    return e.enabled && e.width ? [NSString stringWithFormat:@"%@\n%u × %u · %.3g fps", e.message, e.width.load(), e.height.load(), e.inputFPS.load()] : e.message;
}
NSString *OBStatus(void) {
    auto &e = engine(); std::lock_guard<std::mutex> lock(e.mutex); double now = OBNow();
    return [NSString stringWithFormat:@"tk 本地文件版 %@\n%@\n素材 %@\n视频 %llu / 音频块 %llu / 音频样本 %llu\n发布 %llu / 失败 %llu / 队列 %zu / 丢帧 %llu\n循环 %llu / 重新缓冲 %llu\n最近写音频距今 %.1f ms / 音频写入末端提前 %.1f ms\n源 %u×%u / %.3g fps；热状态 %ld\n%@\n\n%@\n\n%@",
        OB_VERSION, e.message, e.selected, (unsigned long long)e.videos.load(), (unsigned long long)e.audioBlocks.load(),
        (unsigned long long)e.audioFrames.load(), (unsigned long long)e.published.load(), (unsigned long long)e.failed.load(),
        e.images.size(), (unsigned long long)e.dropped.load(), (unsigned long long)e.loops.load(), (unsigned long long)e.rebuffers.load(),
        e.lastAudioWrite ? (now-e.lastAudioWrite.load())*1000. : -1., e.lastAudioEnd ? (e.lastAudioEnd.load()-now)*1000. : -1.,
        e.width.load(), e.height.load(), e.inputFPS.load(), (long)NSProcessInfo.processInfo.thermalState,
        OBBusProducerStatus(), OBMediaStatus(), OBLiveAudioStatus()];
}
#if OB_LOCAL_TEST
void OBLocalTestDrain(void) { dispatch_sync(engine().queue, ^{}); }
#endif
