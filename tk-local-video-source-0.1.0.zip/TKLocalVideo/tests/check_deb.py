"""Check actual .deb payloads, not just source-tree files. No extraction to disk."""
import io
import plistlib
import struct
import sys
import tarfile
from pathlib import Path, PurePosixPath


def payload(path, with_metadata=False):
    raw = Path(path).read_bytes()
    if raw[:8] != b"!<arch>\n":
        raise ValueError("not a Debian ar archive")
    offset = 8
    result = {}
    metadata = {}
    while offset < len(raw):
        header = raw[offset:offset + 60]
        if len(header) != 60 or header[-2:] != b"`\n":
            raise ValueError("invalid ar header")
        name = header[:16].decode("ascii").strip().rstrip("/")
        size = int(header[48:58])
        start = offset + 60
        if start + size > len(raw):
            raise ValueError("truncated ar member")
        if name.startswith("data.tar"):
            with tarfile.open(fileobj=io.BytesIO(raw[start:start + size])) as archive:
                for member in archive.getmembers():
                    if not member.isfile():
                        continue
                    key = PurePosixPath(member.name).as_posix().removeprefix("./")
                    result[key] = archive.extractfile(member).read()
                    metadata[key] = (member.uid, member.gid, member.mode)
        offset = start + size + size % 2
    return (result, metadata) if with_metadata else result


def check(path):
    files, metadata = payload(path, with_metadata=True)
    prefix = "var/jb/Library/"
    required = [
        "MobileSubstrate/DynamicLibraries/OBSBridge.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridge.plist",
        "MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist",
        "PreferenceBundles/OBSBridgePrefs.bundle/OBSBridgePrefs",
        "PreferenceBundles/OBSBridgePrefs.bundle/Info.plist",
        "PreferenceBundles/OBSBridgePrefs.bundle/Root.plist",
        "PreferenceLoader/Preferences/OBSBridge.plist",
        "libSandy/local.xiaoguai.tk.local.media-read.plist",
        "MobileSubstrate/DynamicLibraries/OBSBridgeLive.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridgeLive.plist",
        "libSandy/local.xiaoguai.tk.local.live-read.plist",
    ]
    app = "var/jb/Applications/TKLocalVideo.app/"
    missing = [prefix + name for name in required if prefix + name not in files]
    missing += [app+name for name in ("TKLocalVideo","Info.plist") if app+name not in files]
    if missing:
        raise ValueError("missing packaged files: " + ", ".join(missing))
    profile_key = prefix + required[8]
    uid, gid, mode = metadata[profile_key]
    if uid != 0 or gid != 0 or mode & 0o022:
        raise ValueError(f"libSandy profile must be root:root and not writable by group/others; actual uid={uid}, gid={gid}, mode={mode:04o}")
    profile = plistlib.loads(files[profile_key])
    if profile.get("AllowedProcesses") != ["com.apple.mediaserverd"] or profile.get("Extensions") != [
        {"type": "file", "extension_class": "com.apple.app-sandbox.read",
         "path": "/var/mobile/Library/Preferences/local.xiaoguai.tk.local.media-local-v1.dat"}]:
        raise ValueError("libSandy profile is missing/nonspecific or grants more than the media read path")
    daemon = plistlib.loads(files[prefix + required[1]])
    shortcut = plistlib.loads(files[prefix + required[3]])
    if daemon.get("Filter") != {"Executables": ["mediaserverd"]}:
        raise ValueError("incorrect media-service filter")
    if shortcut.get("Filter") != {"Bundles": ["com.apple.springboard"]}:
        raise ValueError("incorrect SpringBoard filter")
    for name in [prefix+required[0], prefix+required[2], prefix+required[4], prefix+required[9], app+"TKLocalVideo"]:
        raw = files[name]
        if raw[:4] != b"\xca\xfe\xba\xbe" or len(raw) < 8:
            raise ValueError("expected universal arm64/arm64e Mach-O: " + name)
        count = struct.unpack_from(">I", raw, 4)[0]
        archs = []
        for i in range(count):
            cpu, subtype, start, size, align = struct.unpack_from(">IIIII", raw, 8 + 20 * i)
            if start + size > len(raw) or raw[start:start + 4] != b"\xcf\xfa\xed\xfe":
                raise ValueError("invalid Mach-O slice: " + name)
            archs.append((cpu, subtype & 0xffffff))
        if (0x0100000c, 0) not in archs or (0x0100000c, 2) not in archs:
            raise ValueError("missing arm64/arm64e architecture: " + name)
    media = files[prefix + required[0]]
    receiver = files[prefix + required[2]]
    if b"BWNodeOutput" not in media or b"emitSampleBuffer:" not in media:
        raise ValueError("media dylib is not the v2 node consumer")
    if b"local.xiaoguai.tk.local.playback" not in receiver:
        raise ValueError("SpringBoard dylib does not contain the independent local player")
    marker = b"local.xiaoguai.tk.local.media-local-v1.dat"
    if marker not in media or marker not in receiver:
        raise ValueError("missing v6 read-only-consumer transport in one or both modules")
    if b"libSandy_applyProfile" not in media:
        raise ValueError("missing scoped libSandy integration in media module")
    if b"local.xiaoguai.tk.local.v6.audio.phase" not in media or b"local.xiaoguai.tk.local.v6.audio.phase" not in receiver:
        raise ValueError("missing native-audio diagnostics in one or both modules")
    live = plistlib.loads(files[prefix + required[10]])
    if live.get("Filter") != {"Bundles": ["com.zhiliaoapp.musically"]}:
        raise ValueError("incorrect TikTok live audio filter")
    profile_key = prefix + required[11]
    uid, gid, mode = metadata[profile_key]
    if uid != 0 or gid != 0 or mode & 0o022:
        raise ValueError("live libSandy profile must be root:root and not writable by group/others")
    live_profile = plistlib.loads(files[profile_key])
    if live_profile.get("AllowedProcesses") != ["com.zhiliaoapp.musically"] or live_profile.get("Extensions") != [
        {"type": "file", "extension_class": "com.apple.app-sandbox.read", "path": "/var/mobile/Library/Preferences/local.xiaoguai.tk.local.media-local-v1.dat"}]:
        raise ValueError("live libSandy profile grants more than TikTok read-only media")
    app_audio = files[prefix + required[9]]
    for marker in (b"local.xiaoguai.tk.local.live.audio", b"AudioUnitRender", b"libSandy_applyProfile", b"local.xiaoguai.tk.local.live.mapping", b"local.xiaoguai.tk.local.media-local-v1.dat"):
        if marker not in app_audio:
            raise ValueError("missing live audio entry integration: " + marker.decode())
    info = plistlib.loads(files[app+"Info.plist"])
    if info.get("CFBundleIdentifier") != "local.xiaoguai.tk.local.control" or info.get("CFBundleExecutable") != "TKLocalVideo":
        raise ValueError("incorrect local control app identity")
    for marker in (b"AVAssetReader", b"copyNextSampleBuffer"):
        if marker not in receiver: raise ValueError("missing native local playback integration")
    for marker in (b"OBLocalImport",b"UIDocumentPickerViewController"):
        if marker not in files[app+"TKLocalVideo"]: raise ValueError("missing local file importer")
    if b"local.xiaoguai.tk.local.live.position" not in app_audio:
        raise ValueError("missing local audio position diagnostics")
    return len(files)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: check_deb.py PACKAGE.deb [...]")
    for name in sys.argv[1:]:
        try:
            count = check(name)
        except (ValueError, OSError, tarfile.TarError, struct.error) as error:
            raise SystemExit(f"PACKAGE CHECK FAILED: {name}: {error}")
        print(f"PASS: {Path(name).name}: {count} files; v6 read-only transport + media consumer + independent local player + settings present")
