// Actual AVAssetReader playback on macOS. No injection, TikTok or iPhone claims.
#ifdef NDEBUG
#undef NDEBUG
#endif
#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import "../Receiver.h"
#import "../MediaBus.h"
#import "../LocalFiles.h"
#import "../LiveAudioStatus.h"
#include <cassert>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <unistd.h>

namespace {
std::unique_ptr<obs::SharedMedia> media;
std::atomic<uint64_t> frames{0},samples{0};
double lastEnd=0,maximumGap=0;
void run(double seconds) {
    double until=OBNow()+seconds;
    while(OBNow()<until) { OBProducerTick(); usleep(2000); }
}
}
double OBNow(void) { return CMTimeGetSeconds(CMClockGetTime(CMClockGetHostTimeClock())); }
void OBBusHeartbeat(void) { media->heartbeatUS=uint64_t(OBNow()*1e6); }
void OBBusEnable(BOOL enabled) { media->enabled=enabled; if(!enabled)media->resetAudio(); }
void OBBusResetAudio(void) { ++media->generation;media->resetAudio(); }
BOOL OBBusPrepareVideo(size_t count) { return count>0; }
void OBBusSetSourceTransform(CGAffineTransform transform) { assert(std::isfinite(transform.a)); }
BOOL OBBusPublishVideo(CVPixelBufferRef pixel,double due) {
    assert(pixel && CVPixelBufferGetWidth(pixel)>=320 && CVPixelBufferGetWidth(pixel)<=352 &&
        CVPixelBufferGetHeight(pixel)>=180 && CVPixelBufferGetHeight(pixel)<=208); // allow codec padding
    assert(due<=OBNow()+.01);++frames;return YES;
}
void OBBusWriteAudio(const float *source,size_t count,double due) {
    assert(count>0 && count<=1024);assert(due<=OBNow()+.31);
    if(lastEnd)maximumGap=std::max(maximumGap,due-lastEnd);
    lastEnd=due+double(count)/48000.;media->writeAudio(source,count,due);samples+=count;
}
void OBRequestVideoTick(void) {}
NSString *OBBusProducerStatus(void) { return @"native-test stub"; }
NSString *OBMediaStatus(void) { return @"native-test stub"; }
NSString *OBLiveAudioStatus(void) { return @"native-test stub, no TikTok"; }
int main(int argc,char **argv) {
    @autoreleasepool {
        assert(argc==3);setenv("OB_LOCAL_TEST_LIBRARY",argv[2],1);
        assert(!OBPrepareLibrary());
        NSString *name=[NSUUID.UUID.UUIDString stringByAppendingString:@".mp4"];
        NSError *error=nil;
        assert([NSFileManager.defaultManager copyItemAtPath:[NSString stringWithUTF8String:argv[1]] toPath:OBManagedPath(name) error:&error]);
        media=std::make_unique<obs::SharedMedia>();media->initialize();media->generation=1;
        OBStartLocal(name,NO);double started=OBNow();uint64_t readable=0,nonzero=0;
        std::array<float,480> pcm{};std::array<uint8_t,480> validity{};
        while(OBNow()-started<6. && OBEnabled()) {
            OBProducerTick();double now=OBNow();
            auto c=media->readAudioCovered(pcm.data(),validity.data(),480,now,48000,uint64_t(now*1e6));
            if(c.found) { ++readable;for(float value:pcm)if(std::fabs(value)>.001){++nonzero;break;} }
            usleep(2000);
        }
        assert(!OBEnabled() && frames>=50 && samples>=90000 && readable>100 && nonzero>100);
        std::fprintf(stderr,"PASS native finite local playback: video=%llu PCM=%llu readable-polls=%llu\n",
            (unsigned long long)frames.load(),(unsigned long long)samples.load(),(unsigned long long)readable);
        frames=0;samples=0;lastEnd=maximumGap=0;
        OBStartLocal(name,YES);run(5.5);assert(OBEnabled() && frames>=120 && samples>=200000);
        OBStop();uint64_t stopped=frames.load();run(.1);assert(frames==stopped);
#if OB_LOCAL_TEST
        OBLocalTestDrain();
#endif
        assert(maximumGap<.080);
        std::fprintf(stderr,"PASS native looping local playback and stop: maximum adjacent audio gap %.3f ms\n",maximumGap*1000.);
        assert([NSFileManager.defaultManager removeItemAtPath:OBManagedPath(name) error:&error]);
    }
}
