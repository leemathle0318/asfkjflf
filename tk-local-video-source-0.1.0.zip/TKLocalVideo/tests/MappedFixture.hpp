#pragma once
#include "../core/MappedMedia.hpp"
#include <memory>
#include <new>
namespace fixture {
constexpr size_t Pixels = 4096;
constexpr size_t Bytes = obs::MappedMedia::allocationBytes(Pixels);
struct Delete {
    void operator()(obs::MappedMedia *p) const {
        p->~MappedMedia(); ::operator delete(p, std::align_val_t(alignof(obs::MappedMedia)));
    }
};
inline auto make(size_t pixels = Pixels) {
    const size_t bytes = obs::MappedMedia::allocationBytes(pixels);
    auto *memory = ::operator new(bytes, std::align_val_t(alignof(obs::MappedMedia)));
    std::unique_ptr<obs::MappedMedia, Delete> result(new(memory) obs::MappedMedia);
    result->initialize(77, pixels); return result;
}
}
