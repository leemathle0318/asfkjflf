"""Local-file source boundaries; device behavior requires separate validation."""
from pathlib import Path
import plistlib, unittest
ROOT=Path(__file__).resolve().parents[1]
class Project(unittest.TestCase):
 def test_plists(self):
  for p in ROOT.rglob('*.plist'):
   if any(x in ('work','vendor') for x in p.relative_to(ROOT).parts):continue
   self.assertIsInstance(plistlib.loads(p.read_bytes()),dict,p)
 def test_identity_and_conflict(self):
  c=(ROOT/'control').read_text();self.assertIn('Package: local.xiaoguai.tk.local',c)
  self.assertIn('Conflicts: local.xiaoguai.obsbridge',c);self.assertIn('Replaces: local.xiaoguai.obsbridge',c)
  self.assertIn('Name: tk推流助手（本地文件版）',c)
 def test_native_player_not_network(self):
  m=(ROOT/'Makefile').read_text();s=(ROOT/'LocalPlayer.mm').read_text()
  self.assertIn('LocalPlayer.mm',m);self.assertNotIn('-lavformat',m);self.assertNotIn('Receiver.mm',m)
  for token in ('AVAssetReader','alwaysCopiesSampleData = NO','copyNextSampleBuffer','waitAhead','PlaybackClock','OBBusWriteAudio','OBBusPrepareVideo'):
   self.assertIn(token,s)
  self.assertNotIn('AVPlayer play',s)
 def test_fixed_memory_import(self):
  s=(ROOT/'LocalImport.mm').read_text();ui=(ROOT/'controlapp/main.mm').read_text()
  self.assertIn('1024 * 1024',s);self.assertIn('copyChunks',s);self.assertIn('QOS_CLASS_UTILITY',s)
  self.assertIn('fsync(output)',s);self.assertIn('rename(temporary',s)
  self.assertIn('stopAccessingSecurityScopedResource',s);self.assertIn('coordinateReadingItemAtURL',s)
  self.assertNotIn('dataWithContentsOfFile',s);self.assertIn('asCopy:NO',ui);self.assertIn('UTTypeMPEG4Movie',ui)
 def test_audio_rt_boundary(self):
  s=(ROOT/'AppAudio.mm').read_text();hot=s.split('bool addOBS(',1)[1].split('OSStatus create(',1)[0]
  for bad in ('notify_', 'NSLog(', 'OBBusConsumer(', 'std::lock_guard','new ', 'AudioUnitGetProperty(', 'dispatch_'):
   self.assertNotIn(bad,hot)
  self.assertIn('realtimeMapping.tryRead()',hot);self.assertIn('DisciplinedAudioCursor',s)
  self.assertIn('readAudioCovered',hot);self.assertIn('unit.cursor.initialized=false',hot)
  self.assertNotIn('MaximumMappings',s);self.assertIn('!candidate.alive.load',s)
  self.assertIn('realtimeMapping.replace',s)
 def test_native_mic_preserved(self):
  s=(ROOT/'AppAudio.mm').read_text();self.assertIn('originalRender(handle, flags, time, bus, frames, data)',s)
  self.assertIn('obs::liveRender',s);self.assertIn('pcm,1.,.70',s)
  self.assertIn('OBProgramAudioEnabled() && !OBLiveAudioOwnsCapture()',(ROOT/'SystemHooks.mm').read_text())
 def test_sandbox_scope(self):
  for kind,process in [('media','com.apple.mediaserverd'),('live','com.zhiliaoapp.musically')]:
   p=ROOT/('layout/Library/libSandy/local.xiaoguai.tk.local.'+kind+'-read.plist');d=plistlib.loads(p.read_bytes())
   self.assertEqual(d['AllowedProcesses'],[process]);self.assertEqual(d['Extensions'],[{'type':'file','extension_class':'com.apple.app-sandbox.read','path':'/var/mobile/Library/Preferences/local.xiaoguai.tk.local.media-local-v1.dat'}])
  consumer=(ROOT/'MediaBus.mm').read_text().split('std::shared_ptr<OBMapping> OBBusConsumer(',1)[1]
  self.assertNotIn('PROT_WRITE',consumer);self.assertIn('PROT_READ, MAP_SHARED',consumer)
 def test_filters(self):
  for f,key,value in [('OBSBridge.plist','Executables','mediaserverd'),('OBSBridgeSB.plist','Bundles','com.apple.springboard'),('OBSBridgeLive.plist','Bundles','com.zhiliaoapp.musically')]:
   self.assertEqual(plistlib.loads((ROOT/f).read_bytes())['Filter'],{key:[value]})
 def test_build_inputs_lf(self):
  for n in ('Makefile','control','prefs/Makefile','controlapp/Makefile','scripts/prepare_packaging.py','layout/DEBIAN/postinst'):
   raw=(ROOT/n).read_bytes();self.assertNotIn(b'\r',raw);self.assertTrue(raw.endswith(b'\n'))
 def test_never_auto_start_saved_request(self):
  s=(ROOT/'Producer.mm').read_text();self.assertIn('lastRequest = request',s);self.assertIn('fabs(date.timeIntervalSinceNow) > 15',s)
  self.assertIn('OBCSaveSelection',(ROOT/'LocalImport.h').read_text()+(ROOT/'controlapp/main.mm').read_text())
 def test_timing_resource_bounds(self):
  s=(ROOT/'LocalPlayer.mm').read_text();self.assertNotIn('1920 * 1080',s);self.assertNotIn('VideoProfile',s)
  self.assertIn('clock.observe',s);self.assertIn('clock.rebuffer',s);self.assertIn('clock.end',s)
  self.assertIn('physicalMemory/8',s)
 def test_directory_boundaries(self):
  s=(ROOT/'LocalFiles.mm').read_text();self.assertIn('lstat',s);self.assertIn('managedName',s);self.assertIn('S_ISREG',s)
  post=(ROOT/'layout/DEBIAN/postinst').read_text();self.assertNotIn('rm -r',post);self.assertNotIn('chown -R',post)
if __name__=='__main__':unittest.main(verbosity=2)
