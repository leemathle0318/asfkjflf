#include "MappedFixture.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <new>
#include <thread>
#include <chrono>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#else
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#endif
using obs::MappedMedia;
static bool inspect(const MappedMedia *bus) {
    if (!bus || !bus->valid(77, fixture::Bytes)) return false;
    std::vector<uint8_t> pixels(24);
    float audio[2]{};
    obs::FrameTicket ticket{};
    return obs::captureFrame(*bus, 0, 10000000, ticket) &&
        obs::copyFrame(*bus, ticket, 10000000, pixels.data(), 12, pixels.size()) &&
        pixels[0] == 17 && pixels[8] == 0 && pixels[12] == 33 &&
        bus->state.readAudio(audio, 2, 10, 48000, 10000000) && audio[0] == .5f && audio[1] == -.5f;
}
static void prepare(MappedMedia *bus) {
    bus->initialize(77, fixture::Pixels); bus->state.enabled = 1; bus->state.generation = 1; bus->state.heartbeatUS = 10000000;
    const uint8_t pixels[] = {17,18,19,20,21,22,23,24, 0,0,0,0, 33,34,35,36,37,38,39,40, 0,0,0,0};
    auto &slot = bus->state.video[0]; assert(obs::acquireWriter(slot));
    obs::beginFrameWrite(slot);
    assert(bus->frames[0].write(pixels, 12, 2, 2)); slot.surface = 1; slot.sequence = 1; slot.generation = 1; slot.dueUS = 10000000;
    obs::releaseWriter(slot);
    float audio[] = {.5f,-.5f}; bus->state.writeAudio(audio, 2, 10);
}
#ifdef _WIN32
int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    if (argc == 3 && std::wstring(argv[1]) == L"--file-child") {
        HANDLE file = CreateFileW(argv[2], GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) return 10;
        HANDLE map = CreateFileMappingW(file, nullptr, PAGE_READONLY, 0, fixture::Bytes, nullptr);
        auto *bus = map ? static_cast<const MappedMedia *>(MapViewOfFile(map, FILE_MAP_READ, 0, 0, fixture::Bytes)) : nullptr;
        bool ok = inspect(bus);
        if (bus) UnmapViewOfFile(bus); if (map) CloseHandle(map); CloseHandle(file); return ok ? 0 : 11;
    }
#else
int main() {
#endif
    auto unit = fixture::make(); prepare(unit.get());
    assert(!unit->valid(0, fixture::Bytes) && !unit->valid(78, fixture::Bytes));
    auto &raw = unit->frames[0]; uint8_t tooSmall[7]{};
    assert(!raw.copy(raw.geometry(), tooSmall, 8, sizeof(tooSmall)));
    assert(!raw.write(tooSmall, 8, 1281, 1));
    uint32_t saved = raw.stride; raw.stride = 0; assert(!raw.valid()); raw.stride = saved;
    obs::FrameTicket stale{};
    assert(obs::captureFrame(*unit, 0, 10000000, stale));
    obs::beginFrameWrite(unit->state.video[0]);
    assert(!obs::frameUnchanged(*unit, stale, 10000000));
    unit->state.video[0].sequence.store(2, std::memory_order_release);
    assert(!obs::frameUnchanged(*unit, stale, 10000000));
    unit->state.generation = 2; assert(!obs::frameUnchanged(*unit, stale, 10000000));
    prepare(unit.get());
    // All payload words are atomic: concurrent writes cannot create a C++ data
    // race, and accepted snapshots must contain one whole generation/pattern.
    std::atomic<bool> done{false};
    std::thread writer([&] {
        std::vector<uint8_t> image(64*64*4);
        for (uint32_t sequence = 2; sequence < 5002; ++sequence) {
            auto &slot = unit->state.video[0];
            assert(obs::acquireWriter(slot)); obs::beginFrameWrite(slot);
            uint8_t value = sequence % 2 ? 0x33 : 0x77; std::fill(image.begin(), image.end(), value);
            assert(unit->frames[0].write(image.data(), 64*4, 64, 64));
            slot.sequence.store(sequence, std::memory_order_release); obs::releaseWriter(slot);
            if (sequence % 32 == 0) std::this_thread::sleep_for(std::chrono::microseconds(100));
        }
        done = true;
    });
    std::vector<uint8_t> snapshot(64*64*4);
    unsigned accepted = 0;
    while (!done.load()) {
        obs::FrameTicket ticket{};
        if (!obs::captureFrame(*unit, 0, 10000000, ticket) || ticket.sequence == 1) continue;
        if (obs::copyFrame(*unit, ticket, 10000000, snapshot.data(), 64*4, snapshot.size())) {
            ++accepted;
            uint8_t expected = ticket.sequence % 2 ? 0x33 : 0x77;
            for (uint8_t value : snapshot) assert(value == expected);
        }
    }
    writer.join();
    assert(accepted > 0);
    std::printf("PASS: 5000 concurrent frame versions; %u accepted untorn snapshots; stale/stop rejection\n", accepted);
    obs::FrameTicket final{}; assert(obs::captureFrame(*unit, 0, 10000000, final));
    assert(obs::copyFrame(*unit, final, 10000000, snapshot.data(), 64*4, snapshot.size()));
    unit->state.enabled = 0;
    assert(!obs::copyFrame(*unit, final, 10000000, snapshot.data(), 64*4, snapshot.size()));
#ifdef _WIN32
    wchar_t folder[MAX_PATH], path[MAX_PATH]; assert(GetTempPathW(MAX_PATH, folder));
    assert(GetTempFileNameW(folder, L"obm", 0, path));
    HANDLE file = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_TEMPORARY, nullptr); assert(file != INVALID_HANDLE_VALUE);
    HANDLE map = CreateFileMappingW(file, nullptr, PAGE_READWRITE, 0, fixture::Bytes, nullptr); assert(map);
    auto *shared = static_cast<MappedMedia *>(MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, fixture::Bytes)); assert(shared);
    prepare(new (shared) MappedMedia);
    wchar_t exe[32768]; assert(GetModuleFileNameW(nullptr, exe, 32768));
    std::wstring command = L"\"" + std::wstring(exe) + L"\" --file-child \"" + std::wstring(path) + L"\"";
    STARTUPINFOW startup{}; startup.cb = sizeof(startup); PROCESS_INFORMATION process{};
    assert(CreateProcessW(nullptr, command.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process));
    assert(WaitForSingleObject(process.hProcess, 10000) == WAIT_OBJECT_0);
    DWORD result = 99; assert(GetExitCodeProcess(process.hProcess, &result)); assert(result == 0);
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
#else
    char path[] = "/tmp/obsbridge-file-XXXXXX";
    int fd = mkstemp(path); assert(fd >= 0); assert(ftruncate(fd, fixture::Bytes) == 0);
    void *memory = mmap(nullptr, fixture::Bytes, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0); assert(memory != MAP_FAILED);
    auto *shared = new (memory) MappedMedia; prepare(shared);
    pid_t pid = fork(); assert(pid >= 0);
    if (!pid) {
        munmap(memory, fixture::Bytes); close(fd);
        int other = open(path, O_RDONLY | O_NOFOLLOW); if (other < 0) _exit(10);
        void *view = mmap(nullptr, fixture::Bytes, PROT_READ, MAP_SHARED, other, 0); close(other);
        if (view == MAP_FAILED) _exit(11);
        bool ok = inspect(static_cast<MappedMedia *>(view)); munmap(view, fixture::Bytes); _exit(ok ? 0 : 12);
    }
    int result = 99; assert(waitpid(pid, &result, 0) == pid); assert(WIFEXITED(result) && WEXITSTATUS(result) == 0);
#endif
    assert(shared->state.video[0].lease.load() == 0); // no writes from the read-only child
    assert(obs::acquireWriter(shared->state.video[0])); obs::releaseWriter(shared->state.video[0]);
#ifdef _WIN32
    UnmapViewOfFile(shared); CloseHandle(map); CloseHandle(file); assert(DeleteFileW(path));
#else
    munmap(memory, fixture::Bytes); close(fd); assert(unlink(path) == 0);
#endif
    std::printf("PASS: raw BGRA bounds/stride/session; two real processes open the same file and share pixels/PCM using read-only consumer maps; %zu bytes\n", fixture::Bytes);
}
