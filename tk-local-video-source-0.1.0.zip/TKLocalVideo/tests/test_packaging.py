"""Unit regression plus optional actual pinned Theos dm.pl archive regression.

Synthetic binaries are NOT installable. Never present this as phone validation.
"""
import hashlib
import importlib.util
import os
import plistlib
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from check_deb import check, payload
from test_deb_checker import files

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("prepare_packaging", ROOT / "scripts/prepare_packaging.py")
prepare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prepare)


class PackagingTest(unittest.TestCase):
    def test_numeric_owner_patch_and_idempotence(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            path = Path(folder) / "dm-test.pl"
            raw = b"stub\n" + prepare.OLD + b"\n"
            path.write_bytes(raw)
            digest = hashlib.sha256(raw).hexdigest()
            self.assertTrue(prepare.patch_dm(path, digest))
            self.assertIn(b"$tf->uid(0);", path.read_bytes())
            self.assertIn(b"$tf->gid(0);", path.read_bytes())
            self.assertFalse(prepare.patch_dm(path, digest))
            path.write_bytes(path.read_bytes() + b"unexpected\n")
            with self.assertRaisesRegex(ValueError, "unexpected"):
                prepare.patch_dm(path, digest)

    def test_unexpected_packager_is_not_modified(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            path = Path(folder) / "dm.pl"
            path.write_bytes(b"unknown")
            with self.assertRaisesRegex(ValueError, "unsupported"):
                prepare.patch_dm(path)
            self.assertEqual(path.read_bytes(), b"unknown")

    def test_profile_content_and_final_mode(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            base = Path(folder)
            path = base / "Library/libSandy" / prepare.PROFILE
            path.parent.mkdir(parents=True)
            raw = files()["var/jb/Library/libSandy/" + prepare.PROFILE]
            rule = plistlib.loads(raw)
            path.write_bytes(plistlib.dumps(rule))
            os.chmod(path, 0o777)
            prepare.prepare_profile(base)
            self.assertTrue(path.read_bytes().startswith(b"bplist00"))
            self.assertEqual(plistlib.loads(path.read_bytes()), rule)
            if os.name == "posix":
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o644)
            self.assertEqual(list(path.parent.glob(".obsbridge-profile-*")), [])

    def test_live_profile_preparation(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            base=Path(folder)
            name="local.xiaoguai.tk.local.live-read.plist"
            source=ROOT/"layout/Library/libSandy"/name
            path=base/"Library/libSandy"/name
            path.parent.mkdir(parents=True); path.write_bytes(source.read_bytes())
            prepare.prepare_profile(base,name,"com.zhiliaoapp.musically")
            self.assertTrue(path.read_bytes().startswith(b"bplist00"))
            self.assertEqual(plistlib.loads(path.read_bytes())["AllowedProcesses"],["com.zhiliaoapp.musically"])
            if os.name != "nt": # Windows exposes DOS writable bits, not POSIX modes.
                self.assertEqual(stat.S_IMODE(path.stat().st_mode),0o644)
            # Defaults stay restricted to the media service; app-specific scope
            # must be explicitly selected by the packaging hook.
            with self.assertRaisesRegex(ValueError,"scope changed"):
                prepare.prepare_profile(base,name)

    def test_missing_or_broad_profile_fails(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            base = Path(folder)
            (base / "Library/libSandy").mkdir(parents=True)
            with self.assertRaises(OSError):
                prepare.prepare_profile(base)
            path = base / "Library/libSandy" / prepare.PROFILE
            path.write_bytes(plistlib.dumps({"AllowedProcesses": ["*"]}))
            before = path.read_bytes()
            with self.assertRaisesRegex(ValueError, "scope changed"):
                prepare.prepare_profile(base)
            self.assertEqual(path.read_bytes(), before)

    def test_make_hook_and_strict_checker_remain(self):
        source = (ROOT / "Makefile").read_text()
        self.assertIn("before-package::", source)
        self.assertIn("prepare_packaging.py --patch-theos", source)
        self.assertIn('prepare_packaging.py --stage "$(THEOS_STAGING_DIR)"', source)
        self.assertIn("uid != 0 or gid != 0 or mode & 0o022", (ROOT / "tests/check_deb.py").read_text())


def actual_dm_regression(dm_path):
    # This is run on GitHub's macOS runner, using the real pinned Theos writer.
    # Windows unit tests cannot execute the runner's Perl/tar environment.
    original = Path(dm_path).read_bytes()
    if prepare.NEW in original:
        original = original.replace(prepare.NEW, prepare.OLD)
    if hashlib.sha256(original).hexdigest() != prepare.DM_SHA256:
        raise ValueError("actual dm.pl regression requires the pinned writer")
    with tempfile.TemporaryDirectory(dir=ROOT) as folder:
        base = Path(folder)
        writer = base / "dm.pl"
        writer.write_bytes(original)
        stage = base / "stage"
        for name, content in files().items():
            path = stage / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        control = stage / "DEBIAN/control"
        control.parent.mkdir()
        control.write_bytes((ROOT / "control").read_bytes())
        os.chmod(control.parent, 0o755)
        key = "var/jb/Library/libSandy/" + prepare.PROFILE
        os.chmod(stage / key, 0o644)
        # Test the real rootless layout. prepare_profile runs before Theos moves
        # Library under var/jb, so use a separate pre-prefix staging fixture.
        pre = base / "pre-prefix"
        src = pre / "Library/libSandy" / prepare.PROFILE
        src.parent.mkdir(parents=True)
        src.write_bytes(plistlib.dumps(plistlib.loads((stage / key).read_bytes())))
        os.chmod(src, 0o777)
        prepare.prepare_profile(pre)
        shutil.copy2(src, stage / key)
        bad = base / "unpatched-test-only.deb"
        subprocess.run(["perl", str(writer), "-Zgzip", "-b", str(stage), str(bad)], check=True)
        _, metadata = payload(bad, with_metadata=True)
        print("Unpatched actual dm.pl numeric UID/GID/mode:", metadata[key])
        if os.getuid() != 0:
            try:
                check(bad)
            except ValueError as error:
                if "root:root" not in str(error):
                    raise
            else:
                raise AssertionError("expected the unpatched numeric-owner regression")
        prepare.patch_dm(writer)
        good = base / "patched-test-only.deb"
        subprocess.run(["perl", str(writer), "-Zgzip", "-b", str(stage), str(good)], check=True)
        _, metadata = payload(good, with_metadata=True)
        assert metadata[key] == (0, 0, 0o644), metadata[key]
        assert check(good) == 14
        assert payload(good) == payload(bad), "packaging fix changed payload bytes"
        print("PASS: actual pinned Theos dm.pl: numeric 0:0, 0644, strict deb check; payload bytes unchanged (synthetic binaries, not a phone test)")


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--dm-pl":
        actual_dm_regression(Path(sys.argv[2]).resolve())
    else:
        unittest.main(verbosity=2)
