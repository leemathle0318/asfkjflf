#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/LocalPlayback.hpp"
#include "../core/RealtimeOwner.hpp"
#include "../core/AudioReadClock.hpp"
#include "../core/SharedMedia.hpp"
#include <cassert>
#include <cstdio>
#include <thread>
#include <vector>

struct Mapping {
    const unsigned id;
    mutable std::atomic<unsigned> reading{0};
    static std::atomic<unsigned> alive, peak;
    explicit Mapping(unsigned n) : id(n) {
        unsigned count=++alive, old=peak.load();
        while(count>old && !peak.compare_exchange_weak(old,count)) {}
    }
    ~Mapping() { assert(reading==0); --alive; }
};
std::atomic<unsigned> Mapping::alive{0}, Mapping::peak{0};
int main() {
    using namespace obs::local;
    const std::string valid="01234567-89AB-CDEF-0123-456789ABCDEF.mp4";
    assert(managedName(valid));
    for(const auto &n:{std::string("../x.mp4"),std::string("/tmp/a.mp4"),valid+"/a",std::string(""),std::string("01234567-89AB-CDEF-0123-456789ABCDEF.mov")}) assert(!managedName(n));
    std::vector<uint8_t> buffer(1024*1024);
    uint64_t readBytes=0, writtenBytes=0, progress=0, expected=uint64_t(8)*1024*1024*1024;
    assert(copyChunks(buffer.data(),buffer.size(),expected,[&](uint8_t *,size_t n)->int64_t {
        auto count=std::min(uint64_t(n),expected-readBytes);readBytes+=count;return int64_t(count);
    },[&](const uint8_t *,size_t n)->int64_t { auto count=std::min(n,size_t(65536));writtenBytes+=count;return int64_t(count); },
    []{return false;},[&](uint64_t n,uint64_t total){assert(total==expected && n>=progress);progress=n;}));
    assert(readBytes==expected && writtenBytes==expected && progress==expected);
    std::puts("PASS: simulated 8 GiB import using one 1 MiB buffer; partial writes, no whole-file allocation");
    unsigned reads=0;
    assert(!copyChunks(buffer.data(),buffer.size(),expected,[&](uint8_t *,size_t n)->int64_t {++reads;return int64_t(n);},
        [](const uint8_t *,size_t n){return int64_t(n);},[&]{return reads>=3;},[](uint64_t,uint64_t){}));
    assert(reads==3);
    assert(!copyChunks(buffer.data(),buffer.size(),1,[](uint8_t *,size_t){return int64_t(0);},[](const uint8_t *,size_t){return int64_t(-1);},[]{return false;},[](uint64_t,uint64_t){}));
    assert(!copyChunks(buffer.data(),buffer.size(),1,[](uint8_t *,size_t){return int64_t(2);},[](const uint8_t *,size_t){return int64_t(1);},[]{return false;},[](uint64_t,uint64_t){}));
    assert(!copyChunks(buffer.data(),buffer.size(),1,[](uint8_t *,size_t){return int64_t(1);},[](const uint8_t *,size_t){return int64_t(0);},[]{return false;},[](uint64_t,uint64_t){}));
    PlaybackClock clock;assert(clock.begin(-.021333,100));
    assert(std::abs(clock.due(0)-100.371333)<1e-9);
    for(unsigned loop=0;loop<100000;++loop) {
        clock.observe(clock.source+2.,.5);double end=clock.end;
        assert(clock.begin(loop%2 ? -.021333 : 0,end-.1,true));
        assert(clock.host==end); // audio and video retain one uninterrupted host epoch
    }
    assert(clock.late(clock.source,clock.host+1.));clock.rebuffer(clock.source,clock.host+1.);
    assert(!clock.late(clock.source,clock.host-.1));
    std::puts("PASS: common audio/video clock, 100000 loop transitions and joint rebuffer (accelerated model)");
    {
        RealtimeOwner<Mapping> owner;
        assert(owner.replace(std::make_shared<Mapping>(0)));
        std::atomic<bool> done{false};std::atomic<unsigned> accepted{0};
        std::thread reader([&]{
            while(!done) {
                auto lease=owner.tryRead();if(!lease.acquired() || !lease.get())continue;
                auto *value=lease.get();++value->reading;auto id=value->id;std::this_thread::yield();
                assert(value->id==id);--value->reading;++accepted;
            }
        });
        while(accepted.load()==0)std::this_thread::yield(); // start barrier, not a timing-dependent assertion
        for(unsigned n=1;n<=10000;++n) {
            auto next=std::make_shared<Mapping>(n);
            while(!owner.replace(next))std::this_thread::yield();
        }
        done=true;reader.join();assert(accepted>0);assert(owner.replace(nullptr));
    }
    assert(Mapping::alive==0 && Mapping::peak<=3);
    std::printf("PASS: 10000 mapping swaps concurrent with RT leases; no in-use destruction; peak owned mappings %u\n",Mapping::peak.load());
    // Persistent drift must not turn into an ever-growing read delay.
    for(double ppm:{-200.,200.}) {
        obs::DisciplinedAudioCursor cursor;double largest=0;
        for(unsigned n=0;n<1100000;++n) {
            double now=100.+n*1024./(48000.*(1.+ppm/1e6));
            double when=cursor.begin(91,1,now,1024,48000);
            largest=std::max(largest,std::abs(when-now));assert(std::isfinite(when));
        }
        assert(largest<.080);
        std::printf("PASS: %.0f ppm, >6 simulated hours, maximum host read phase %.3f ms\n",ppm,largest*1000.);
    }
    auto bus=std::make_unique<obs::SharedMedia>();bus->initialize();bus->enabled=1;bus->generation=1;bus->heartbeatUS=100000000;
    std::vector<float> input(24000,.2f),output(1024);std::vector<uint8_t> flags(1024);
    bus->writeAudio(input.data(),input.size(),99.9);
    auto coverage=bus->readAudioCovered(output.data(),flags.data(),1024,100.,48000,100000000);
    assert(coverage.found==1024 && coverage.longestGap==0);
    bus->resetAudio();coverage=bus->readAudioCovered(output.data(),flags.data(),1024,100.,48000,100000000);assert(!coverage.found);
    bus->writeAudio(input.data(),input.size(),100.);
    coverage=bus->readAudioCovered(output.data(),flags.data(),1024,100.,48000,100000000);assert(coverage.found==1024);
    assert(bus->audioLastEndTag==4824000);
    std::puts("PASS: complete/empty/recovered PCM coverage and write-end diagnostics");
}
