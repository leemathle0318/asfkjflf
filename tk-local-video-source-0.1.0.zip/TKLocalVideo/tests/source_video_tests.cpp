#include "MappedFixture.hpp"
#include "../core/VideoSchedule.hpp"
#include "../core/PendingFrames.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <vector>
#include <deque>
#include <cstdio>
#include <limits>
struct Frame { double due; };
int main() {
    // Includes dimensions above old 1080p/2048-edge limits and odd sizes.
    const uint32_t sizes[][2] = {{720,1280},{1080,1920},{2560,1440},{3840,2160},{3001,901},{4097,257}};
    for (const auto &size : sizes) {
        const size_t pixels = size_t(size[0]) * size[1];
        auto bus = fixture::make(pixels);
        const size_t bytes = obs::MappedMedia::allocationBytes(pixels);
        assert(bus->valid(77,bytes));
        std::vector<uint8_t> input(pixels*4,0x57), output(input.size());
        auto &raw = bus->frames[2];
        assert(raw.write(input.data(),size[0]*4,size[0],size[1]));
        assert(raw.geometry().width == size[0] && raw.geometry().height == size[1]);
        assert(raw.copy(raw.geometry(),output.data(),size[0]*4,output.size()) && output == input);
        assert(!raw.copy(raw.geometry(),output.data(),size[0]*4,output.size()-1));
        auto bad = raw.geometry(); bad.height += 1;
        assert(!raw.copy(bad,output.data(),size[0]*4,output.size()));
        ++raw.offset; assert(!bus->valid(77,bytes)); --raw.offset;
        ++raw.capacity; assert(!bus->valid(77,bytes)); --raw.capacity;
        assert(!bus->valid(77,bytes-1));
        std::printf("PASS: native geometry %u x %u; %zu-byte mapping\n",size[0],size[1],bytes);
    }
    assert(!obs::MappedMedia::allocationBytes(std::numeric_limits<size_t>::max()));
    // Long/short video duration is absent from allocation: only current frame size matters.
    for (double fps : {23.976,30.,59.94,60.,120.,144.}) {
        std::deque<std::shared_ptr<Frame>> queue;
        const size_t capacity = 256;
        for (int n=0;n<200;++n) {
            double due = 10. + n/fps;
            assert(obs::enqueuePending(queue,std::make_shared<Frame>(Frame{due}),capacity));
        }
        double previous = 9.; unsigned count = 0;
        while (!queue.empty()) {
            double now = queue.front()->due;
            double early = obs::nextVideoDelay(queue,now-.001);
            assert(std::abs(early-.001)<1e-9);
            assert(obs::nextVideoDelay(queue,now)==0.);
            assert(now>previous);previous=now;queue.pop_front();++count;
        }
        assert(count==200 && obs::nextVideoDelay(queue,10.)==.5);
        std::printf("PASS: deadline scheduling %.3f fps (simulation, not device playback)\n",fps);
    }
}
