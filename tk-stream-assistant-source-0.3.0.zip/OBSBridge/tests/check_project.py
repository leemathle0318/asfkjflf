"""Static package checks; these cannot verify private iOS media-service behavior."""
from pathlib import Path
import plistlib
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ProjectTest(unittest.TestCase):
    def test_rtmp_window_recovery_and_queue_accounting(self):
        source = (ROOT / "Receiver.mm").read_text(encoding="utf-8")
        self.assertIn('"core/PresentationClock.hpp"', source)
        self.assertIn("clock.schedule(pts, OBNow(), video, rtmpMode.load())", source)
        self.assertIn("e.scheduleLocked(p, true)", source)
        self.assertIn("e.scheduleLocked(p, false)", source)
        self.assertIn("if (obs::enqueuePending(e.images", source)
        self.assertIn("} else ++e.timingDrops;", source)
        self.assertIn("已连接 / 暂无可发布视频", source)
        self.assertNotIn("原画质修复", source)
        self.assertIn("e.connected = false", source)
        # Startup and stop must not inherit last session's receiving heartbeat.
        self.assertEqual(source.count("e.lastVideo=0;"), 2)

    def test_control_app_has_no_preview_or_app_route(self):
        source = (ROOT / "controlapp/main.mm").read_text(encoding="utf-8")
        for token in ("CIContext", "MTLCreateSystemDefaultDevice", "OBBusCopyVideo", "OBRequestMediaReadAccess", "previewQueue", "togglePreview", "openRoute", "openURL:", "原画质修复"):
            self.assertNotIn(token, source)
        self.assertIn('self.title=@"tk直播推流助手"', source)
        info=plistlib.loads((ROOT/"controlapp/Info.plist").read_bytes())
        self.assertEqual(info["CFBundleDisplayName"],"tk直播推流助手")
        self.assertEqual(info["CFBundleIdentifier"],"local.xiaoguai.obsbridge.control")
        self.assertNotIn("CFBundleURLTypes",info)
        makefile=(ROOT/"controlapp/Makefile").read_text()
        files=next(line for line in makefile.splitlines() if line.startswith("OBSBridgeControl_FILES"))
        self.assertEqual(files,"OBSBridgeControl_FILES = main.mm ../Client.m")
        self.assertNotIn("Metal",makefile)
        self.assertNotIn("CoreImage",makefile)

    def test_adjustment_and_status_remain_without_preview(self):
        source=(ROOT/"controlapp/main.mm").read_text(encoding="utf-8")
        for selector in ("slider:","rotate","outputDirection","reset","copyStatus"):
            self.assertIn("@selector("+selector+")",source)
        self.assertIn("OBCSaveTransform(self.values)",source)
        self.assertIn("self.status.text=raw",source)
        self.assertIn("UIApplicationStateActive",source)
        self.assertIn("now-self.lastStatusUpdate<1.",source)
        self.assertIn("打开手机相机或直播画面",source)

    def test_packaging_line_endings(self):
        for name in ("control", "Makefile", "prefs/Makefile", "scripts/build_ffmpeg.sh", "scripts/prepare_packaging.py"):
            with self.subTest(path=name):
                raw = (ROOT / name).read_bytes()
                self.assertNotIn(b"\r", raw, "Packaging inputs must use LF, not CRLF/CR")
                self.assertFalse(raw.startswith(b"\xef\xbb\xbf"), "Packaging inputs must not have a UTF-8 BOM")
                self.assertTrue(raw.endswith(b"\n"), "Packaging inputs must end with LF")

    def test_plists(self):
        files = list(ROOT.rglob("*.plist"))
        self.assertGreaterEqual(len(files), 4)
        for path in files:
            if "work" not in path.parts and "vendor" not in path.parts:
                with self.subTest(path=path):
                    with path.open("rb") as stream:
                        self.assertIsInstance(plistlib.load(stream), dict)

    def test_system_filter(self):
        with (ROOT / "OBSBridge.plist").open("rb") as stream:
            rule = plistlib.load(stream)
        self.assertEqual(rule["Filter"], {"Executables": ["mediaserverd"]})

    def test_rootless_architectures(self):
        makefile = (ROOT / "Makefile").read_text()
        self.assertIn("ARCHS = arm64 arm64e", makefile)
        self.assertIn("THEOS_PACKAGE_SCHEME = rootless", makefile)
        self.assertIn("SystemHooks.mm", makefile)
        self.assertNotIn("Tweak.xm", makefile)

    def test_shortcut_module(self):
        with (ROOT / "OBSBridgeSB.plist").open("rb") as stream:
            rule = plistlib.load(stream)
        self.assertEqual(rule["Filter"], {"Bundles": ["com.apple.springboard"]})
        makefile = (ROOT / "Makefile").read_text()
        self.assertIn("TWEAK_NAME = OBSBridge OBSBridgeSB", makefile)
        self.assertIn("OBSBridgeSB_FILES = Client.m Producer.mm Receiver.mm MediaBus.mm", makefile)
        self.assertNotIn("Preferences", next(line for line in makefile.splitlines() if line.startswith("OBSBridgeSB_FRAMEWORKS")))
        self.assertIn("Version: 0.3.0", (ROOT / "control").read_text())

    def test_required_sources(self):
        for name in ["SystemHooks.mm", "Receiver.mm", "Receiver.h", "Shared.h",
                     "prefs/OBPrefs.m", "core/Timeline.cpp", "core/Timeline.hpp",
                     "tests/timeline_tests.cpp", "tests/shortcut_tests.cpp", "core/Shortcut.hpp",
                     "Shortcut.mm", "Client.h", "Client.m", "OBSBridgeSB.plist",
                     "Producer.mm", "Consumer.mm", "MediaBus.mm", "MediaBus.h",
                     "core/SharedMedia.hpp", "tests/shared_media_tests.cpp",
                     "core/NonblockingRead.hpp", "core/MappingStatus.hpp", "tests/nonblocking_read_tests.cpp",
                     "core/MappedMedia.hpp", "core/PendingFrames.hpp", "tests/mapped_media_tests.cpp", "tests/pending_frames_tests.cpp",
                     "SandboxAccess.mm", "SandboxAccess.h", "core/AccessAttempt.hpp", "tests/access_attempt_tests.cpp",
                     "tests/check_deb.py", "tests/test_deb_checker.py",
                     "scripts/build_ffmpeg.sh", "scripts/prepare_packaging.py", "tests/test_packaging.py",
                     "core/VideoContinuity.hpp", "tests/video_continuity_tests.cpp",
                     "core/NativePCM.hpp", "AudioSample.h", "AudioSample.mm",
                     "core/AudioListQuery.hpp", "tests/audio_list_contract_tests.cpp",
                     "tests/native_audio_tests.cpp", "tests/coremedia_audio_tests.mm", "README.md", "THIRD_PARTY.md"]:
            self.assertTrue((ROOT / name).is_file(), name)

    def test_volume_menu_is_not_built_or_registered(self):
        source=(ROOT/"Shortcut.mm").read_text(encoding="utf-8")
        for token in ("SBVolumeControl","increaseVolume","decreaseVolume","showMenu","openURL:","constructor"):
            self.assertNotIn(token,source)
        files=next(line for line in (ROOT/"Makefile").read_text().splitlines() if line.startswith("OBSBridgeSB_FILES"))
        self.assertNotIn("Shortcut.mm",files)
        self.assertIn("Producer.mm",files)
        self.assertIn("Receiver.mm",files)

    def test_shared_config_write_contract(self):
        # Static regression only: does not simulate iOS filesystem/sandbox access.
        source = (ROOT / "Client.m").read_text(encoding="utf-8")
        engine = (ROOT / "Producer.mm").read_text(encoding="utf-8")
        self.assertNotIn("CFPreferencesSetAppValue", source)
        self.assertNotIn("CFPreferencesAppSynchronize", source)
        self.assertIn("writeToFile:OB_CONFIG options:NSDataWritingAtomic error:&error", source)
        self.assertIn("[saved isEqualToDictionary:config]", source)
        self.assertIn("chmod(OB_CONFIG.fileSystemRepresentation, 0644) != 0", source)
        self.assertIn("dictionaryWithContentsOfFile:OB_CONFIG", engine)
        command = source.split("NSString *OBCSendCommand(", 1)[1].split("NSString *OBCStatus(", 1)[0]
        for key in ("PCIP", "Enabled", "BindIP", "RequestID", "RequestDate"):
            self.assertIn(f'config[@"{key}"]', command)
        self.assertLess(command.index("OBCWriteConfig(config)"), command.index("if (error) return error;"))
        self.assertLess(command.index("if (error) return error;"), command.index("notify_post(OB_NOTIFY)"))
        header = (ROOT / "Client.h").read_text(encoding="utf-8")
        self.assertIn("NSString *OBCSavePeerIP", header)
        prefs = (ROOT / "prefs/OBPrefs.m").read_text(encoding="utf-8")
        self.assertIn("NSString *error = OBCSavePeerIP(value)", prefs)

    def test_receiver_does_not_depend_on_capture_hooks(self):
        makefile = (ROOT / "Makefile").read_text()
        media_files = next(line for line in makefile.splitlines() if line.startswith("OBSBridge_FILES"))
        self.assertIn("Consumer.mm AudioSample.mm MediaBus.mm", media_files)
        self.assertNotIn("Receiver.mm", media_files)
        source = (ROOT / "Receiver.mm").read_text(encoding="utf-8")
        self.assertNotIn("videoHook", source)
        self.assertNotIn("audioHook", source)
        self.assertIn('networkError(e, g, "bind", code)', source)
        self.assertIn('networkError(e, g, "listen", code)', source)
        self.assertIn("engine().bytes +=", source)
        client = (ROOT / "Client.m").read_text(encoding="utf-8")
        self.assertIn("return OBControlStatus()", client)

    def test_system_node_and_shared_protocol(self):
        hooks = (ROOT / "SystemHooks.mm").read_text(encoding="utf-8")
        self.assertIn('objc_getClass("BWNodeOutput")', hooks)
        self.assertIn('sel_registerName("emitSampleBuffer:")', hooks)
        self.assertNotIn("BWAudioConverterNode", hooks)
        self.assertNotIn("sourceNodeWillEmitVideoSampleBuffer", hooks)
        self.assertIn("OBMediaHeartbeat", hooks)
        self.assertNotIn("writeToFile", hooks)
        bus = (ROOT / "core/SharedMedia.hpp").read_text(encoding="utf-8")
        self.assertIn("is_always_lock_free", bus)
        self.assertNotIn("std::mutex", bus.split("struct alignas(64) SharedMedia", 1)[1])
        bridge = (ROOT / "MediaBus.mm").read_text(encoding="utf-8")
        self.assertIn("obs::captureFrame", bridge)
        self.assertNotIn("IOSurfaceLookup(", bridge)
        self.assertIn("MAP_SHARED", bridge)
        self.assertIn("O_RDONLY | O_NOFOLLOW", bridge)

    def test_nonblocking_transport_and_utf8_diagnostics(self):
        source = (ROOT / "Receiver.mm").read_text(encoding="utf-8")
        self.assertNotIn("poll(", source)
        self.assertNotIn("<poll.h>", source)
        self.assertIn("flags | O_NONBLOCK", source)
        self.assertIn("obs::nonblockingRead", source)
        self.assertIn("nanosleep(&delay", source)
        self.assertIn("stringWithUTF8String:e.message.c_str()", source)
        self.assertIn("stringWithUTF8String:e.lastError.c_str()", source)
        bridge = (ROOT / "MediaBus.mm").read_text(encoding="utf-8")
        self.assertIn("NSString *reason", bridge)
        self.assertIn("最近媒体结果：%@", bridge)
        self.assertIn("OB_MEDIA_MAPPING", bridge)
        self.assertIn("obs::MappingCode::FileOpen", bridge)
        self.assertIn("obs::MappingCode::AllocationSize", bridge)

    def test_raw_file_transport_and_pending_queue(self):
        bridge = (ROOT / "MediaBus.mm").read_text(encoding="utf-8")
        self.assertNotIn("IOSurfaceCreate(", bridge)
        self.assertNotIn("IOSurfaceGetID(", bridge)
        self.assertNotIn("IOSurfaceIsGlobal", bridge)
        self.assertIn("rename(temporary, OB_BUS_FILE)", bridge)
        self.assertIn("info.st_size != off_t(sizeof(obs::MappedMedia))", bridge)
        self.assertIn("file->valid(session)", bridge)
        self.assertNotIn("obs::releaseReader", bridge)
        receiver = (ROOT / "Receiver.mm").read_text(encoding="utf-8")
        self.assertIn("obs::enqueuePending", receiver)
        self.assertNotIn("while (e.images.size() > 6)", receiver)

    def test_consumer_is_read_only(self):
        bridge = (ROOT / "MediaBus.mm").read_text(encoding="utf-8")
        consumer = bridge.split("std::shared_ptr<OBMapping> OBBusConsumer(", 1)[1]
        self.assertNotIn("PROT_WRITE", consumer)
        self.assertNotIn("O_RDWR", consumer)
        self.assertNotIn("acquireReader", consumer)
        self.assertNotIn("releaseReader", consumer)
        self.assertIn("PROT_READ, MAP_SHARED", consumer)
        header = (ROOT / "MediaBus.h").read_text(encoding="utf-8")
        self.assertIn("const obs::SharedMedia *data", header)
        self.assertNotIn("releaseReader", header)
        protocol = (ROOT / "core/MappedMedia.hpp").read_text(encoding="utf-8")
        self.assertIn("std::array<std::atomic<uint32_t>, MaximumPixels>", protocol)
        self.assertIn("beginFrameWrite", protocol)
        self.assertIn("frameUnchanged", protocol)

    def test_scoped_upstream_permission_dependency(self):
        path = ROOT / "layout/Library/libSandy/local.xiaoguai.obsbridge.media-read.plist"
        rule = plistlib.loads(path.read_bytes())
        self.assertEqual(rule["AllowedProcesses"], ["com.apple.mediaserverd"])
        self.assertEqual(rule["Extensions"], [{"type": "file", "extension_class": "com.apple.app-sandbox.read",
            "path": "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}])
        self.assertIn("com.opa334.libsandy", (ROOT / "control").read_text())
        source = (ROOT / "SandboxAccess.mm").read_text(encoding="utf-8")
        self.assertIn('dlsym(library, "libSandy_applyProfile")', source)
        self.assertIn("PROT_READ, MAP_SHARED", source)
        self.assertIn("->valid(attempt.session)", source)
        self.assertIn("dispatch_async(permissionQueue", source)
        self.assertIn("exhaustedSession", source)
        self.assertNotIn("sandbox_extension_consume", source)
        hooks = (ROOT / "SystemHooks.mm").read_text(encoding="utf-8")
        callback = hooks.split("template<size_t Slot> void emit(", 1)[1].split("template<size_t...", 1)[0]
        self.assertNotIn("OBRequestMediaReadAccess", callback)
        self.assertIn("OBRequestMediaReadAccess", hooks.split("dispatch_source_set_event_handler(healthTimer", 1)[1])

    def test_video_continuity_and_rotation(self):
        hooks = (ROOT / "SystemHooks.mm").read_text(encoding="utf-8")
        video = hooks.split("if (type == kCMMediaType_Video", 1)[1].split("else if (type == kCMMediaType_Audio)", 1)[0]
        self.assertNotIn("CMSetAttachment", video)
        self.assertNotIn("CMGetAttachment", video)
        self.assertIn("if (depth || !sample)", hooks)
        bus = (ROOT / "MediaBus.mm").read_text(encoding="utf-8")
        self.assertIn("continuity.context", bus)
        self.assertIn("continuity.accept", bus)
        self.assertIn("obs::copyFrameTimed", bus)
        self.assertIn("CVPixelBufferRetain(snapshot->pixel)", bus)
        self.assertIn("CVPixelBufferPoolCreatePixelBufferWithAuxAttributes", bus)
        self.assertIn("return reuse()", bus)
        consumer = (ROOT / "Consumer.mm").read_text(encoding="utf-8")
        self.assertIn("obs::outputOrientation", consumer)
        self.assertIn("unsigned rotation = OBBusVideoRotation()", consumer)
        self.assertIn("obs::extraOrientation(rotation)", consumer)
        self.assertNotIn("imageByApplyingOrientation:6", consumer)
        client = (ROOT / "Client.m").read_text(encoding="utf-8")
        rotate = client.split("NSString *OBCSetVideoRotation", 1)[1].split("NSString *OBCURL", 1)[0]
        self.assertNotIn('config[@"Enabled"]', rotate)
        self.assertNotIn('config[@"RequestID"]', rotate)
        self.assertIn("OBCWriteConfig(config)", rotate)
        self.assertIn("@selector(rotate)", (ROOT / "controlapp/main.mm").read_text(encoding="utf-8"))


    def test_native_audio_mix_and_owned_sample(self):
        consumer = (ROOT / "Consumer.mm").read_text(encoding="utf-8")
        self.assertIn("obs::mixNative", consumer)
        self.assertIn("pcm, 1., .70", consumer)
        self.assertIn("context->cursor.begin", consumer)
        self.assertIn("contextForAudio(node)", consumer)
        self.assertNotIn("CMSampleBufferGetPresentationTimeStamp", consumer)
        self.assertIn("kLinearPCMFormatFlagsSampleFractionMask", consumer)
        self.assertIn("OBMediaAudioState", consumer)
        self.assertIn("OBCopyMixedAudioSample(mic, abl, &rc)", consumer)
        helper = (ROOT / "AudioSample.mm").read_text(encoding="utf-8")
        self.assertIn("CMBlockBufferCreateWithMemoryBlock", helper)
        self.assertIn("OBGetAudioBufferList(result", helper)
        self.assertIn("OBGetAudioBufferList(mic", consumer)
        self.assertIn("kCMSampleBufferError_ArrayTooSmall", helper)
        self.assertIn("obs::audioListPlan", helper)
        self.assertIn("list->mNumberBuffers = plan.buffers", helper)
        self.assertIn("list, *needed, kCFAllocatorDefault", helper)
        self.assertIn("source, nullptr,", helper)
        self.assertIn("nullptr, 0, kCFAllocatorDefault", helper)
        self.assertIn("CMSampleBufferCreateReady", helper)
        self.assertIn("planar ? nullptr : &sampleSize", helper)
        self.assertIn("CMSampleBufferGetSampleTimingInfoArray", helper)
        self.assertIn("kCMAttachmentMode_ShouldNotPropagate", helper)
        self.assertNotIn("CMSampleBufferSetDataBufferFromAudioBufferList", helper)
        hooks = (ROOT / "SystemHooks.mm").read_text(encoding="utf-8")
        self.assertIn("OBCopyAudioForNode(sample, self)", hooks)
        self.assertIn("OBPublishAudioDiagnostics", hooks)
        self.assertIn("复制完整状态", (ROOT / "controlapp/main.mm").read_text(encoding="utf-8"))
        self.assertNotIn('import "MediaBus.h"', (ROOT / "Client.m").read_text())


    def test_live_audio_boundary_and_rt_scope(self):
        rule=plistlib.loads((ROOT/"OBSBridgeLive.plist").read_bytes())
        self.assertEqual(rule["Filter"],{"Bundles":["com.zhiliaoapp.musically"]})
        source=(ROOT/"AppAudio.mm").read_text(encoding="utf-8")
        callback=source.split("OSStatus render(",1)[1].split("OSStatus create(",1)[0]
        mixer=source.split("bool addOBS(",1)[1].split("OSStatus render(",1)[0]
        for forbidden in ("AudioUnitGetProperty(","NSLog(","notify_", "OBBusConsumer(","OBRequestMediaReadAccess(","dispatch_", "std::lock_guard", "new "):
            self.assertNotIn(forbidden,callback+mixer)
        self.assertIn("obs::liveRender",callback)
        self.assertIn("unit.busy.test_and_set",mixer)
        self.assertIn("obs::nativeLayout",mixer)
        self.assertIn("obs::mixNative",mixer)
        self.assertIn("OBBusLiveAudioEnabled()",source)
        self.assertIn("mediaVersionReady.load",mixer)
        self.assertIn("OBBusMediaVersionReady()",source)
        self.assertNotIn("dictionaryWithContentsOfFile",source)
        hooks=(ROOT/"SystemHooks.mm").read_text(encoding="utf-8")
        self.assertIn("!OBLiveAudioOwnsCapture()",hooks)
        self.assertIn("OBRefreshLiveAudioOwner()",hooks)
        rule=plistlib.loads((ROOT/"layout/Library/libSandy/local.xiaoguai.obsbridge.live-read.plist").read_bytes())
        self.assertEqual(rule["AllowedProcesses"],["com.zhiliaoapp.musically"])
        self.assertEqual(rule["Extensions"],[{"type":"file","extension_class":"com.apple.app-sandbox.read","path":"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}])

    def test_performance_and_video_fallback(self):
        producer=(ROOT/"Producer.mm").read_text(encoding="utf-8")
        self.assertIn("NSEC_PER_SEC / fps",producer)
        self.assertIn("obs::videoBudget(OBBusVideoProfile()",producer)
        self.assertIn("now - lastStatus >= 1.",producer)
        consumer=(ROOT/"Consumer.mm").read_text(encoding="utf-8")
        self.assertIn("source != cache.source",consumer)
        self.assertIn("kCIContextCacheIntermediates: @NO",consumer)
        self.assertIn("obs::copyVideoPlanes",consumer)
        self.assertIn("CIColor colorWithRed:0",consumer)
        receiver=(ROOT/"Receiver.mm").read_text(encoding="utf-8")
        self.assertLess(receiver.index("gate.admit"),receiver.index("CVPixelBufferCreate"))
        for name in ("core/LiveAudio.hpp","core/VideoBudget.hpp","core/VideoCopy.hpp","AppAudio.mm","LiveAudioStatus.mm","LiveAudioStatus.h","tests/live_audio_tests.cpp","tests/video_budget_tests.cpp"):
            self.assertTrue((ROOT/name).is_file(),name)

    def test_native_quality_is_shared_by_both_transports_and_bounded(self):
        receiver=(ROOT/"Receiver.mm").read_text(encoding="utf-8")
        self.assertIn("obs::videoBudget(OBBusVideoProfile()",receiver)
        bus=(ROOT/"MediaBus.mm").read_text(encoding="utf-8")
        self.assertIn("obs::normalizedProfile(profile)",bus)
        self.assertIn("scale == 1. ? size_t(inputW)",bus)
        self.assertIn("scale == 1. ? size_t(inputH)",bus)
        mapped=(ROOT/"core/MappedMedia.hpp").read_text()
        self.assertIn("MaximumPixels = 1920 * 1080",mapped)
        self.assertIn("FileVersion = 5",mapped)
        self.assertIn("width <= 2048",mapped)
        self.assertIn("OB_VERSION_CODE 0x00030001u",(ROOT/"Shared.h").read_text())

    def test_simple_settings_pages_keep_stop_and_diagnostics(self):
        source=(ROOT/"controlapp/main.mm").read_text(encoding="utf-8")
        for text in ('@"连接",@"画面",@"状态"','@"省电",@"均衡",@"源画质"','复制完整状态','OBS / TCP','AAC 192 Kbps'):
            self.assertIn(text,source)
        self.assertIn("OBCSendCommand(YES,self.peer.text)",source)
        self.assertIn("UIAlertActionStyleDestructive",source)
        self.assertIn("self.cropFields.hidden=YES",source)
        self.assertIn("constraintGreaterThanOrEqualToConstant:44",source)
        self.assertIn("Name: tk推流助手\n",(ROOT/"control").read_text(encoding="utf-8"))
        self.assertIn("Package: local.xiaoguai.obsbridge\n",(ROOT/"control").read_text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
