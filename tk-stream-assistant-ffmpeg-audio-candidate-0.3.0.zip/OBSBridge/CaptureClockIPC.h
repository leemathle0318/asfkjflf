#pragma once
#include "core/CaptureClockWire.hpp"
// Background-only functions. Never call them from AudioUnitRender.
void OBPublishCaptureClock(const obs::next::CaptureClockSnapshot &snapshot);
obs::next::CaptureFeedbackState OBReadCaptureClock(uint64_t cookie,uint32_t generation,double now,
                                                 obs::next::CaptureClockSnapshot &snapshot);
