#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/CaptureOutputWorker.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <thread>
using namespace obs::next;
static void ringGuards() {
    auto pcm=std::make_unique<PreparedCapturePCM>();
    PreparedContext c{123,1,1,2,4,48000};auto epoch=pcm->configure(c);
    std::array<float,1024> input{},out{};std::array<uint8_t,1024> valid{};
    input.fill(.25f);obs::AudioReadCoverage coverage;
    assert(pcm->write(epoch,input.data(),input.size(),0,1000000));
    assert(pcm->read(c,0,out.data(),valid.data(),out.size(),1000010,coverage) && coverage.found==1024);
    // These positions alias in a 32-bit tag implementation but never here.
    assert(!pcm->read(c,uint64_t(1)<<32,out.data(),valid.data(),out.size(),1000010,coverage));
    assert(coverage.found==0);
    auto wrong=c;wrong.captureRevision++;
    assert(!pcm->read(wrong,0,out.data(),valid.data(),out.size(),1000010,coverage));
    auto next=pcm->configure(c);assert(next!=epoch);
    assert(!pcm->read(c,0,out.data(),valid.data(),out.size(),1000010,coverage));
    assert(!pcm->write(epoch,input.data(),input.size(),0,1000000));
    input.fill(0);assert(pcm->write(next,input.data(),input.size(),0,1000000));
    assert(pcm->read(c,0,out.data(),valid.data(),out.size(),1000010,coverage));
    for(float x:out)assert(x==0);
    assert(!pcm->read(c,0,out.data(),valid.data(),out.size(),2000000,coverage));
    pcm->invalidate();assert(!pcm->read(c,0,out.data(),valid.data(),out.size(),1000010,coverage));
    std::puts("PASS prepared PCM: full-width frame tags, context isolation, stale/reset/old writer rejection, silent restart");
}
static void nativeWorker(int rate,unsigned frames,double ppm) {
    auto worker=std::make_unique<CaptureOutputWorker>();
    CaptureClockTracker clock;CaptureReportSource source;CaptureReportQueue<> queue;
    std::array<float,8192> out{};std::array<uint8_t,8192> valid{};
    uint64_t missing=0,requested=0;double now=0;
    double ratio=1.+ppm/1e6;
    unsigned blocks=unsigned(240.*rate/frames);
    for(unsigned n=0;n<blocks;++n) {
        CaptureReport r;r.cookie=123;r.unit=1;r.generation=2;r.formatVersion=4;r.frames=frames;
        r.nominalRate=rate;r.hasSample=r.hasHost=true;r.sampleTime=10000.+double(n)*frames;
        r.hostTime=1000.+double(n)*frames/rate/ratio;
        r.callbackTime=r.hostTime+.003+double(n%7)*.00005;now=r.callbackTime;
        CaptureReport ticket;
        assert(source.offer(queue,r,&ticket));
        obs::AudioReadCoverage coverage;
        PreparedContext context{ticket.cookie,ticket.unit,ticket.captureRevision,ticket.generation,ticket.formatVersion,uint32_t(rate)};
        worker->prepared()->read(context,ticket.framePosition,out.data(),valid.data(),frames,uint64_t(now*1e6),coverage);
        if(n>100) {
            missing+=coverage.requested-coverage.found;requested+=coverage.requested;
            for(unsigned i=0;i<frames;++i)assert(std::isfinite(out[i]) && std::abs(out[i])<.3);
        }
        CaptureReport observed;while(queue.pop(observed))clock.observe(observed);
        worker->tick(clock,now,[&](float *data,size_t count,double host) {
            if(host+double(count)/48000.>now+.180)return false;
            for(size_t i=0;i<count;++i)data[i]=float(.2*std::sin(2*3.141592653589793*440.*(host+double(i)/48000.)));
            return true;
        });
    }
    assert(requested>0 && missing==0 && worker->stats.failed==0 && worker->stats.rebuffers==1);
    std::printf("PASS actual SWR background -> prepared PCM -> native-frame read: rate=%d frames=%u skew=%+.0fppm, 240s-equivalent, missing=%llu rebuffers=%llu\n",
        rate,frames,ppm,(unsigned long long)missing,(unsigned long long)worker->stats.rebuffers);
}
static void coherentRingThreads() {
    auto pcm=std::make_unique<PreparedCapturePCM>();PreparedContext c{1,2,1,3,4,48000};auto epoch=pcm->configure(c);
    std::atomic<uint64_t> newest{0};std::atomic<bool> done{false};uint64_t reads=0;
    std::thread writer([&]{
        std::array<float,64> input{};
        for(uint64_t block=1;block<=100000;++block) {
            uint64_t start=block*64;
            for(unsigned i=0;i<input.size();++i)input[i]=float((start+i)%1000)/1000.f;
            assert(pcm->write(epoch,input.data(),input.size(),start,1000000));newest.store(start,std::memory_order_release);
        }
        done.store(true,std::memory_order_release);
    });
    std::array<float,64> out{};std::array<uint8_t,64> valid{};
    while(!done.load(std::memory_order_acquire)) {
        uint64_t start=newest.load(std::memory_order_acquire);if(!start)continue;
        obs::AudioReadCoverage coverage;pcm->read(c,start,out.data(),valid.data(),out.size(),1000000,coverage);
        for(unsigned i=0;i<out.size();++i)if(valid[i])assert(out[i]==float((start+i)%1000)/1000.f);
        ++reads;
    }
    writer.join();assert(reads);
    std::puts("PASS real concurrent prepared-PCM writer/reader: valid samples never have torn frame/value payload");
}
static void deviceRestart() {
    auto worker=std::make_unique<CaptureOutputWorker>();CaptureClockTracker clock;CaptureReportSource source;CaptureReportQueue<> queue;
    uint64_t revision=0;
    for(unsigned n=0;n<500;++n) {
        bool restarted=n>=250;
        CaptureReport r;r.cookie=1;r.unit=2;r.generation=3;r.formatVersion=4;r.frames=480;r.nominalRate=48000;
        r.hasHost=r.hasSample=true;r.sampleTime=double(restarted?n-250:n)*480;
        r.hostTime=100.+n*.010;r.callbackTime=r.hostTime+.003;
        CaptureReport ticket;assert(source.offer(queue,r,&ticket));
        if(n==250){assert(ticket.captureRevision>revision && ticket.framePosition==0);}
        revision=ticket.captureRevision;
        CaptureReport report;while(queue.pop(report))clock.observe(report);
        worker->tick(clock,r.callbackTime,[&](float *out,size_t frames,double){std::fill(out,out+frames,restarted?0.f:.25f);return true;});
        if(n==255) {
            std::array<float,480> out{};std::array<uint8_t,480> valid{};obs::AudioReadCoverage coverage;
            assert(worker->prepared()->read(worker->context(),ticket.framePosition,out.data(),valid.data(),out.size(),uint64_t(r.callbackTime*1e6),coverage));
            for(unsigned i=0;i<out.size();++i)if(valid[i])assert(out[i]==0.f);
        }
    }
    assert(worker->stats.rebuffers==2 && worker->stats.failed==0);
    std::puts("PASS actual SWR device sample-time restart: fresh capture epoch, no previous-session PCM/filter tail");
}
int main(){
    ringGuards();
    coherentRingThreads();deviceRestart();
    for(int rate:{44100,48000})for(double ppm:{-500.,500.})nativeWorker(rate,1024,ppm);
    for(int rate:{8000,96000,192000})nativeWorker(rate,unsigned(rate/100),100.);
}
