"""Synthetic package fixtures only; never install these on a device."""
import io
import plistlib
import struct
import tarfile
import tempfile
import unittest
from pathlib import Path

from check_deb import check


def macho(archs=(0, 2), markers=b"BWNodeOutput\0emitSampleBuffer:\0local.xiaoguai.obsbridge.receive\0local.xiaoguai.obsbridge.media-v5.dat\0libSandy_applyProfile\0local.xiaoguai.obsbridge.v5.audio.phase\0local.xiaoguai.obsbridge.live.audio\0AudioUnitRender\0local.xiaoguai.obsbridge.live.mapping\0"):
    offset = 8 + len(archs) * 20
    headers = []
    slices = []
    for subtype in archs:
        data = struct.pack("<8I", 0xfeedfacf, 0x100000c, subtype, 6, 0, 0, 0, 0) + markers
        headers.append(struct.pack(">5I", 0x100000c, subtype, offset, len(data), 0))
        slices.append(data)
        offset += len(data)
    return b"\xca\xfe\xba\xbe" + struct.pack(">I", len(archs)) + b"".join(headers + slices)


def files():
    prefix = "var/jb/Library/"
    plist = lambda value: plistlib.dumps(value, fmt=plistlib.FMT_BINARY)
    return {
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridge.dylib": macho(),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridge.plist": plist({"Filter": {"Executables": ["mediaserverd"]}}),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib": macho(),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist": plist({"Filter": {"Bundles": ["com.apple.springboard"]}}),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridgeLive.dylib": macho(),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridgeLive.plist": plist({"Filter": {"Bundles": ["com.zhiliaoapp.musically"]}}),
        prefix + "libSandy/local.xiaoguai.obsbridge.live-read.plist": plist({
            "AllowedProcesses": ["com.zhiliaoapp.musically"], "Extensions": [
                {"type": "file", "extension_class": "com.apple.app-sandbox.read", "path": "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}]}),
        prefix + "libSandy/local.xiaoguai.obsbridge.control-read.plist": plist({"AllowedProcesses":["local.xiaoguai.obsbridge.control"],"Extensions":[{"type":"file","extension_class":"com.apple.app-sandbox.read","path":"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}]}),
        "var/jb/Applications/OBSBridgeControl.app/OBSBridgeControl": macho(),
        "var/jb/Applications/OBSBridgeControl.app/Info.plist": plist({"CFBundleIdentifier":"local.xiaoguai.obsbridge.control","CFBundleDisplayName":"tk直播推流助手","NSCameraUsageDescription":"Scan QR"}),
        prefix + "PreferenceBundles/OBSBridgePrefs.bundle/OBSBridgePrefs": macho(),
        prefix + "PreferenceBundles/OBSBridgePrefs.bundle/Info.plist": plist({}),
        prefix + "PreferenceBundles/OBSBridgePrefs.bundle/Root.plist": plist({}),
        prefix + "PreferenceLoader/Preferences/OBSBridge.plist": plist({}),
        prefix + "libSandy/local.xiaoguai.obsbridge.media-read.plist": plist({
            "AllowedProcesses": ["com.apple.mediaserverd"], "Extensions": [
                {"type": "file", "extension_class": "com.apple.app-sandbox.read",
                 "path": "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v5.dat"}]}),
    }


def package(items, metadata=None):
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode="w:gz") as archive:
        for name, content in items.items():
            member = tarfile.TarInfo(name)
            member.size = len(content)
            if metadata and name in metadata:
                member.uid, member.gid, member.mode = metadata[name]
            archive.addfile(member, io.BytesIO(content))
    def ar(name, content):
        header = f"{name + '/':<16}{0:<12}{0:<6}{0:<6}{'100644':<8}{len(content):<10}`\n".encode("ascii")
        return header + content + (b"\n" if len(content) % 2 else b"")
    return b"!<arch>\n" + ar("debian-binary", b"2.0\n") + ar("data.tar.gz", data.getvalue())


class DebCheckerTest(unittest.TestCase):
    def run_check(self, raw):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic-test-only.deb"
            path.write_bytes(raw)
            return check(path)

    def test_old_volume_menu_is_rejected(self):
        items=files();key="var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib"
        items[key]+=b"SBVolumeControl\0"
        with self.assertRaisesRegex(ValueError,"legacy volume menu"):
            self.run_check(package(items))

    def test_old_app_name_and_route_are_rejected(self):
        for route in (False,True):
            items=files();key="var/jb/Applications/OBSBridgeControl.app/Info.plist"
            info=plistlib.loads(items[key])
            if route:info["CFBundleURLTypes"]=[{"CFBundleURLSchemes":["meowbridge"]}]
            else:info["CFBundleDisplayName"]="RTMP 画面设置"
            items[key]=plistlib.dumps(info)
            with self.assertRaisesRegex(ValueError,"display name or legacy URL route"):
                self.run_check(package(items))

    def test_complete_fixture(self):
        self.assertEqual(self.run_check(package(files())), 15)

    def test_broad_permission_profile_is_rejected(self):
        items = files()
        key = "var/jb/Library/libSandy/local.xiaoguai.obsbridge.media-read.plist"
        items[key] = plistlib.dumps({"AllowedProcesses": ["*"], "Extensions": [
            {"type": "file", "extension_class": "com.apple.app-sandbox.read-write", "path": "/"}]})
        with self.assertRaisesRegex(ValueError, "grants more"):
            self.run_check(package(items))

    def test_unsafe_profile_owner_and_mode_are_rejected(self):
        key = "var/jb/Library/libSandy/local.xiaoguai.obsbridge.media-read.plist"
        for attrs in ((501, 0, 0o644), (0, 501, 0o644), (0, 0, 0o664), (0, 0, 0o646)):
            with self.subTest(metadata=attrs), self.assertRaisesRegex(ValueError, "root:root"):
                self.run_check(package(files(), {key: attrs}))

    def test_missing_upstream_permission_interface_is_rejected(self):
        items = files()
        key = "var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridge.dylib"
        marker = b"libSandy_applyProfile"
        items[key] = items[key].replace(marker, b"X" * len(marker))
        with self.assertRaisesRegex(ValueError, "libSandy integration"):
            self.run_check(package(items))

    def test_old_audio_module_is_rejected(self):
        items = files()
        marker = b"local.xiaoguai.obsbridge.v5.audio.phase"
        for module in ("OBSBridge", "OBSBridgeSB"):
            with self.subTest(module=module):
                modified = dict(items)
                key = f"var/jb/Library/MobileSubstrate/DynamicLibraries/{module}.dylib"
                modified[key] = modified[key].replace(marker, b"X" * len(marker))
                with self.assertRaisesRegex(ValueError, "native-audio diagnostics"):
                    self.run_check(package(modified))

    def test_old_transport_is_rejected(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridge.dylib"] = macho(markers=b"BWNodeOutput\0emitSampleBuffer:\0")
        with self.assertRaisesRegex(ValueError, "v5 read-only-consumer transport"):
            self.run_check(package(items))

    def test_missing_shortcut(self):
        items = files()
        del items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib"]
        with self.assertRaisesRegex(ValueError, "missing packaged files"):
            self.run_check(package(items))

    def test_wrong_filter(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist"] = plistlib.dumps({"Filter": {"Bundles": ["wrong"]}})
        with self.assertRaisesRegex(ValueError, "incorrect SpringBoard filter"):
            self.run_check(package(items))

    def test_arm64e_only_is_rejected(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib"] = macho((2,))
        with self.assertRaisesRegex(ValueError, "missing arm64/arm64e"):
            self.run_check(package(items))

    def test_missing_live_and_profile(self):
        for name in ("MobileSubstrate/DynamicLibraries/OBSBridgeLive.dylib", "libSandy/local.xiaoguai.obsbridge.live-read.plist"):
            items=files(); del items["var/jb/Library/"+name]
            with self.assertRaisesRegex(ValueError,"missing packaged"):
                self.run_check(package(items))

    def test_unsafe_live_profile(self):
        key="var/jb/Library/libSandy/local.xiaoguai.obsbridge.live-read.plist"
        for attrs in ((501,0,0o644),(0,0,0o666)):
            with self.assertRaisesRegex(ValueError,"root:root"):
                self.run_check(package(files(),{key:attrs}))
        items=files(); items[key]=plistlib.dumps({"AllowedProcesses":["*"],"Extensions":[]})
        with self.assertRaisesRegex(ValueError,"grants more"):
            self.run_check(package(items))

    def test_bad_live_filter_or_architecture(self):
        items=files(); key="var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeLive.plist"
        items[key]=plistlib.dumps({"Filter":{"Bundles":["*"]}})
        with self.assertRaisesRegex(ValueError,"incorrect TikTok"):
            self.run_check(package(items))
        items=files(); items[key.replace(".plist",".dylib")]=macho((2,))
        with self.assertRaisesRegex(ValueError,"missing arm64"):
            self.run_check(package(items))

    def test_old_live_hook_marker(self):
        items=files(); key="var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeLive.dylib"
        items[key]=items[key].replace(b"AudioUnitRender",b"X"*len(b"AudioUnitRender"))
        with self.assertRaisesRegex(ValueError,"missing live audio"):
            self.run_check(package(items))

    def test_truncated_archive(self):
        with self.assertRaisesRegex(ValueError, "truncated ar member"):
            self.run_check(package(files())[:-20])

    def test_old_media_role_is_rejected(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridge.dylib"] = macho(markers=b"legacy")
        with self.assertRaisesRegex(ValueError, "v2 node consumer"):
            self.run_check(package(items))

    def test_missing_receiver_role_is_rejected(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib"] = macho(markers=b"menu-only")
        with self.assertRaisesRegex(ValueError, "independent receiver"):
            self.run_check(package(items))


if __name__ == "__main__":
    unittest.main(verbosity=2)
