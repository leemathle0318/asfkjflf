#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/FFmpegAudioTimeline.hpp"
#include "../core/CaptureClockFeedback.hpp"
#include "../core/CaptureClockedAudio.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <vector>
extern "C" {
#include <libavutil/avutil.h>
}
using obs::next::FFmpegAudioTimeline;
using obs::next::AudioEngineBlock;
using obs::next::AudioEngineResult;
constexpr double pi=3.141592653589793;
static void checkCaptureDrivenCompensation(double nativePPM,double sourcePPM) {
    using namespace obs::next;
    CaptureClockTracker capture;
    uint64_t nativeBlock=0;
    double nativeRatio=1.+nativePPM/1e6, sourceRatio=1.+sourcePPM/1e6;
    auto snapshot=[&](double now) {
        for(;;) {
            double host=1000.+double(nativeBlock)*.01/nativeRatio;
            if(host+.003>now)break;
            CaptureReport r;
            r.cookie=123;r.unit=1;r.generation=2;r.formatVersion=4;r.frames=480;
            r.framePosition=nativeBlock*480;r.hasSample=r.hasHost=true;
            r.sampleTime=10000.+double(r.framePosition);r.hostTime=host;
            r.callbackTime=host+.003;r.nominalRate=48000;capture.observe(r);++nativeBlock;
        }
        const auto &latest=capture.latest();
        CaptureClockSnapshot clock;
        clock.cookie=latest.cookie;clock.unit=latest.unit;clock.generation=latest.generation;clock.formatVersion=latest.formatVersion;
        clock.hostAnchor=latest.hostTime;clock.masterAnchor=capture.masterForHost(latest.hostTime,now);
        clock.ratio=capture.rateRatio();clock.reportedAt=latest.callbackTime;
        clock.consumedFrames=latest.framePosition;clock.ready=capture.ready(now);
        clock.revision=capture.revision();
        auto words=CaptureClockWire::encode(clock);words[CaptureClockWire::Sequence]=(uint64_t(567)<<32)|2;
        CaptureClockSnapshot received;
        assert(CaptureClockWire::decode(words,now,123,2,received)==CaptureFeedbackState::Ready);
        return received;
    };
    auto engine=std::make_unique<CaptureClockedAudio>();
    AVChannelLayout mono=AV_CHANNEL_LAYOUT_MONO;
    auto first=snapshot(1010.);
    assert(engine->configure(48000,AV_SAMPLE_FMT_FLT,mono,first,1010.,33));
    std::array<float,960> input{};
    for(unsigned i=0;i<input.size();++i)input[i]=float(.2*std::sin(2*pi*1000.*i/48000.));
    const uint8_t *planes[]={reinterpret_cast<const uint8_t *>(input.data())};
    std::array<float,2048> out{};
    uint64_t total=0;double previousEnd=0,now=1010.;
    for(unsigned block=0;block<30000;++block) {
        // The model supplies a known common source->host mapping here. Fitting
        // that mapping to real RTMP arrivals is NOT exercised by this test.
        now=1010.+block*.020/sourceRatio;
        auto clock=snapshot(now);
        assert(engine->pushForHost(planes,1,960,now+.180,clock,now,33)==AudioEngineResult::Ok);
        while(engine->available()) {
            AudioEngineBlock result;
            assert(engine->pop(out.data(),int(out.size()),result)==AudioEngineResult::Ok);
            if(total)assert(std::abs(result.masterTime-previousEnd)<.00005);
            previousEnd=result.masterTime+double(result.frames)/48000.;total+=unsigned(result.frames);
            for(int n=0;n<result.frames;++n)assert(std::isfinite(out[n]) && std::abs(out[n])<.3);
        }
        assert(engine->allocatedSamples()==FFmpegAudioTimeline::Capacity);
    }
    double expected=600.*nativeRatio/sourceRatio;
    double residual=double(total)/48000.+engine->filterDelay()-expected;
    assert(std::abs(residual)<.004);
    auto clock=snapshot(now);auto before=engine->stats().input;
    auto stale=clock;stale.reportedAt=now-3.;
    assert(engine->pushForHost(planes,1,960,now+.2,stale,now,33)==AudioEngineResult::ClockUnavailable);
    auto wrongPID=clock;wrongPID.owner++;
    assert(engine->pushForHost(planes,1,960,now+.2,wrongPID,now,33)==AudioEngineResult::EpochChanged);
    auto wrongEpoch=clock;wrongEpoch.generation++;
    assert(engine->pushForHost(planes,1,960,now+.2,wrongEpoch,now,33)==AudioEngineResult::EpochChanged);
    auto wrongRevision=clock;wrongRevision.revision++;
    assert(engine->pushForHost(planes,1,960,now+.2,wrongRevision,now,33)==AudioEngineResult::EpochChanged);
    assert(engine->stats().input==before && capture.stats.discontinuities==0);
    std::printf("PASS hardware feedback -> coherent wire -> actual SWR: native=%+.0fppm source=%+.0fppm residual=%.3fms, stale/PID/epoch never advance DSP\n",nativePPM,sourcePPM,residual*1000.);
}
// The common-clock adapter supplies this mapped time. This is a DSP regression,
// NOT a model of actual network arrival or AudioUnit consumption feedback.
static void checkChangingSkew(int rate) {
    auto engine=std::make_unique<FFmpegAudioTimeline>();
    AVChannelLayout mono=AV_CHANNEL_LAYOUT_MONO;
    assert(engine->configure(rate,AV_SAMPLE_FMT_FLT,mono,19));
    constexpr int frames=1024;
    constexpr unsigned blocks=90000;
    std::array<float,frames> input{};
    std::array<float,2048> output{};
    const uint8_t *planes[]={reinterpret_cast<const uint8_t *>(input.data())};
    double mapped=0, previousEnd=0, previousSample=0, worstResidual=0, worstEdge=0;
    uint64_t total=0, inputSamples=0;
    for(unsigned block=0;block<blocks;++block) {
        // A smoothly changing speed error reverses sign repeatedly. Millisecond
        // rounding exercises FLV-like timestamp resolution without resetting SWR.
        double ppm=500.*std::sin(2*pi*double(block)/30000.);
        double target=1000.+std::round(mapped*1000.)/1000.;
        for(int i=0;i<frames;++i)
            input[i]=float(.2*std::sin(2*pi*440.*double(inputSamples+unsigned(i))/rate));
        assert(engine->push(planes,1,frames,target,19)==AudioEngineResult::Ok);
        inputSamples+=frames;
        mapped+=double(frames)/rate*(1.+ppm/1e6);
        while(engine->available()) {
            AudioEngineBlock result;
            assert(engine->pop(output.data(),int(output.size()),result)==AudioEngineResult::Ok);
            assert(result.frames>0 && result.epoch==19);
            if(total)assert(std::abs(result.masterTime-previousEnd)<.00005);
            previousEnd=result.masterTime+double(result.frames)/48000.;
            for(int i=0;i<result.frames;++i) {
                assert(std::isfinite(output[i]) && std::abs(output[i])<.3);
                if(total || i)worstEdge=std::max(worstEdge,std::abs(double(output[i])-previousSample));
                previousSample=output[i];
            }
            total+=unsigned(result.frames);
        }
        double residual=double(total)/48000.+engine->filterDelay()-mapped;
        worstResidual=std::max(worstResidual,std::abs(residual));
        assert(engine->allocatedSamples()==FFmpegAudioTimeline::Capacity);
        assert(engine->stats.discontinuities==0);
    }
    assert(engine->stats.input==inputSamples && engine->stats.full==0);
    assert(worstResidual<.005 && worstEdge<.03);
    std::printf("PASS actual SWR changing drift + millisecond timestamps: rate=%d modeled=%.1fs maxResidual=%.3fms maxAdjacentStep=%.6f, no reconfigure/reconnect\n",
        rate,double(inputSamples)/rate,worstResidual*1000.,worstEdge);
}
static void checkSkew(int rate,int channels,double ppm) {
    auto engine=std::make_unique<FFmpegAudioTimeline>();
    AVChannelLayout layout{};av_channel_layout_default(&layout,channels);
    assert(engine->configure(rate,AV_SAMPLE_FMT_FLT,layout,11));
    av_channel_layout_uninit(&layout);
    int frames=rate/50;
    std::vector<float> input(size_t(frames)*channels);
    for(int i=0;i<frames;++i)for(int c=0;c<channels;++c)
        input[size_t(i)*channels+c]=float(.2*std::sin(2*pi*1000*i/rate));
    const uint8_t *planes[]={reinterpret_cast<uint8_t*>(input.data())};
    std::array<float,2048> out{};double previousEnd=0;
    uint64_t total=0;unsigned variable=0;
    for(unsigned block=0;block<30000;++block) {
        double target=1000.+block*.020*(1+ppm/1e6);
        assert(engine->push(planes,1,frames,target,11)==AudioEngineResult::Ok);
        assert(engine->allocatedSamples()==FFmpegAudioTimeline::Capacity);
        while(engine->available()) {
            AudioEngineBlock result;
            assert(engine->pop(out.data(),int(out.size()),result)==AudioEngineResult::Ok);
            assert(result.frames>0 && result.epoch==11);
            if(total)assert(std::abs(result.masterTime-previousEnd)<.00005);
            previousEnd=result.masterTime+double(result.frames)/48000;
            for(int i=0;i<result.frames;++i)assert(std::isfinite(out[i])&&std::abs(out[i])<.5);
            variable+=result.frames!=960;total+=unsigned(result.frames);
        }
    }
    double expected=600.*(1+ppm/1e6);
    double residual=double(total)/48000+engine->filterDelay()-expected;
    assert(std::abs(residual)<.004);
    assert(variable>0 && engine->stats.input==uint64_t(30000)*frames);
    std::printf("PASS actual SWR+FIFO: rate=%d channels=%d skew=%+.0fppm residual=%.3fms allocated=%d\n",rate,channels,ppm,residual*1000,engine->allocatedSamples());
}
int main(){
    std::printf("Native FFmpeg runtime: %s (not iOS runtime)\n",av_version_info());
    for(int rate:{44100,48000})for(int channels:{1,2})for(double ppm:{-500.,500.})checkSkew(rate,channels,ppm);
    for(int rate:{44100,48000})checkChangingSkew(rate);
    for(double native:{-500.,500.})for(double source:{-100.,100.})checkCaptureDrivenCompensation(native,source);
    auto engine=std::make_unique<FFmpegAudioTimeline>();
    AVChannelLayout mono=AV_CHANNEL_LAYOUT_MONO;
    assert(engine->configure(48000,AV_SAMPLE_FMT_FLT,mono,1));
    std::array<float,960> input{};
    const uint8_t *planes[]={reinterpret_cast<uint8_t*>(input.data())};
    double time=10;unsigned writes=0;
    while(engine->push(planes,1,960,time,1)==AudioEngineResult::Ok){time+=.020;++writes;assert(writes<200);}
    assert(engine->stats.full==1 && engine->allocatedSamples()==96000);
    assert(engine->stats.input==uint64_t(writes)*960);
    auto before=engine->available();
    assert(engine->push(planes,1,960,time,2)==AudioEngineResult::EpochChanged && engine->available()==before);
    assert(engine->push(planes,1,960,time+1.,1)==AudioEngineResult::Discontinuity && engine->available()==before);
    assert(engine->push(nullptr,1,960,time,1)==AudioEngineResult::Invalid);
    assert(engine->push(planes,0,960,time,1)==AudioEngineResult::Invalid);
    assert(engine->push(planes,1,8193,time,1)==AudioEngineResult::Invalid);
    assert(engine->push(planes,1,960,time-.020,1)==AudioEngineResult::Invalid); // duplicate block cannot enter FIFO
    std::array<float,1024> out{};AudioEngineBlock block;
    assert(engine->pop(out.data(),1024,block)==AudioEngineResult::Ok && block.frames==1024);
    assert(engine->push(planes,1,960,time,1)==AudioEngineResult::Ok); // Full never advanced SWR/PTS
    assert(engine->configure(48000,AV_SAMPLE_FMT_FLT,mono,2));
    assert(engine->available()==0 && engine->push(planes,1,960,100000.,2)==AudioEngineResult::Ok);
    assert(engine->pop(out.data(),1024,block)==AudioEngineResult::Ok && block.epoch==2 && block.masterTime==100000.);
    for(int i=0;i<block.frames;++i)assert(out[i]==0); // a new silent session has no old samples
    AVChannelLayout stereo=AV_CHANNEL_LAYOUT_STEREO;
    assert(engine->configure(48000,AV_SAMPLE_FMT_FLTP,stereo,3));
    const uint8_t *missingPlane[]={planes[0],nullptr};
    assert(engine->push(missingPlane,2,960,0.,3)==AudioEngineResult::Invalid);
    const uint8_t *planar[]={planes[0],planes[0]};
    assert(engine->push(planar,2,960,0.,3)==AudioEngineResult::Ok);
    assert(engine->pop(out.data(),1024,block)==AudioEngineResult::Ok && block.frames>0);
    assert(engine->configure(48000,AV_SAMPLE_FMT_FLT,mono,4));
    assert(engine->push(planes,1,960,0.,4)==AudioEngineResult::Ok);
    assert(engine->push(planes,1,960,1e10,4)==AudioEngineResult::Discontinuity);
    std::puts("PASS bounded FIFO saturation/retry, epoch/discontinuity/invalid guards, restart silent session, planar input validation");
}
