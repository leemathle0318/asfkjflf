#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/CaptureClockWire.hpp"
#include "../core/CaptureClockMailbox.hpp"
#include <cassert>
#include <cstdio>
#include <thread>
using namespace obs::next;
int main() {
    CaptureClockSnapshot source;
    source.cookie=123;source.unit=22;source.generation=7;source.formatVersion=4;
    source.hostAnchor=100.;source.masterAnchor=101.;source.ratio=1.0005;source.reportedAt=100.003;
    source.consumedFrames=900000;source.ready=true;
    source.revision=1;
    auto words=CaptureClockWire::encode(source);
    words[CaptureClockWire::Sequence]=(uint64_t(567)<<32)|2;
    CaptureClockSnapshot result;
    auto read=[&](unsigned i,uint64_t &value){value=words[i];return true;};
    auto status=[&]{return CaptureClockWire::read(read,100.01,123,7,result);};
    assert(status()==CaptureFeedbackState::Ready && result.owner==567 && result.consumedFrames==900000);
    assert(std::abs(result.masterForHost(100.18,100.01)-101.18009)<1e-10);
    assert(std::abs(result.hostForMaster(101.18009,100.01)-100.18)<1e-10);
    assert(std::isnan(result.masterForHost(110.,100.01)));
    assert(CaptureClockWire::read(read,103.,123,7,result)==CaptureFeedbackState::Stale && !result.ready);
    assert(CaptureClockWire::read(read,100.01,124,7,result)==CaptureFeedbackState::Stale);
    assert(CaptureClockWire::read(read,100.01,123,8,result)==CaptureFeedbackState::Stale);
    words[CaptureClockWire::Sequence]|=1;assert(status()==CaptureFeedbackState::Busy);
    words[CaptureClockWire::Sequence]&=~uint64_t(1);
    unsigned calls=0;
    auto torn=[&](unsigned i,uint64_t &value){value=words[i];if(i==0 && calls++)value+=2;return true;};
    assert(CaptureClockWire::read(torn,100.01,123,7,result)==CaptureFeedbackState::Busy && !result.ready);
    auto failed=[&](unsigned i,uint64_t &value){value=words[i];return i!=CaptureClockWire::Ratio;};
    assert(CaptureClockWire::read(failed,100.01,123,7,result)==CaptureFeedbackState::Unavailable);
    words[CaptureClockWire::Ratio]=CaptureClockWire::bits(NAN);assert(status()==CaptureFeedbackState::Invalid);
    words[CaptureClockWire::Ratio]=CaptureClockWire::bits(1.1);assert(status()==CaptureFeedbackState::Invalid);
    for(double boundary:{.998,1.002}) {
        words[CaptureClockWire::Ratio]=CaptureClockWire::bits(boundary);
        assert(status()==CaptureFeedbackState::Ready);
    }
    words[CaptureClockWire::Revision]=0;assert(status()==CaptureFeedbackState::Invalid);
    words[CaptureClockWire::Revision]=1;
    words[CaptureClockWire::Ratio]=CaptureClockWire::bits(1.0005);
    words[CaptureClockWire::Reported]=CaptureClockWire::bits(100.1);assert(status()==CaptureFeedbackState::Stale);
    words[CaptureClockWire::Ready]=0;assert(status()==CaptureFeedbackState::Unavailable);
    words[CaptureClockWire::Sequence]=0;assert(status()==CaptureFeedbackState::Unavailable);
    std::puts("PASS coherent clock wire: valid roundtrip, epoch/PID identity, stale/future, torn/odd/failed IPC and invalid rate guards");
    CaptureClockMailbox mailbox;
    std::atomic<bool> done{false};std::atomic<uint64_t> accepted{0};
    std::thread writer([&]{
        for(uint64_t n=1;n<=200000;++n) {
            auto sample=source;sample.unit=n;sample.consumedFrames=n*1024;sample.revision=n;
            sample.hostAnchor=100.+double(n)*1e-9;sample.masterAnchor=200.+double(n)*1e-9;
            mailbox.publish(sample,567);
        }
        done.store(true);
    });
    do {
        CaptureClockSnapshot sample;
        if(mailbox.read(100.01,123,7,sample)==CaptureFeedbackState::Ready) {
            assert(sample.owner==567 && sample.unit && sample.unit==sample.revision);
            assert(sample.consumedFrames==sample.unit*1024);
            assert(std::abs((sample.masterAnchor-sample.hostAnchor)-100.)<1e-10);
            ++accepted;
        }
    } while(!done.load());
    writer.join();
    assert(mailbox.read(100.01,123,7,result)==CaptureFeedbackState::Ready && result.unit==200000);
    assert(mailbox.read(100.01,124,7,result)==CaptureFeedbackState::Stale && !result.ready);
    std::printf("PASS real concurrent clock mailbox: %llu coherent snapshots; preparation never waits for control IPC\n",(unsigned long long)accepted.load());
}
