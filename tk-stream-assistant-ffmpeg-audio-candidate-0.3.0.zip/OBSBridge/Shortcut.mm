// Legacy source-locator compatibility file. Not built or loaded.
// Volume-button menu and app URL routing were removed.
