#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
namespace obs::next {
// One source->host calibration for BOTH tracks. Observation is single-track,
// using one least-delayed packet per media second, not every jittery arrival.
// SWR does audio stretching; this adapter only supplies common presentation PTS.
class CommonPresentationClock {
    struct Point {double pts=0,host=0;};
    std::array<Point,64> history_{};size_t count_=0,next_=0;
    Point bin_{};bool valid_=false,binValid_=false,audioTrack_=false;
    double originPTS_=0,originHost_=0,rate_=1,startHost_=0,lastAudio_=-1e30;
    double binNumber_=0,lastPTS_=0,lastHost_=0,lastFit_=-1e30,lastRecovery_=-1e30;
    void observations(){count_=next_=0;binValid_=false;lastFit_=-1e30;}
    void anchor(double pts,double now) {
        originPTS_=pts;originHost_=now+.180;rate_=1;valid_=true;lastPTS_=pts;lastHost_=now;observations();
        stats.ratePPM=stats.lastPhaseMS=0;
    }
    void fit(double currentPTS,double now) {
        if(count_<16)return;
        double basePTS=history_[0].pts,baseHost=history_[0].host;
        double mx=0,my=0,xx=0,xy=0,yy=0,minPTS=1e30,maxPTS=-1e30;
        size_t n=0;
        for(size_t i=0;i<count_;++i) {
            auto p=history_[i];double x=p.pts-basePTS,y=p.host-baseHost;
            ++n;double dx=x-mx,dy=y-my;mx+=dx/double(n);my+=dy/double(n);
            xx+=dx*(x-mx);xy+=dx*(y-my);yy+=dy*(y-my);
            minPTS=std::min(minPTS,p.pts);maxPTS=std::max(maxPTS,p.pts);
        }
        if(maxPTS-minPTS<15 || xx<=0)return;
        double slope=xy/xx,rms=std::sqrt(std::max(0.,yy-slope*xy)/double(n));
        if(!std::isfinite(slope) || slope<.998 || slope>1.002 || rms>.003){++stats.rejectedFits;return;}
        double predictedArrival=baseHost+my+slope*(currentPTS-basePTS-mx);
        double present=map(currentPTS),phase=predictedArrival+.180-present;
        double target=std::clamp(slope+std::clamp(phase/30.,-.001,.001),.998,1.002);
        double elapsed=lastFit_<0?1.:std::clamp(now-lastFit_,0.,2.);
        originPTS_=currentPTS;originHost_=present; // no presentation-time step
        rate_+=std::clamp(target-rate_,-.000020*elapsed,.000020*elapsed);
        lastFit_=now;++stats.fits;stats.lastPhaseMS=phase*1000.;stats.ratePPM=(rate_-1.)*1e6;
    }
public:
    struct Result {double due;bool rebased;};
    struct Stats {uint64_t fits=0,rejectedFits=0,discontinuities=0;double ratePPM=0,lastPhaseMS=0;} stats;
    void reset(){*this=CommonPresentationClock{};}
    double map(double pts)const{return valid_?originHost_+(pts-originPTS_)*rate_:NAN;}
    double sourceForHost(double host)const{return valid_?originPTS_+(host-originHost_)/rate_:NAN;}
    static bool usable(double due,double now){return std::isfinite(due)&&due>=now-.25&&due<now+.75;}
    Result schedule(double pts,double now,bool video,bool /*rtmp*/) {
        if(!std::isfinite(pts)||!std::isfinite(now)||now<0)return {NAN,false};
        if(!valid_){startHost_=now;anchor(pts,now);}
        if(!video && !audioTrack_){audioTrack_=true;observations();lastPTS_=pts;lastHost_=now;}
        if(!video)lastAudio_=now;
        if(video && audioTrack_ && now-lastAudio_>2.){audioTrack_=false;observations();lastPTS_=pts;lastHost_=now;}
        bool observe=!video || (!audioTrack_ && now-lastAudio_>2.);
        bool rebased=false;
        if(observe) {
            double dp=pts-lastPTS_,dh=now-lastHost_;
            bool discontinuity=dp<-.100 || (dp>0 && std::fabs(dp-dh)>1.);
            double due=map(pts);
            bool startup=now-startHost_<2. && (due>now+.350 || due<now+.040);
            bool stalled=due<now-.500 || due>now+1.;
            if((discontinuity || startup || stalled) && now-lastRecovery_>=.5) {
                anchor(pts,now);lastRecovery_=now;++stats.discontinuities;rebased=true;
            }
            if(pts>lastPTS_ || !binValid_) {
                // Skip initial probe/backlog arrivals when estimating the slope.
                if(now-startHost_>=1.) {
                    double bin=std::floor(pts);
                    if(!binValid_){bin_={pts,now};binNumber_=bin;binValid_=true;}
                    else if(bin>binNumber_) {
                        history_[next_]=bin_;next_=(next_+1)%history_.size();count_=std::min(count_+1,history_.size());
                        fit(pts,now);bin_={pts,now};binNumber_=bin;
                    } else if(bin==binNumber_ && now-map(pts)<bin_.host-map(bin_.pts))bin_={pts,now};
                }
                lastPTS_=pts;lastHost_=now;
            }
        }
        return {map(pts),rebased};
    }
};
}
