#pragma once
#include "CaptureClockWire.hpp"
#include <atomic>
namespace obs::next {
// One preparation worker publishes; the separate control/IPC queue reads.
// No worker waits for permissions, file operations or notify IPC to finish.
class CaptureClockMailbox {
    std::array<std::atomic<uint64_t>,CaptureClockWire::Count> words_{};
    uint32_t revision_=0;
public:
    static_assert(std::atomic<uint64_t>::is_always_lock_free,"lock-free snapshot required");
    void publish(const CaptureClockSnapshot &snapshot,uint32_t pid) {
        auto words=CaptureClockWire::encode(snapshot);revision_+=2;
        uint64_t sequence=(uint64_t(pid)<<32)|revision_;
        words_[CaptureClockWire::Sequence].store(sequence|1);
        for(unsigned i=1;i<CaptureClockWire::Count;++i)words_[i].store(words[i]);
        words_[CaptureClockWire::Sequence].store(sequence);
    }
    CaptureFeedbackState read(double now,uint64_t cookie,uint32_t generation,CaptureClockSnapshot &snapshot)const {
        return CaptureClockWire::read([&](unsigned index,uint64_t &value){value=words_[index].load();return true;},
                                      now,cookie,generation,snapshot);
    }
};
}
