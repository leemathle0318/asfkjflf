#pragma once
// MIT application adapter. This measures a native sample clock; it is NOT a
// resampler or a second audio PLL. libswresample owns sample-rate compensation.
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <limits>
#include <type_traits>

namespace obs::next {
struct CaptureReport {
    uint64_t cookie=0, unit=0, framePosition=0, captureRevision=1;
    uint32_t generation=0, formatVersion=0, frames=0;
    bool hasSample=false, hasHost=false;
    double sampleTime=0, hostTime=0, callbackTime=0, nominalRate=0;
};
static_assert(std::is_trivially_copyable<CaptureReport>::value,"fixed report required");

// One eligible input unit owns one queue. Its producer must be serialized (the
// hook uses a non-waiting atomic_flag). Only the background worker consumes it.
// Feedback may be dropped when full. PCM is not queued here and is never blocked.
template<uint32_t Capacity=256> class CaptureReportQueue {
    static_assert(Capacity>1 && (Capacity&(Capacity-1))==0 && Capacity<=65536,"power of two required");
    static_assert(std::atomic<uint32_t>::is_always_lock_free,"RT indices must be lock-free");
    static_assert(std::atomic<uint64_t>::is_always_lock_free,"RT counters must be lock-free");
    std::array<CaptureReport,Capacity> slots_{};
    alignas(64) std::atomic<uint32_t> write_{0};
    alignas(64) std::atomic<uint32_t> read_{0};
    std::atomic<uint64_t> dropped_{0};
public:
    bool push(const CaptureReport &report) noexcept {
        uint32_t write=write_.load(std::memory_order_relaxed);
        if(uint32_t(write-read_.load(std::memory_order_acquire))>=Capacity) {
            dropped_.fetch_add(1,std::memory_order_relaxed);return false;
        }
        slots_[write&(Capacity-1)]=report;
        write_.store(write+1,std::memory_order_release);return true;
    }
    bool pop(CaptureReport &report) noexcept {
        uint32_t read=read_.load(std::memory_order_relaxed);
        if(read==write_.load(std::memory_order_acquire))return false;
        report=slots_[read&(Capacity-1)];
        read_.store(read+1,std::memory_order_release);return true;
    }
    uint64_t dropped()const noexcept{return dropped_.load(std::memory_order_relaxed);}
};

// Producer-local state. framePosition advances even if a FEEDBACK report cannot
// enter the queue, so observation loss is not misclassified as lost audio.
class CaptureReportSource {
    CaptureReport previous_{};
    uint64_t position_=0;
    uint64_t revision_=0;
    bool valid_=false;
public:
    template<uint32_t N> bool offer(CaptureReportQueue<N> &queue,CaptureReport report,CaptureReport *ticket=nullptr) noexcept {
        if(ticket)*ticket={};
        if(!report.unit || !report.formatVersion || (report.formatVersion&1) || !report.frames || report.frames>8192 ||
           !std::isfinite(report.nominalRate) || report.nominalRate<8000 || report.nominalRate>192000 ||
           !std::isfinite(report.callbackTime) || report.callbackTime<0)return false;
        bool same=valid_ && previous_.unit==report.unit && previous_.cookie==report.cookie &&
            previous_.generation==report.generation && previous_.formatVersion==report.formatVersion &&
            previous_.nominalRate==report.nominalRate;
        if(!same){position_=0;++revision_;}
        if(same && previous_.frames==report.frames &&
            ((report.hasSample && previous_.hasSample && report.sampleTime==previous_.sampleTime) ||
             (report.hasHost && previous_.hasHost && report.hostTime==previous_.hostTime)))return false;
        if(same && report.hasHost && previous_.hasHost && report.hostTime<previous_.hostTime)return false;
        if(same && report.hasSample && previous_.hasSample && report.hasHost && previous_.hasHost &&
           report.hostTime>previous_.hostTime &&
           std::fabs(report.sampleTime-previous_.sampleTime-double(previous_.frames))>.5) {
            position_=0;++revision_; // real device-timeline discontinuity, not queue loss
        }
        if(position_>std::numeric_limits<uint64_t>::max()-report.frames)return false;
        report.framePosition=position_;report.captureRevision=revision_;
        position_+=report.frames;previous_=report;valid_=true;
        if(ticket)*ticket=report;
        return queue.push(report);
    }
};

enum class CaptureClockResult { Priming, Observed, RateUpdated, Unavailable, Invalid, Stale, Discontinuity, Unreliable };

// Background-only estimator from paired *hardware* sample/host timestamps.
// Callback scheduling times are used ONLY for freshness, never rate estimation.
// A centered, bounded-duration least-squares fit avoids hours-long floating point
// subtraction and rejects bad timestamp domains rather than substituting arrival.
class CaptureClockTracker {
    CaptureReport last_{};
    bool initialized_=false, rateReady_=false;
    double originHost_=0, originSample_=0, ratio_=1;
    double windowHost_=0, windowSample_=0, meanX_=0, meanY_=0, xx_=0, xy_=0, yy_=0;
    uint64_t windowCount_=0;
    uint64_t revision_=0;
    void window(const CaptureReport &r) {
        windowHost_=r.hostTime;windowSample_=r.sampleTime;
        windowCount_=1;meanX_=meanY_=xx_=xy_=yy_=0;
    }
    void anchor(const CaptureReport &r) {
        ++revision_;
        initialized_=true;rateReady_=false;ratio_=1;last_=r;
        originHost_=r.hostTime;originSample_=r.sampleTime;window(r);
    }
    static bool keys(const CaptureReport &a,const CaptureReport &b) {
        return a.captureRevision==b.captureRevision && a.cookie==b.cookie && a.generation==b.generation && a.unit==b.unit &&
            a.formatVersion==b.formatVersion && a.nominalRate==b.nominalRate;
    }
public:
    static constexpr double WindowSeconds=8., MaximumSkew=.002, MaximumFitRMS=.0001;
    struct Stats { uint64_t observed=0, updated=0, invalid=0, unavailable=0, stale=0, discontinuities=0, unreliable=0; } stats;
    CaptureClockResult observe(const CaptureReport &r) {
        if(!r.hasSample || !r.hasHost){++stats.unavailable;return CaptureClockResult::Unavailable;}
        if(!r.unit || !r.formatVersion || (r.formatVersion&1) || !r.frames || r.frames>8192 ||
           !std::isfinite(r.sampleTime) || !std::isfinite(r.hostTime) || r.hostTime<0 ||
           !std::isfinite(r.callbackTime) || r.callbackTime<0 ||
           !std::isfinite(r.nominalRate) || r.nominalRate<8000 || r.nominalRate>192000 ||
           std::fabs(r.hostTime-r.callbackTime)>1.) {
            ++stats.invalid;return CaptureClockResult::Invalid;
        }
        if(!initialized_ || !keys(r,last_)){anchor(r);++stats.observed;return CaptureClockResult::Priming;}
        if(r.framePosition<=last_.framePosition || r.callbackTime<last_.callbackTime) {
            ++stats.stale;return CaptureClockResult::Stale;
        }
        // Out-of-order hardware timestamps are not accepted as new anchors.
        // A real device timeline restart must carry a new format/capture identity.
        if(r.sampleTime<=last_.sampleTime || r.hostTime<=last_.hostTime) {
            ++stats.stale;return CaptureClockResult::Stale;
        }
        double samples=r.sampleTime-last_.sampleTime;
        double consumed=double(r.framePosition-last_.framePosition);
        if(std::fabs(samples-consumed)>.5) {
            anchor(r);++stats.discontinuities;return CaptureClockResult::Discontinuity;
        }
        // A gap in observed reports is allowed. Positions prove how many frames
        // the real input consumed while the worker was delayed or its queue full.
        double x=(r.sampleTime-windowSample_)/r.nominalRate, y=r.hostTime-windowHost_;
        ++windowCount_;
        double dx=x-meanX_, dy=y-meanY_;
        meanX_+=dx/double(windowCount_);meanY_+=dy/double(windowCount_);
        xx_+=dx*(x-meanX_);xy_+=dx*(y-meanY_);yy_+=dy*(y-meanY_);
        last_=r;++stats.observed;
        if(y<WindowSeconds)return CaptureClockResult::Observed;
        double slope=xx_>0 ? xy_/xx_ : 0;
        double rms=slope>0 ? std::sqrt(std::max(0.,yy_-slope*xy_)/double(windowCount_)) : INFINITY;
        double candidate=slope>0 ? 1./slope : INFINITY;
        window(r);
        if(!std::isfinite(candidate) || std::fabs(candidate-1.)>MaximumSkew || rms>MaximumFitRMS) {
            // Never continue publishing an earlier valid rate after hardware
            // timestamps become incoherent. A later clean window can recover.
            rateReady_=false;++stats.unreliable;return CaptureClockResult::Unreliable;
        }
        ratio_=candidate;rateReady_=true;++stats.updated;return CaptureClockResult::RateUpdated;
    }
    bool fresh(double now)const {
        return initialized_ && std::isfinite(now) && now>=0 &&
            now-last_.callbackTime<2. && last_.callbackTime-now<=.0025;
    }
    bool ready(double now)const{return rateReady_ && fresh(now);}
    double rateRatio()const{return ratio_;}
    uint64_t revision()const{return revision_;}
    double ppm()const{return (ratio_-1.)*1e6;}
    const CaptureReport &latest()const{return last_;}
    // These paired conversions express HOST seconds in nominal device-sample
    // seconds and back. A caller must still provide a drift-corrected source->host
    // mapping; raw source PTS is not fixed by this adapter alone.
    double masterForHost(double host,double now)const {
        if(!ready(now))return NAN;
        return estimateForHost(host,now);
    }
    // Usable from the first valid pair, at nominal rate until a full frequency
    // window is available. ready() still distinguishes measured calibration.
    double estimateForHost(double host,double now)const {
        if(!fresh(now) || !std::isfinite(host) || std::fabs(host-last_.hostTime)>2.)return NAN;
        return originHost_+(last_.sampleTime-originSample_)/last_.nominalRate+(host-last_.hostTime)*ratio_;
    }
    double hostForMaster(double master,double now)const {
        if(!ready(now))return NAN;
        return estimateHostForMaster(master,now);
    }
    double estimateHostForMaster(double master,double now)const {
        if(!fresh(now) || !std::isfinite(master))return NAN;
        double latestMaster=originHost_+(last_.sampleTime-originSample_)/last_.nominalRate;
        double host=last_.hostTime+(master-latestMaster)/ratio_;
        return std::fabs(host-last_.hostTime)<=2. ? host : NAN;
    }
};
}
