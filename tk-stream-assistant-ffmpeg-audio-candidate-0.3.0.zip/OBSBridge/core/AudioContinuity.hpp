#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>

namespace obs {
struct AudioReadCoverage {
    size_t requested = 0, found = 0, headGap = 0, tailGap = 0, longestGap = 0;
};
// Per-input state, only touched by that input's guarded render callback.
struct AudioGapMeter {
    uint64_t trailing = 0, longest = 0;
    void observe(const AudioReadCoverage &c) {
        if (!c.requested) return;
        longest = std::max(longest, std::max(uint64_t(c.longestGap), trailing + c.headGap));
        trailing = c.found ? c.tailGap : trailing + c.requested;
    }
};
// Only the program track is tapered. No delayed microphone, old-block replay,
// waiting, allocation, or unbounded concealment. A missing run drains at most
// one millisecond of the last program sample, then remains zero.
struct AudioEdgeRamp {
    float gain = 0, tail = 0;
    unsigned tailLeft = 0;
    void reset() { *this = AudioEdgeRamp{}; }
    bool apply(float *samples, const uint8_t *valid, size_t count, double rate) {
        if (!samples || !valid || !std::isfinite(rate) || rate < 8000 || rate > 192000) return false;
        unsigned ramp = unsigned(std::max(1., std::min(192., std::round(rate * .001))));
        bool output = false;
        size_t i = 0;
        while (i < count) {
            if (!valid[i]) {
                gain = 0;
                samples[i] = tailLeft ? tail * float(--tailLeft) / ramp : 0;
                output |= samples[i] != 0;
                ++i;
                continue;
            }
            size_t end = i + 1;
            while (end < count && valid[end]) ++end;
            bool gapAfter = end < count;
            for (; i < end; ++i) {
                gain = std::min(1.f, gain + 1.f / ramp);
                float edge = gapAfter ? std::min(1.f, float(end - i) / ramp) : 1.f;
                float value = std::isfinite(samples[i]) ? samples[i] : 0;
                samples[i] = value * std::min(gain, edge);
                tail = samples[i]; tailLeft = ramp;
                output |= samples[i] != 0;
            }
        }
        return output;
    }
};
// Do not commit an expensive video render from a superseded receive clock.
inline bool publicationCurrent(uint64_t generation, uint64_t epoch,
                               uint64_t currentGeneration, uint64_t currentEpoch, bool enabled) {
    return enabled && generation == currentGeneration && epoch == currentEpoch;
}
}
