#pragma once
#include "PreparedCapturePCM.hpp"
#include "FFmpegAudioTimeline.hpp"
namespace obs::next {
// ONE background queue owns this object, SWR, FIFO and ring publication.
// Source PCM is on the common HOST timeline. Output PCM is tagged in native
// input-frame positions, at the native nominal sample rate; RT does no resampling.
class CaptureOutputWorker {
    FFmpegAudioTimeline engine_;
    PreparedCapturePCM prepared_;
    PreparedContext context_;
    uint64_t epoch_=0,anchorFrame_=0,writtenEnd_=0,clockRevision_=0,readHostIndex_=0;
    double anchorMaster_=0,readHost_=0,deliveryOffset_=0,retryAfter_=0;
    std::array<double,64> offsets_{};
    size_t offsetCount_=0,offsetNext_=0;
    uint64_t lastOffsetFrame_=UINT64_MAX;
    double phaseTarget_=0,lastPhaseHost_=0,lastMedianHost_=0;
    bool configured_=false;
    std::array<float,480> input_{};
    std::array<float,8192> output_{};
    bool start(const CaptureClockTracker &clock,double now) {
        const auto &r=clock.latest();
        context_={r.cookie,r.unit,r.captureRevision,r.generation,r.formatVersion,uint32_t(std::llround(r.nominalRate))};
        clockRevision_=clock.revision();
        epoch_=prepared_.configure(context_);configured_=false;
        if(!r.cookie || !context_.rate || std::fabs(double(context_.rate)-r.nominalRate)>1e-6 ||
           r.framePosition>UINT64_MAX-r.frames)return false;
        anchorFrame_=r.framePosition;anchorMaster_=clock.estimateForHost(r.hostTime,now);
        // Hardware pairs measure frequency; delivery latency is a separate
        // robust phase measurement. Never feed individual callback jitter to SWR.
        deliveryOffset_=r.callbackTime-r.hostTime;
        phaseTarget_=deliveryOffset_;lastPhaseHost_=lastMedianHost_=now;
        offsetCount_=offsetNext_=0;lastOffsetFrame_=UINT64_MAX;
        writtenEnd_=r.framePosition+r.frames;
        double startMaster=anchorMaster_+double(writtenEnd_-anchorFrame_)/context_.rate;
        readHost_=clock.estimateHostForMaster(startMaster,now)+deliveryOffset_;
        if(!std::isfinite(readHost_) || readHost_<0 || readHost_>1e10)return false;
        readHostIndex_=uint64_t(std::llround(readHost_*48000.));readHost_=double(readHostIndex_)/48000.;
        AVChannelLayout mono=AV_CHANNEL_LAYOUT_MONO;
        configured_=std::isfinite(readHost_) && engine_.configure(48000,AV_SAMPLE_FMT_FLT,mono,epoch_,int(context_.rate));
        ++stats.rebuffers;return configured_;
    }
public:
    struct Stats { uint64_t rebuffers=0,reads=0,waiting=0,failed=0,prepared=0; } stats;
    PreparedCapturePCM *prepared(){return &prepared_;}
    const PreparedContext &context()const{return context_;}
    uint64_t writtenEnd()const{return writtenEnd_;}
    void stop(){prepared_.invalidate();engine_.close();configured_=false;}
    template<class ReadHostPCM> void tick(const CaptureClockTracker &clock,double now,ReadHostPCM read) {
        const auto &r=clock.latest();
        if(now<retryAfter_ || !clock.fresh(now) || !r.cookie || now-r.callbackTime>.25)return;
        PreparedContext desired{r.cookie,r.unit,r.captureRevision,r.generation,r.formatVersion,uint32_t(std::llround(r.nominalRate))};
        if(!configured_ || !(context_==desired) || clockRevision_!=clock.revision() || readHost_<now-.15) {
            if(!start(clock,now)){++stats.failed;retryAfter_=now+1.;return;}
        }
        if(lastOffsetFrame_!=r.framePosition) {
            offsets_[offsetNext_]=r.callbackTime-r.hostTime;offsetNext_=(offsetNext_+1)%offsets_.size();
            offsetCount_=std::min(offsetCount_+1,offsets_.size());lastOffsetFrame_=r.framePosition;
        }
        if(offsetCount_>=8 && now-lastMedianHost_>=.5) {
            auto sorted=offsets_;std::sort(sorted.begin(),sorted.begin()+offsetCount_);
            phaseTarget_=sorted[offsetCount_/2];lastMedianHost_=now;
        }
        double elapsed=std::clamp(now-lastPhaseHost_,0.,.1);lastPhaseHost_=now;
        // At most 0.5ms phase change/second (500ppm), in addition to measured
        // hardware drift. Continuous latency creep must not become hours of lag.
        deliveryOffset_+=std::clamp(phaseTarget_-deliveryOffset_,-.0005*elapsed,.0005*elapsed);
        // Bounded lookahead, not FIFO capacity as latency. A ten-ms feed plus
        // 80ms native headroom fits the source receiver's normal 180ms lead.
        uint64_t headroom=uint64_t(r.frames)+uint64_t(std::ceil(context_.rate*.080));
        if(r.framePosition>UINT64_MAX-headroom){++stats.failed;return;}
        uint64_t target=r.framePosition+headroom;
        for(unsigned job=0;job<16 && writtenEnd_<target;++job) {
            ++stats.reads;
            if(!read(input_.data(),input_.size(),readHost_)){++stats.waiting;return;}
            double due=clock.estimateForHost(readHost_-deliveryOffset_,now);
            const uint8_t *planes[]={reinterpret_cast<const uint8_t *>(input_.data())};
            auto result=engine_.push(planes,1,int(input_.size()),due,epoch_);
            if(result!=AudioEngineResult::Ok){++stats.failed;configured_=false;prepared_.invalidate();return;}
            readHostIndex_+=input_.size();readHost_=double(readHostIndex_)/48000.;
            while(engine_.available()) {
                AudioEngineBlock block;
                if(engine_.pop(output_.data(),int(output_.size()),block)!=AudioEngineResult::Ok || !block.frames){++stats.failed;return;}
                double offset=(block.masterTime-anchorMaster_)*context_.rate;
                if(!std::isfinite(offset) || offset<0 || offset>double(INT64_MAX/2)) {++stats.failed;return;}
                uint64_t delta=uint64_t(std::llround(offset));
                if(anchorFrame_>UINT64_MAX-delta){++stats.failed;return;}
                uint64_t first=anchorFrame_+delta;
                if(first>UINT64_MAX-uint64_t(block.frames) ||
                   !prepared_.write(epoch_,output_.data(),size_t(block.frames),first,uint64_t(now*1000000.))) {++stats.failed;return;}
                writtenEnd_=first+uint64_t(block.frames);stats.prepared+=unsigned(block.frames);
            }
        }
    }
};
}
