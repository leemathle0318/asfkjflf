#pragma once
#include "CaptureClockFeedback.hpp"
#include "AudioContinuity.hpp"
#include <cstring>
namespace obs::next {
struct PreparedContext {
    uint64_t cookie=0,unit=0,captureRevision=0;
    uint32_t generation=0,formatVersion=0,rate=0;
    bool operator==(const PreparedContext &b)const {
        return cookie==b.cookie && unit==b.unit && captureRevision==b.captureRevision &&
            generation==b.generation && formatVersion==b.formatVersion && rate==b.rate;
    }
};
// Process-local, one worker writer. Every shared payload access is atomic.
// Full-width native frame tags avoid the 32-bit sample-tag wrap at ~24.8h/48k.
// Cell seqlocks use seq_cst atomics including payload (no C++ data-race seqlock).
// Readers have one attempt/cell, never retry or wait, and never allocate.
class PreparedCapturePCM {
    struct Cell {
        std::atomic<uint64_t> sequence{0},tag{0},epoch{0};
        std::atomic<uint32_t> value{0};
    };
public:
    static constexpr size_t Capacity=32768;
private:
    std::array<Cell,Capacity> samples_;
    std::atomic<uint64_t> epoch_{0},cookie_{0},unit_{0},captureRevision_{0},heartbeatUS_{0};
    std::atomic<uint32_t> generation_{0},format_{0},rate_{0};
    std::atomic<bool> ready_{false};
    bool matches(const PreparedContext &c)const {
        return cookie_.load()==c.cookie && unit_.load()==c.unit && captureRevision_.load()==c.captureRevision &&
            generation_.load()==c.generation && format_.load()==c.formatVersion && rate_.load()==c.rate;
    }
public:
    uint64_t configure(const PreparedContext &c) {
        ready_.store(false);uint64_t epoch=epoch_.fetch_add(1)+1;
        cookie_.store(c.cookie);unit_.store(c.unit);captureRevision_.store(c.captureRevision);
        generation_.store(c.generation);format_.store(c.formatVersion);rate_.store(c.rate);
        heartbeatUS_.store(0);return epoch;
    }
    void invalidate(){ready_.store(false);epoch_.fetch_add(1);}
    bool write(uint64_t epoch,const float *data,size_t count,uint64_t start,uint64_t nowUS) {
        if(epoch!=epoch_.load() || !data || !count || count>Capacity || start>UINT64_MAX-count)return false;
        for(size_t i=0;i<count;++i) {
            auto &cell=samples_[size_t((start+i)%Capacity)];
            uint64_t seq=cell.sequence.load();cell.sequence.store(seq+1);
            float sample=std::isfinite(data[i])?data[i]:0;uint32_t bits;std::memcpy(&bits,&sample,4);
            cell.tag.store(start+i);cell.epoch.store(epoch);cell.value.store(bits);cell.sequence.store(seq+2);
        }
        heartbeatUS_.store(nowUS);ready_.store(true);return true;
    }
    bool read(const PreparedContext &c,uint64_t start,float *out,uint8_t *valid,size_t frames,uint64_t nowUS,
              obs::AudioReadCoverage &coverage,uint64_t *readEpoch=nullptr)const {
        if(readEpoch)*readEpoch=0;
        coverage={};
        if(!out || !valid || !frames || frames>8192 || start>UINT64_MAX-frames)return false;
        std::fill(out,out+frames,0);std::fill(valid,valid+frames,0);
        coverage.requested=frames;coverage.headGap=coverage.tailGap=coverage.longestGap=frames;
        uint64_t epoch=epoch_.load(),heart=heartbeatUS_.load();
        if(!epoch || !ready_.load() || !matches(c) || !heart ||
           (heart>nowUS?heart-nowUS>2500:nowUS-heart>500000))return false;
        if(readEpoch)*readEpoch=epoch;
        coverage.headGap=coverage.tailGap=coverage.longestGap=0;size_t gap=0;
        for(size_t i=0;i<frames;++i) {
            const auto &cell=samples_[size_t((start+i)%Capacity)];
            uint64_t before=cell.sequence.load(),tag=cell.tag.load(),cellEpoch=cell.epoch.load();
            uint32_t bits=cell.value.load();uint64_t after=cell.sequence.load();
            float sample;std::memcpy(&sample,&bits,4);
            if(!(before&1) && before==after && cellEpoch==epoch && tag==start+i && std::isfinite(sample)) {
                out[i]=sample;valid[i]=1;++coverage.found;gap=0;
            } else {
                ++gap;coverage.longestGap=std::max(coverage.longestGap,gap);
                if(!coverage.found)++coverage.headGap;
            }
        }
        coverage.tailGap=gap;
        if(epoch!=epoch_.load() || !ready_.load() || !matches(c)) {
            std::fill(out,out+frames,0);std::fill(valid,valid+frames,0);
            coverage.found=0;coverage.headGap=coverage.tailGap=coverage.longestGap=frames;
            if(readEpoch)*readEpoch=0;
        }
        return coverage.found!=0;
    }
};
}
