#pragma once
#import <Foundation/Foundation.h>
#import <CoreVideo/CoreVideo.h>
#include "core/SharedMedia.hpp"
#include "core/MappedMedia.hpp"
#include <sys/mman.h>
#include <memory>
#include "core/VideoTransform.hpp"

// Producer methods are only used in SpringBoard. The mapped file persists
// for that process's lifetime, including while receiving is stopped.
NSString *OBBusCreate(void);
void OBBusEnable(BOOL enabled);
void OBBusHeartbeat(void);
void OBBusResetAudio(void);
void OBBusWriteAudio(const float *samples, size_t count, double due);
// Producer queue owns this bounded staging lease. Pixels are prepared without
// holding the receiver clock mutex; commit is only short metadata publication.
struct OBVideoPublication {
    obs::VideoSlot *lease = nullptr;
    uint32_t generation = 0;
    unsigned slot = 0;
    double due = 0;
    bool ready = false;
    OBVideoPublication() = default;
    OBVideoPublication(const OBVideoPublication &) = delete;
    OBVideoPublication &operator=(const OBVideoPublication &) = delete;
    ~OBVideoPublication();
};
BOOL OBBusPrepareVideo(CVPixelBufferRef source, double due, OBVideoPublication &publication);
BOOL OBBusCommitVideo(OBVideoPublication &publication);
NSString *OBBusProducerStatus(void);
uint64_t OBBusSession(void);
// Local producer identity; no IPC or consumer mapping. Background-only.
bool OBBusProducerIdentity(uint64_t &cookie,uint32_t &generation);
void OBBusSetVideoRotation(unsigned quarterTurns);
unsigned OBBusVideoRotation(void);
void OBBusSetVideoProfile(unsigned profile);
unsigned OBBusVideoProfile(void);
void OBBusSetLiveAudioEnabled(BOOL enabled);
BOOL OBBusLiveAudioEnabled(void); // background-only notification read
BOOL OBBusMediaVersionReady(void); // background-only, PID-bound version check
void OBBusClearVideoSnapshot(void);
// Consumer mappings report lookup failures rather than silently failing.
struct OBMapping {
    const obs::MappedMedia *memory;
    const obs::SharedMedia *data;
    explicit OBMapping(obs::MappedMedia *m) : memory(m), data(&m->state) {}
    ~OBMapping() { munmap(const_cast<obs::MappedMedia *>(memory), sizeof(obs::MappedMedia)); }
};
struct OBVideoLease {
    std::shared_ptr<OBMapping> mapping;
    CVPixelBufferRef pixel;
    OBVideoLease(std::shared_ptr<OBMapping> m, CVPixelBufferRef p) : mapping(m), pixel(p) {}
    ~OBVideoLease() { CVPixelBufferRelease(pixel); } // owns a private snapshot; no shared lease writes
};
std::shared_ptr<OBMapping> OBBusConsumer(void);
NSString *OBBusConsumerError(void);
// A private pixel snapshot is returned; readers never write the mapped file.
std::unique_ptr<OBVideoLease> OBBusCopyVideo(void);
void OBMediaHeartbeat(uint32_t hookCount, uint64_t videoCalls, uint64_t audioCalls,
                      uint64_t replaced, uint64_t mixed, uint32_t failure);
NSString *OBMediaStatus(void);
void OBMediaAudioState(uint64_t phase, uint64_t format, uint64_t layout, uint64_t timing);
FOUNDATION_EXPORT NSString *OBMediaAudioStatus(void);
FOUNDATION_EXPORT double OBNow(void);
void OBMediaVideoCounters(uint64_t rendered, uint64_t reused, uint64_t black, uint64_t failed);

void OBBusSetTransform(obs::VideoTransform value);
obs::VideoTransform OBBusTransform(void);

void OBMediaVideoFailures(uint64_t unsupported, uint64_t allocation, uint64_t exception, uint64_t copy, uint64_t target);
