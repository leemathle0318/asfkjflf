#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
SOURCE="$ROOT/work/ffmpeg-7.1.5"
BUILD="$ROOT/work/ffmpeg-host-build"
PREFIX="$ROOT/work/ffmpeg-host-install"
[ "$(uname -s)" = Darwin ] || { echo 'Requires macOS host compiler.'; exit 1; }
[ -f "$SOURCE/configure" ] || { echo 'Build pinned iOS FFmpeg sources first.'; exit 1; }
mkdir -p "$BUILD"
(
  cd "$BUILD"
  "$SOURCE/configure" --prefix="$PREFIX" --cc="$(xcrun --find clang)" \
    --disable-everything --disable-autodetect --disable-programs --disable-network \
    --disable-doc --disable-debug --disable-asm --disable-shared --enable-static \
    --disable-avcodec --disable-avformat --disable-avdevice --disable-avfilter \
    --disable-swscale --disable-postproc --enable-avutil --enable-swresample
  make -j"$(sysctl -n hw.ncpu)"
  make install
)
for NAME in capture_clock capture_wire common_clock ffmpeg_timeline prepared_capture full_audio_pipeline; do
  xcrun clang++ -std=c++17 -Wall -Wextra -Werror -O2 -UNDEBUG \
    -I"$PREFIX/include" "tests/${NAME}_tests.cpp" \
    "$PREFIX/lib/libswresample.a" "$PREFIX/lib/libavutil.a" \
    -o "work/${NAME}_tests"
  "work/${NAME}_tests" 2>&1 | tee "work/${NAME}-test.log"
done
# Use the pinned library for long-duration PCM as well as short edge cases.
# This is accelerated modeled IO, not a four-hour iPhone/audience test.
"work/full_audio_pipeline_tests" 14400 both 2>&1 | tee work/full_audio_pipeline-long-test.log

echo 'Pinned FFmpeg 7.1.5 native host tests passed; NOT iPhone or audience verification.'
