"""Rename the checked export only; keep the installed package identity intact."""
from pathlib import Path
import re
import sys


def rename_export(folder, version="0.3.0"):
    root = Path(folder).resolve()
    if not re.fullmatch(r"[0-9A-Za-z.+_~-]+", version):
        raise ValueError("invalid version")
    files = sorted(root.glob("*.deb"))
    if len(files) != 1 or files[0].is_symlink():
        raise ValueError("expected exactly one checked package")
    source = files[0]
    destination = root / f"tk推流助手_{version}_iphoneos-arm64.deb"
    if source.resolve().parent != root or destination.resolve().parent != root:
        raise ValueError("export path escapes package directory")
    if source != destination:
        if destination.exists():
            raise ValueError("destination already exists")
        source.rename(destination)
    return destination


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: name_package.py PACKAGE_DIRECTORY")
    print(rename_export(sys.argv[1]).name)
