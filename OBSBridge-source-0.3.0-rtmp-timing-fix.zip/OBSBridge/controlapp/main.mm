#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreImage/CoreImage.h>
#import <Metal/Metal.h>
#import "../Client.h"
#import "../MediaBus.h"
#include "../core/VideoContinuity.hpp"
#include <arpa/inet.h>

@interface OBScan : UIViewController <AVCaptureMetadataOutputObjectsDelegate>
@property(nonatomic,strong) AVCaptureSession *session;
@property(nonatomic,strong) AVCaptureVideoPreviewLayer *layer;
@property(nonatomic,copy) void (^found)(NSString *);
@end
@implementation OBScan
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=UIColor.blackColor;self.title=@"扫描电脑视频通道二维码";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancel)];
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted){
        dispatch_async(dispatch_get_main_queue(),^{
            if(!granted){[self cancel];return;}
            self.session=[AVCaptureSession new];self.session.sessionPreset=AVCaptureSessionPreset640x480;
            NSError *error=nil;AVCaptureDeviceInput *input=[AVCaptureDeviceInput deviceInputWithDevice:[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo] error:&error];
            AVCaptureMetadataOutput *output=[AVCaptureMetadataOutput new];
            if(!input || ![self.session canAddInput:input] || ![self.session canAddOutput:output]){[self cancel];return;}
            [self.session addInput:input];[self.session addOutput:output];[output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
            if(![output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeQRCode]){[self cancel];return;}
            output.metadataObjectTypes=@[AVMetadataObjectTypeQRCode];
            self.layer=[AVCaptureVideoPreviewLayer layerWithSession:self.session];self.layer.videoGravity=AVLayerVideoGravityResizeAspectFill;
            [self.view.layer addSublayer:self.layer];self.layer.frame=self.view.bounds;
            AVCaptureSession *session=self.session;dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{[session startRunning];});
        });
    }];
}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];self.layer.frame=self.view.bounds;}
- (void)cancel {[self dismissViewControllerAnimated:YES completion:nil];}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];AVCaptureSession *session=self.session;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{[session stopRunning];});
}
- (void)captureOutput:(AVCaptureOutput *)output didOutputMetadataObjects:(NSArray *)objects fromConnection:(AVCaptureConnection *)connection {
    (void)output;(void)connection;
    for(AVMetadataObject *object in objects)if([object isKindOfClass:AVMetadataMachineReadableCodeObject.class]){
        NSString *text=((AVMetadataMachineReadableCodeObject *)object).stringValue;
        if(text.length && self.found){void (^found)(NSString *)=self.found;self.found=nil;[self dismissViewControllerAnimated:YES completion:^{found(text);}];break;}
    }
}
@end

@interface OBSettings : UIViewController
@property(nonatomic,strong) UITextField *address;
@property(nonatomic,strong) UIImageView *preview;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) NSMutableDictionary *values;
@property(nonatomic,strong) NSMutableDictionary<NSString *,UISlider *> *sliders;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) CIContext *context;
@property(nonatomic,strong) UIButton *previewButton;
@property(nonatomic) BOOL previewEnabled;
@property(nonatomic,copy) NSString *previewError;
@property(nonatomic) CGPoint panStart;
@property(nonatomic) CGFloat zoomStart;
@property(nonatomic) BOOL sendingHeartbeat;
@property(nonatomic) CFTimeInterval lastHeartbeat;
@end
@implementation OBSettings
- (void)message:(NSString *)text {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"RTMP" message:text preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];
}
- (UIButton *)button:(NSString *)title selector:(SEL)selector {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];[b setTitle:title forState:UIControlStateNormal];
    [b addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];return b;
}
- (void)viewDidLoad {
    [super viewDidLoad];self.title=@"RTMP / 画面调整 · 启动修复1";self.view.backgroundColor=UIColor.systemBackgroundColor;
    self.values=[@{@"zoom":@1,@"x":@0,@"y":@0,@"left":@0,@"right":@0,@"top":@0,@"bottom":@0} mutableCopy];
    [self.values addEntriesFromDictionary:OBCTransform()];self.sliders=[NSMutableDictionary dictionary];
    // The reported iOS 15.0.2 launch crashed inside CI::GLContext when the
    // default CIContext selected OpenGL. Do not initialize a renderer on launch.
    // Preview is opt-in; RTMP, pairing and numeric adjustments work without it.
    UIScrollView *scroll=[UIScrollView new];scroll.translatesAutoresizingMaskIntoConstraints=NO;[self.view addSubview:scroll];
    UIStackView *stack=[UIStackView new];stack.axis=UILayoutConstraintAxisVertical;stack.spacing=10;stack.translatesAutoresizingMaskIntoConstraints=NO;[scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor], [scroll.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor],
        [scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],[scroll.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor constant:16],[stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor constant:-16],
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:12],[stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-20],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor constant:-32]]];
    UILabel *hint=[UILabel new];hint.numberOfLines=0;hint.text=@"电脑视频通道用此处配对；TikTok账号由手机TikTok扫描电脑官方登录码，两者无关。裁剪和缩放只改替换画面，不重编码素材。";[stack addArrangedSubview:hint];
    self.address=[UITextField new];self.address.placeholder=@"rtmp://电脑IP:1935/live/通道";self.address.text=OBCRtmpURL();self.address.borderStyle=UITextBorderStyleRoundedRect;
    self.address.autocorrectionType=UITextAutocorrectionTypeNo;self.address.autocapitalizationType=UITextAutocapitalizationTypeNone;[stack addArrangedSubview:self.address];
    [stack addArrangedSubview:[self button:@"扫码绑定视频通道" selector:@selector(scan)]];
    [stack addArrangedSubview:[self button:@"粘贴配对码（也可粘贴二维码文字）" selector:@selector(paste)]];
    [stack addArrangedSubview:[self button:@"开始 RTMP" selector:@selector(start)]];
    [stack addArrangedSubview:[self button:@"停止并恢复真实摄像头" selector:@selector(stop)]];
    self.previewButton=[self button:@"显示调整预览（默认关闭，不影响直播画面）" selector:@selector(togglePreview)];
    [stack addArrangedSubview:self.previewButton];
    self.preview=[UIImageView new];self.preview.backgroundColor=UIColor.blackColor;self.preview.contentMode=UIViewContentModeScaleAspectFit;
    self.preview.userInteractionEnabled=YES;[self.preview.heightAnchor constraintEqualToConstant:300].active=YES;[stack addArrangedSubview:self.preview];
    [self.preview addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    [self.preview addGestureRecognizer:[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinch:)]];
    NSArray *keys=@[@"zoom",@"x",@"y",@"left",@"right",@"top",@"bottom"];
    NSArray *names=@[@"缩放 1–4倍（也可双指缩放）",@"左右位置（也可拖动画面）",@"上下位置",@"裁剪左侧 0–45%",@"裁剪右侧 0–45%",@"裁剪顶部 0–45%",@"裁剪底部 0–45%"];
    for(NSUInteger i=0;i<keys.count;++i){
        UILabel *label=[UILabel new];label.text=names[i];[stack addArrangedSubview:label];
        UISlider *slider=[UISlider new];slider.tag=(NSInteger)i;slider.minimumValue=i==0?1:(i<3?-1:0);slider.maximumValue=i==0?4:(i<3?1:.45);
        slider.value=[self.values[keys[i]] floatValue];[slider addTarget:self action:@selector(slider:) forControlEvents:UIControlEventValueChanged];
        self.sliders[keys[i]]=slider;[stack addArrangedSubview:slider];
    }
    [stack addArrangedSubview:[self button:@"额外旋转 +90°" selector:@selector(rotate)]];
    [stack addArrangedSubview:[self button:@"输出方向：竖屏 / 横屏（默认竖屏，点击切换）" selector:@selector(outputDirection)]];
    [stack addArrangedSubview:[self button:@"恢复默认裁剪与缩放" selector:@selector(reset)]];
    self.status=[UILabel new];self.status.numberOfLines=0;self.status.font=[UIFont systemFontOfSize:12];[stack addArrangedSubview:self.status];
    self.timer=[NSTimer scheduledTimerWithTimeInterval:.3 target:self selector:@selector(update) userInfo:nil repeats:YES];
}
- (void)start {NSString *e=OBCStartRTMP(self.address.text);[self message:e?:@"启动请求已发送；请在手机直播预览和观众端确认画面、声音。"] ;}
- (void)stop {NSString *e=OBCSendCommand(NO,nil);if(e)[self message:e];}
- (void)scan {
    // Stop replacement before scanning; otherwise the scanner would see the substituted video.
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"扫描视频通道" message:@"继续将停止画面替换，可能露出真实摄像头。请在开播前扫码；正在直播时建议用粘贴配对文字。取消此提示不会停止接收。" preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"继续扫码" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        (void)action;NSString *error=OBCSendCommand(NO,nil);
        if(error){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{[self message:error];});return;}
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{
            OBScan *s=[OBScan new];s.found=^(NSString *text){[self pair:text];};
            [self presentViewController:[[UINavigationController alloc] initWithRootViewController:s] animated:YES completion:nil];
        });
    }]];[self presentViewController:a animated:YES completion:nil];
}
- (void)paste {NSString *s=UIPasteboard.generalPasteboard.string;if(s.length)[self pair:s];else [self message:@"剪贴板没有配对文字；也可直接填写RTMP地址。"] ;}
- (void)pair:(NSString *)text {
    if([text hasPrefix:@"rtmp://"]){self.address.text=text;return;}
    NSURLComponents *u=[NSURLComponents componentsWithString:text];NSMutableDictionary *q=[NSMutableDictionary dictionary];
    for(NSURLQueryItem *i in u.queryItems)if(i.value)q[i.name]=i.value;
    struct in_addr ip;NSInteger port=[q[@"port"] integerValue];
    if(![u.scheme isEqual:@"meowrtmp"] || ![u.host isEqual:@"pair"] || !q[@"server"] || inet_pton(AF_INET,[q[@"server"] UTF8String],&ip)!=1 || port<1 || port>65535 || [q[@"token"] length]>128 || ![q[@"token"] length]){[self message:@"不是有效的视频通道配对码。TikTok登录码请用TikTok扫描。"] ;return;}
    NSString *device=[[NSUserDefaults standardUserDefaults] stringForKey:@"DeviceID"];
    if(!device){device=NSUUID.UUID.UUIDString;[[NSUserDefaults standardUserDefaults] setObject:device forKey:@"DeviceID"];}
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@:%ld/pair",q[@"server"],(long)port]]];
    request.HTTPMethod=@"POST";request.timeoutInterval=6;[request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    request.HTTPBody=[NSJSONSerialization dataWithJSONObject:@{@"token":q[@"token"],@"device":device} options:0 error:nil];
    [[NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *data,NSURLResponse *response,NSError *error){
        NSDictionary *d=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:nil]:nil;
        dispatch_async(dispatch_get_main_queue(),^{
            if(error || ![d isKindOfClass:NSDictionary.class] || ((NSHTTPURLResponse *)response).statusCode!=200 || ![d[@"rtmp"] isKindOfClass:NSString.class]){[self message:error.localizedDescription?:d[@"error"]?:@"配对失败"];return;}
            NSMutableDictionary *pair=[d mutableCopy];pair[@"device"]=device;
            NSString *failure=OBCSavePairing(pair);if(failure){[self message:failure];return;}
            self.address.text=d[@"rtmp"];[self message:@"视频通道配对成功，点击开始RTMP。"];
        });
    }] resume];
}
- (void)save {
    for(NSString *key in self.sliders)self.sliders[key].value=[self.values[key] floatValue];
    NSString *e=OBCSaveTransform(self.values);if(e)self.status.text=e;
}
- (void)slider:(UISlider *)s {NSArray *keys=@[@"zoom",@"x",@"y",@"left",@"right",@"top",@"bottom"];self.values[keys[(NSUInteger)s.tag]]=@(s.value);[self save];}
- (void)pan:(UIPanGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan)self.panStart=CGPointMake([self.values[@"x"] doubleValue],[self.values[@"y"] doubleValue]);
    CGPoint t=[g translationInView:self.preview];self.values[@"x"]=@(MAX(-1,MIN(1,self.panStart.x+t.x/150)));self.values[@"y"]=@(MAX(-1,MIN(1,self.panStart.y+t.y/150)));[self save];
}
- (void)pinch:(UIPinchGestureRecognizer *)g {
    if(g.state==UIGestureRecognizerStateBegan)self.zoomStart=[self.values[@"zoom"] doubleValue];self.values[@"zoom"]=@(MAX(1,MIN(4,self.zoomStart*g.scale)));[self save];
}
- (void)rotate {NSString *e=OBCSetVideoRotation(OBCVideoRotation()+1);if(e)[self message:e];}
- (void)outputDirection {BOOL landscape=![self.values[@"landscape"] boolValue];self.values[@"landscape"]=@(landscape);[self save];[self message:landscape?@"当前按横屏输出调整。素材比例不限。":@"当前按竖屏输出调整。素材比例不限。"] ;}
- (void)reset {for(NSString *k in self.values.allKeys)self.values[k]=[k isEqual:@"zoom"]?@1:@0;[self save];}
- (void)togglePreview {
    self.previewEnabled=!self.previewEnabled;self.previewError=nil;
    if(!self.previewEnabled){self.preview.image=nil;self.context=nil;}
    [self.previewButton setTitle:self.previewEnabled?@"关闭调整预览":@"显示调整预览（默认关闭，不影响直播画面）" forState:UIControlStateNormal];
    [self update];
}
- (void)disablePreview:(NSString *)reason {
    self.previewEnabled=NO;self.previewError=reason;self.context=nil;self.preview.image=nil;
    [self.previewButton setTitle:@"重新开启调整预览" forState:UIControlStateNormal];
    self.status.text=[NSString stringWithFormat:@"%@\n预览已关闭：%@。RTMP与调整按钮仍可使用。",OBCStatus(),reason];
}
- (BOOL)preparePreview {
    if(self.context)return YES;
    // Explicit Metal construction has no default/OpenGL fallback. A nil device
    // or Objective-C exception disables only this optional local preview.
    // @catch does NOT catch a SIGSEGV; never claim it shields driver crashes.
    @try {
        id<MTLDevice> device=MTLCreateSystemDefaultDevice();
        if(!device){[self disablePreview:@"没有可用的Metal设备"];return NO;}
        self.context=[CIContext contextWithMTLDevice:device options:@{kCIContextCacheIntermediates:@NO}];
        if(!self.context){[self disablePreview:@"Metal预览初始化失败"];return NO;}
    } @catch(NSException *exception) {
        [self disablePreview:[NSString stringWithFormat:@"%@：%@",exception.name,exception.reason?:@"初始化异常"]];return NO;
    }
    return YES;
}
- (void)update {
    if(UIApplication.sharedApplication.applicationState!=UIApplicationStateActive || !self.view.window || self.presentedViewController)return;
    self.status.text=self.previewError?[NSString stringWithFormat:@"%@\n预览已关闭：%@。RTMP与调整按钮仍可使用。",OBCStatus(),self.previewError]:OBCStatus();
    if(!self.previewEnabled)return;
    auto chosen=OBBusCopyVideo();
    if(chosen){
        if(![self preparePreview])return;
        CIImage *im=[[CIImage imageWithCVPixelBuffer:chosen->pixel] imageByApplyingOrientation:obs::extraOrientation((unsigned)OBCVideoRotation())];
        obs::VideoTransform t;t.zoom=[self.values[@"zoom"] doubleValue];t.x=[self.values[@"x"] doubleValue];t.y=[self.values[@"y"] doubleValue];
        t.left=[self.values[@"left"] doubleValue];t.right=[self.values[@"right"] doubleValue];t.top=[self.values[@"top"] doubleValue];t.bottom=[self.values[@"bottom"] doubleValue];t.normalize();
        t.landscape=[self.values[@"landscape"] boolValue];
        CGRect f=im.extent;im=[im imageByCroppingToRect:CGRectMake(f.origin.x+f.size.width*t.left,f.origin.y+f.size.height*t.bottom,f.size.width*(1-t.left-t.right),f.size.height*(1-t.top-t.bottom))];f=im.extent;
        double w=t.landscape?320:180,h=t.landscape?180:320;auto g=obs::fillGeometry(f.size.width,f.size.height,w,h,t);
        im=[im imageByApplyingTransform:CGAffineTransformMakeTranslation(-f.origin.x,-f.origin.y)];im=[im imageByApplyingTransform:CGAffineTransformMakeScale(g.scale,g.scale)];im=[im imageByApplyingTransform:CGAffineTransformMakeTranslation(g.tx,g.ty)];
        CGImageRef image=[self.context createCGImage:im fromRect:CGRectMake(0,0,w,h)];if(image){self.preview.image=[UIImage imageWithCGImage:image];CGImageRelease(image);}
    }else self.preview.image=nil;
}
@end

@interface OBApp : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation OBApp
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    (void)application;(void)options;self.window=[[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController=[[UINavigationController alloc] initWithRootViewController:[OBSettings new]];[self.window makeKeyAndVisible];return YES;
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary *)options {(void)application;(void)url;(void)options;return YES;}
@end
int main(int argc,char **argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass(OBApp.class));}}
