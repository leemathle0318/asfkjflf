#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <substrate.h>
#import "MediaBus.h"
#import "SandboxAccess.h"
#import "Shared.h"
#include "core/LiveAudio.hpp"
#include <notify.h>
#include <dlfcn.h>
#include <array>
#include <atomic>
#include <mutex>
#include <unistd.h>

namespace {
constexpr size_t MaximumUnits = 64, MaximumMappings = 8;
struct Unit {
    std::atomic<uintptr_t> handle{0};
    std::atomic<bool> alive{false};
    std::atomic<uint32_t> sequence{0}, type{0}, subtype{0}, manufacturer{0};
    std::atomic<uint32_t> format{0}, flags{0}, bits{0}, channels{0}, frameBytes{0};
    std::atomic<uint64_t> rateBits{0};
    std::atomic_flag busy = ATOMIC_FLAG_INIT;
    obs::AudioDeliveryCursor cursor;
    obs::PullIdentity pull;
    std::array<float, 8192> scratch{};
};
struct Description {
    uint32_t version, type, subtype, manufacturer;
    AudioStreamBasicDescription format{};
};
std::array<Unit, MaximumUnits> units;
std::mutex configuration; // configuration hooks only; NEVER acquired by render()
std::atomic<const obs::MappedMedia *> audioMapping{nullptr};
static_assert(std::atomic<const obs::MappedMedia *>::is_always_lock_free, "RT pointer must be lock free");
// Mappings stay owned until process exit. The RT thread never creates/destroys
// shared_ptrs or unmaps pages; exceeding this bounded session table fails open.
std::array<std::shared_ptr<OBMapping>, MaximumMappings> retained;
size_t mappingCount = 0;
std::atomic<bool> enabled{true};
std::atomic<bool> mediaVersionReady{false};
std::atomic<uint64_t> calls{0}, mixed{0}, underflow{0}, skipped{0}, lastInputMS{0}, lastFormat{0}, phase{0};
using Render = OSStatus (*)(AudioUnit, AudioUnitRenderActionFlags *, const AudioTimeStamp *, UInt32, UInt32, AudioBufferList *);
using NewUnit = OSStatus (*)(AudioComponent, AudioComponentInstance *);
using Dispose = OSStatus (*)(AudioComponentInstance);
using Initialize = OSStatus (*)(AudioUnit);
using SetProperty = OSStatus (*)(AudioUnit, AudioUnitPropertyID, AudioUnitScope, AudioUnitElement, const void *, UInt32);
Render originalRender = nullptr;
NewUnit originalNew = nullptr;
Dispose originalDispose = nullptr;
Initialize originalInitialize = nullptr;
Initialize originalStart = nullptr;
SetProperty originalProperty = nullptr;
thread_local unsigned depth = 0;

Unit *find(AudioUnit handle) {
    for (auto &unit : units) if (unit.alive.load(std::memory_order_acquire) &&
        unit.handle.load(std::memory_order_relaxed) == uintptr_t(handle)) return &unit;
    return nullptr;
}
bool description(const Unit &unit, Description &result) {
    uint32_t sequence = unit.sequence.load(std::memory_order_acquire);
    if (!sequence || (sequence & 1)) return false;
    result.version = sequence; result.type = unit.type.load(); result.subtype = unit.subtype.load();
    result.manufacturer = unit.manufacturer.load();
    result.format.mFormatID = unit.format.load(); result.format.mFormatFlags = unit.flags.load();
    result.format.mBitsPerChannel = unit.bits.load(); result.format.mChannelsPerFrame = unit.channels.load();
    result.format.mBytesPerFrame = unit.frameBytes.load();
    uint64_t rate = unit.rateBits.load(); memcpy(&result.format.mSampleRate, &rate, sizeof(rate));
    return unit.alive.load(std::memory_order_acquire) && sequence == unit.sequence.load(std::memory_order_acquire);
}
void registerUnit(AudioUnit handle) {
    if (!handle) return;
    AudioComponentDescription component{};
    AudioComponent source = AudioComponentInstanceGetComponent(handle);
    if (!source || AudioComponentGetDescription(source, &component) ||
        !obs::liveInput(component.componentType, component.componentSubType, component.componentManufacturer, 1, 0)) return;
    AudioStreamBasicDescription format{}; UInt32 size = sizeof(format);
    if (AudioUnitGetProperty(handle, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Output, 1, &format, &size) ||
        size != sizeof(format)) return;
    std::lock_guard<std::mutex> lock(configuration);
    Unit *slot = find(handle);
    if (!slot) for (auto &candidate : units) if (!candidate.handle.load()) {
        slot = &candidate; slot->handle.store(uintptr_t(handle)); break;
    }
    if (!slot) { phase = 6; return; }
    slot->sequence.fetch_add(1, std::memory_order_acq_rel);
    slot->type = component.componentType; slot->subtype = component.componentSubType;
    slot->manufacturer = component.componentManufacturer;
    slot->format = format.mFormatID; slot->flags = format.mFormatFlags;
    slot->bits = format.mBitsPerChannel; slot->channels = format.mChannelsPerFrame;
    slot->frameBytes = format.mBytesPerFrame;
    uint64_t rate; memcpy(&rate, &format.mSampleRate, sizeof(rate)); slot->rateBits = rate;
    slot->sequence.fetch_add(1, std::memory_order_release);
    slot->alive.store(true, std::memory_order_release);
}
obs::NativePCM native(const AudioStreamBasicDescription &f) {
    obs::NativePCM result;
    result.bits = f.mBitsPerChannel; result.channels = f.mChannelsPerFrame; result.frameBytes = f.mBytesPerFrame;
    result.floating = f.mFormatFlags & kAudioFormatFlagIsFloat;
    result.signedInteger = f.mFormatFlags & kAudioFormatFlagIsSignedInteger;
    result.planar = f.mFormatFlags & kAudioFormatFlagIsNonInterleaved;
    result.bigEndian = f.mFormatFlags & kAudioFormatFlagIsBigEndian;
    result.highAligned = f.mFormatFlags & kAudioFormatFlagIsAlignedHigh;
    result.fractionBits = (f.mFormatFlags & kLinearPCMFormatFlagsSampleFractionMask) >> kLinearPCMFormatFlagsSampleFractionShift;
    unsigned channels = result.planar ? 1 : result.channels;
    if (channels && !(result.frameBytes % channels)) result.bytes = result.frameBytes / channels;
    return result;
}
bool addOBS(Unit &unit, const Description &description, const AudioTimeStamp *timestamp,
            UInt32 frames, AudioBufferList *data) {
    if (!unit.alive.load(std::memory_order_acquire) || unit.sequence.load(std::memory_order_acquire) != description.version) return false;
    ++calls; lastInputMS.store(uint64_t(OBNow() * 1000));
    const auto &format = description.format;
    lastFormat.store((uint64_t(std::isfinite(format.mSampleRate) && format.mSampleRate > 0 && format.mSampleRate <= 192000 ?
        format.mSampleRate : 0) << 32) | (uint64_t(format.mBitsPerChannel & 65535) << 16) | (format.mChannelsPerFrame & 65535));
    if (!enabled.load(std::memory_order_acquire)) { phase = 4; return false; }
    if (!mediaVersionReady.load(std::memory_order_acquire)) { phase = 7; return false; }
    const auto *mapping = audioMapping.load(std::memory_order_acquire);
    double now = OBNow();
    if (!mapping || !mapping->state.fresh(uint64_t(now * 1000000))) { phase = 5; return false; }
    if (!data || !data->mNumberBuffers || data->mNumberBuffers > 8 || !frames || frames > 8192 ||
        format.mFormatID != kAudioFormatLinearPCM || !std::isfinite(format.mSampleRate) ||
        format.mSampleRate < 8000 || format.mSampleRate > 192000) { ++skipped; phase = 3; return false; }
    obs::NativePCM pcm = native(format);
    obs::PCMBuffer buffers[8];
    for (unsigned i = 0; i < data->mNumberBuffers; ++i)
        buffers[i] = {data->mBuffers[i].mData, data->mBuffers[i].mDataByteSize, data->mBuffers[i].mNumberChannels};
    if (!obs::nativeLayout(pcm, buffers, data->mNumberBuffers, frames) || unit.busy.test_and_set(std::memory_order_acquire)) {
        ++skipped; phase = 3; return false;
    }
    struct Release { Unit &unit; ~Release() { unit.busy.clear(std::memory_order_release); } } release{unit};
    bool sampleValid = timestamp && (timestamp->mFlags & kAudioTimeStampSampleTimeValid) && std::isfinite(timestamp->mSampleTime);
    bool hostValid = timestamp && (timestamp->mFlags & kAudioTimeStampHostTimeValid);
    double sampleTime = sampleValid ? timestamp->mSampleTime : 0;
    uint64_t hostTime = hostValid ? timestamp->mHostTime : 0;
    if (unit.pull.duplicate(sampleValid, sampleTime, hostValid, hostTime, frames, description.version)) return false;
    if (unit.cursor.generation != mapping->state.generation.load() || unit.cursor.session != mapping->cookie ||
        unit.pull.version != description.version) unit.cursor.initialized = false;
    double when = unit.cursor.begin(mapping->cookie, mapping->state.generation.load(std::memory_order_acquire),
        now, frames, format.mSampleRate);
    if (!mapping->state.readAudio(unit.scratch.data(), frames, when, format.mSampleRate, uint64_t(now * 1000000))) {
        ++underflow; phase = 2; return false;
    }
    if (!obs::mixNative(unit.scratch.data(), buffers, data->mNumberBuffers, frames, pcm, 1., .70)) {
        ++skipped; phase = 3; return false;
    }
    unit.pull.accept(sampleValid, sampleTime, hostValid, hostTime, frames, description.version);
    ++mixed; phase = 1; return true;
}
OSStatus render(AudioUnit handle, AudioUnitRenderActionFlags *flags, const AudioTimeStamp *time,
                UInt32 bus, UInt32 frames, AudioBufferList *data) {
    // Original capture runs exactly once. No property query, lock wait, heap,
    // notification, log, file open or audio-session change in this callback.
    ++depth;
    struct Depth { ~Depth() { --depth; } } guard;
    Unit *unit = bus == 1 && depth == 1 ? find(handle) : nullptr;
    Description info{};
    bool eligible = unit && description(*unit, info) &&
        obs::liveInput(info.type, info.subtype, info.manufacturer, bus, 0);
    return obs::liveRender([&] { return originalRender(handle, flags, time, bus, frames, data); },
        [&] { return addOBS(*unit, info, time, frames, data); }, flags,
        kAudioUnitRenderAction_OutputIsSilence, eligible);
}
OSStatus create(AudioComponent component, AudioComponentInstance *unit) {
    OSStatus rc = originalNew(component, unit); if (!rc && unit && !depth) registerUnit(*unit); return rc;
}
OSStatus dispose(AudioComponentInstance handle) {
    OSStatus rc = originalDispose(handle);
    if (!rc) { std::lock_guard<std::mutex> lock(configuration); if (auto *slot = find(handle)) slot->alive = false; }
    return rc;
}
OSStatus initialize(AudioUnit unit) { OSStatus rc = originalInitialize(unit); if (!rc && !depth) registerUnit(unit); return rc; }
OSStatus start(AudioUnit unit) {
    // Also covers a unit that was constructed before this tweak's constructor.
    if (!depth) registerUnit(unit);
    return originalStart(unit);
}
OSStatus property(AudioUnit unit, AudioUnitPropertyID key, AudioUnitScope scope, AudioUnitElement element,
                  const void *data, UInt32 size) {
    OSStatus rc = originalProperty(unit, key, scope, element, data, size);
    if (!rc && !depth && (key == kAudioUnitProperty_StreamFormat || key == kAudioOutputUnitProperty_EnableIO ||
        key == kAudioOutputUnitProperty_SetInputCallback)) registerUnit(unit);
    return rc;
}
template<class Function> bool hook(const char *name, Function replacement, Function &original) {
    void *symbol = dlsym(RTLD_DEFAULT, name);
    if (!symbol) return false;
    MSHookFunction(symbol, reinterpret_cast<void *>(replacement), reinterpret_cast<void **>(&original));
    return original != nullptr;
}
void publish(unsigned index, uint64_t value) {
    // Called only by the background timer, never the render callback.
    static const char *names[] = {"local.xiaoguai.obsbridge.live.heart", "local.xiaoguai.obsbridge.live.owner",
        "local.xiaoguai.obsbridge.live.calls", "local.xiaoguai.obsbridge.live.mixed",
        "local.xiaoguai.obsbridge.live.misses", "local.xiaoguai.obsbridge.live.format", "local.xiaoguai.obsbridge.live.phase"};
    static int tokens[] = {-1,-1,-1,-1,-1,-1,-1};
    if (tokens[index] < 0 && notify_register_check(names[index], &tokens[index])) { tokens[index] = -1; return; }
    notify_set_state(tokens[index], value);
}
void update(void) {
    // Do not read another process's preferences file from the app sandbox.
    enabled.store(OBBusLiveAudioEnabled(), std::memory_order_release);
    mediaVersionReady.store(OBBusMediaVersionReady(), std::memory_order_release);
    OBRequestMediaReadAccess();
    auto mapping = OBBusConsumer();
    if (mapping) {
        const obs::MappedMedia *pointer = mapping->memory;
        bool found = false;
        for (size_t i = 0; i < mappingCount; ++i) if (retained[i]->memory == pointer) found = true;
        if (!found && mappingCount < MaximumMappings) { retained[mappingCount++] = mapping; found = true; }
        audioMapping.store(found ? pointer : nullptr, std::memory_order_release);
        if (!found) phase = 6;
    } else audioMapping.store(nullptr, std::memory_order_release);
    uint64_t nowMS = uint64_t(OBNow() * 1000), input = lastInputMS.load();
    bool owns = enabled.load() && mediaVersionReady.load() && mapping && mapping->data->fresh(nowMS * 1000) && input && nowMS >= input && nowMS - input < 1000;
    publish(1, owns ? (uint64_t(getpid()) << 32) | uint32_t(input) : 0);
    publish(2, calls.load()); publish(3, mixed.load());
    publish(4, (uint64_t(uint32_t(underflow.load())) << 32) | uint32_t(skipped.load()));
    publish(5, lastFormat.load()); publish(6, enabled.load() ? phase.load() : 4);
    publish(0, (uint64_t(getpid()) << 32) | uint32_t(nowMS));
}
}
__attribute__((constructor)) static void OBAppAudioInitialize(void) {
    @autoreleasepool {
        if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.zhiliaoapp.musically"]) return;
        bool ready = hook("AudioComponentInstanceNew", create, originalNew);
        ready &= hook("AudioComponentInstanceDispose", dispose, originalDispose);
        ready &= hook("AudioUnitInitialize", initialize, originalInitialize);
        ready &= hook("AudioOutputUnitStart", start, originalStart);
        ready &= hook("AudioUnitSetProperty", property, originalProperty);
        if (ready) ready = hook("AudioUnitRender", render, originalRender);
        if (!ready) { NSLog(@"[OBSBridge] live audio hooks unavailable; leave input unchanged"); return; }
        dispatch_queue_t queue = dispatch_queue_create("local.xiaoguai.obsbridge.live.audio", DISPATCH_QUEUE_SERIAL);
        static dispatch_source_t timer;
        timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
        dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, 0), NSEC_PER_SEC / 2, NSEC_PER_SEC / 10);
        dispatch_source_set_event_handler(timer, ^{ @autoreleasepool { update(); } });
        dispatch_resume(timer);
    }
}
