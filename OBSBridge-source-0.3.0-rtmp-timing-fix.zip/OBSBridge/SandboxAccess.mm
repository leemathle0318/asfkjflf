#import "SandboxAccess.h"
#import "Shared.h"
#import "MediaBus.h"
#include "core/AccessAttempt.hpp"
#include <dlfcn.h>
#include <notify.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <atomic>
#include <mutex>
#include <cerrno>

namespace {
std::mutex notifyLock;
int statusToken = -1;
uint32_t accessChannel(uint64_t *value, bool write) {
    std::lock_guard<std::mutex> lock(notifyLock);
    if (statusToken < 0) {
        uint32_t rc = notify_register_check(OB_ACCESS_NOTIFY, &statusToken);
        if (rc) { statusToken = -1; return rc; }
    }
    return write ? notify_set_state(statusToken, *value) : notify_get_state(statusToken, value);
}
void report(const obs::AccessAttempt &attempt) {
    uint64_t value = attempt.state(); uint32_t rc = accessChannel(&value, true);
    if (rc) NSLog(@"[OBSBridge] permission status notify rc=%u", rc);
}
std::atomic<bool> busy{false};
std::atomic<uint64_t> verifiedSession{0};
std::atomic<uint64_t> exhaustedSession{0};
dispatch_queue_t permissionQueue;
// The only upstream interface used is libSandy_applyProfile(const char*).
// Its return 0 is NOT proof that the kernel accepted a file extension: the
// audited implementation doesn't check consume's result. Probe actual access.
using ApplyProfile = int (*)(const char *);
void applyAndProbe(obs::AccessAttempt &attempt) {
    static void *library = nullptr;
    static ApplyProfile apply = nullptr;
    if (!library) library = dlopen("/var/jb/usr/lib/libsandy.dylib", RTLD_LAZY | RTLD_LOCAL);
    if (!library) { attempt.finish(obs::AccessPhase::LibraryMissing, 0); return; }
    if (!apply) apply = reinterpret_cast<ApplyProfile>(dlsym(library, "libSandy_applyProfile"));
    if (!apply) { attempt.finish(obs::AccessPhase::SymbolMissing, 0); return; }
    int rc = apply(OB_ACCESS_PROFILE);
    if (rc) { attempt.finish(obs::AccessPhase::ProfileRejected, rc); return; }
    int fd = open(OB_BUS_FILE, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
    if (fd < 0) { attempt.finish(obs::AccessPhase::ReadProbeFailed, errno); return; }
    struct stat info{};
    int failure = 0;
    if (fstat(fd, &info)) failure = errno;
    else if (!S_ISREG(info.st_mode) || info.st_nlink != 1 || (info.st_mode & S_IWOTH) ||
        (info.st_uid != 0 && info.st_uid != 501 && info.st_uid != geteuid()) ||
        info.st_size != off_t(sizeof(obs::MappedMedia))) failure = EINVAL;
    if (failure) { close(fd); attempt.finish(obs::AccessPhase::ReadProbeFailed, failure); return; }
    void *base = mmap(nullptr, sizeof(obs::MappedMedia), PROT_READ, MAP_SHARED, fd, 0);
    failure = errno; close(fd);
    if (base == MAP_FAILED) { attempt.finish(obs::AccessPhase::ReadProbeFailed, failure); return; }
    bool valid = static_cast<const obs::MappedMedia *>(base)->valid(attempt.session);
    munmap(base, sizeof(obs::MappedMedia));
    attempt.finish(valid ? obs::AccessPhase::Verified : obs::AccessPhase::HeaderMismatch, 0);
}
}
void OBRequestMediaReadAccess(void) {
    uint64_t session = OBBusSession();
    if (!session || verifiedSession.load(std::memory_order_acquire) == session ||
        exhaustedSession.load(std::memory_order_acquire) == session || busy.exchange(true)) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ permissionQueue = dispatch_queue_create("local.xiaoguai.obsbridge.read-access", DISPATCH_QUEUE_SERIAL); });
    dispatch_async(permissionQueue, ^{
        @autoreleasepool {
            static obs::AccessAttempt attempt;
            if (attempt.begin(session)) {
                report(attempt);
                applyAndProbe(attempt);
                report(attempt);
                if (attempt.verified) verifiedSession.store(session, std::memory_order_release);
                else if (attempt.attempts >= 3) exhaustedSession.store(session, std::memory_order_release);
                NSLog(@"[OBSBridge] scoped media read: phase=%u detail=%d attempt=%u", uint32_t(attempt.phase), attempt.detail, attempt.attempts);
            }
        }
        busy.store(false, std::memory_order_release);
    });
}
NSString *OBMediaReadAccessStatus(void) {
    uint64_t value = 0; uint32_t rc = accessChannel(&value, false);
    if (rc) return [NSString stringWithFormat:@"授权状态读取失败 rc=%u", rc];
    auto phase = obs::AccessPhase(value >> 32); int detail = int32_t(uint32_t(value));
    switch (phase) {
        case obs::AccessPhase::Unrequested: return @"libSandy：等待媒体缓存会话";
        case obs::AccessPhase::Requesting: return [NSString stringWithFormat:@"libSandy：后台申请只读权限，第 %d 次", detail];
        case obs::AccessPhase::LibraryMissing: return @"libSandy：rootless 库未能加载（不是画面替换成功）";
        case obs::AccessPhase::SymbolMissing: return @"libSandy：安装库缺少公开接口";
        case obs::AccessPhase::ProfileRejected: return [NSString stringWithFormat:@"libSandy 返回 %d：1 通信失败；2 profile/进程/条件被拒绝", detail];
        case obs::AccessPhase::ReadProbeFailed: return [NSString stringWithFormat:@"libSandy 调用返回 0，但实际只读探测失败 errno=%d", detail];
        case obs::AccessPhase::HeaderMismatch: return @"libSandy：可打开映射，但媒体会话/协议不符";
        case obs::AccessPhase::Verified: return @"libSandy：实际只读打开、映射和协议检查通过";
        default: return @"libSandy：未知状态，需要真实日志";
    }
}
