#pragma once
// Minimal, bounded RTMP 3 player for a trusted LAN MediaMTX server.
// Uses caller-owned cancellable I/O; no poll(), TLS, AMF3 or enhanced codecs.
// Wire format: Adobe RTMP specification, handshake, chunk streams and AMF0.
#include <array>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <functional>
#include <stdexcept>
#include <string>
#include <vector>
namespace obs {
struct RtmpURL {
    std::string host, app, stream;
    uint16_t port = 1935;
    static RtmpURL parse(const std::string &value) {
        if (value.rfind("rtmp://", 0) != 0 || value.size() > 1024)
            throw std::runtime_error("Use a LAN rtmp://IPv4:port/live/channel URL");
        auto slash = value.find('/', 7), next = value.find('/', slash == std::string::npos ? 0 : slash + 1);
        if (slash == std::string::npos || next == std::string::npos || next + 1 == value.size())
            throw std::runtime_error("RTMP URL requires application and stream path");
        auto authority = value.substr(7, slash - 7); auto colon = authority.find(':');
        RtmpURL out; out.host = authority.substr(0, colon);
        if (colon != std::string::npos) {
            auto port = authority.substr(colon + 1);
            if (port.empty() || port.size() > 5 || port.find_first_not_of("0123456789") != std::string::npos)
                throw std::runtime_error("Invalid RTMP port");
            unsigned n = unsigned(std::stoul(port));
            if (!n || n > 65535) throw std::runtime_error("Invalid RTMP port");
            out.port = uint16_t(n);
        }
        unsigned parts = 0; size_t start = 0;
        while (start < out.host.size()) {
            auto end = out.host.find('.', start); if (end == std::string::npos) end = out.host.size();
            auto part = out.host.substr(start, end - start);
            if (part.empty() || part.size() > 3 || part.find_first_not_of("0123456789") != std::string::npos || std::stoul(part) > 255)
                throw std::runtime_error("Use a literal IPv4 address");
            ++parts; start = end + 1;
        }
        if (parts != 4 || out.host.back() == '.') throw std::runtime_error("Invalid IPv4");
        out.app = value.substr(slash + 1, next - slash - 1); out.stream = value.substr(next + 1);
        auto safe = [](const std::string &s) { return !s.empty() && s.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_/.") == std::string::npos && s.find("..") == std::string::npos; };
        if (!safe(out.app) || !safe(out.stream)) throw std::runtime_error("Invalid RTMP path");
        return out;
    }
};
class RtmpPull {
    using Bytes = std::vector<uint8_t>;
    struct Chunk { bool valid=false, extended=false, partial=false; uint32_t stamp=0, delta=0, length=0, stream=0; uint8_t type=0; Bytes data; };
    std::array<Chunk, 128> chunks{};
    std::function<bool(uint8_t *, size_t)> receive;
    std::function<bool(const uint8_t *, size_t)> transmit;
    uint32_t chunkSize=128, ackWindow=0, streamID=0;
    uint64_t received=0, acknowledged=0;
    Bytes pending;
    size_t pendingOffset=0;
    static uint32_t be24(const uint8_t *p) { return (uint32_t(p[0])<<16)|(uint32_t(p[1])<<8)|p[2]; }
    static uint32_t be32(const uint8_t *p) { return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3]; }
    static void put24(Bytes &b, uint32_t n) { b.push_back(uint8_t(n>>16)); b.push_back(uint8_t(n>>8)); b.push_back(uint8_t(n)); }
    static void put32(Bytes &b, uint32_t n) { b.push_back(uint8_t(n>>24)); put24(b,n); }
    static void string(Bytes &b, const std::string &s) {
        if (s.size()>65535) throw std::runtime_error("AMF string too long");
        b.push_back(2); b.push_back(uint8_t(s.size()>>8)); b.push_back(uint8_t(s.size())); b.insert(b.end(),s.begin(),s.end());
    }
    static void number(Bytes &b, double value) {
        uint64_t bits; std::memcpy(&bits,&value,8); b.push_back(0);
        for (int i=7;i>=0;--i) b.push_back(uint8_t(bits>>(i*8)));
    }
    static void property(Bytes &b,const char *name,const std::string &value) {
        size_t n=std::strlen(name); b.push_back(uint8_t(n>>8)); b.push_back(uint8_t(n)); b.insert(b.end(),name,name+n); string(b,value);
    }
    void read(uint8_t *p,size_t n) {
        if (!receive(p,n)) throw std::runtime_error("RTMP read closed, timed out or cancelled");
        received+=n;
        if (ackWindow && received-acknowledged >= ackWindow) {
            Bytes b; put32(b,uint32_t(received)); send(2,3,0,b); acknowledged=received;
        }
    }
    void send(uint8_t channel,uint8_t type,uint32_t stream,const Bytes &body) {
        if (body.size()>8*1024*1024) throw std::runtime_error("RTMP output too large");
        Bytes wire{channel}; put24(wire,0); put24(wire,uint32_t(body.size())); wire.push_back(type);
        for (unsigned i=0;i<4;++i) wire.push_back(uint8_t(stream>>(8*i)));
        for (size_t offset=0;offset<body.size();) {
            if (offset) wire.push_back(uint8_t(0xc0|channel));
            size_t n=std::min(size_t(128),body.size()-offset);
            wire.insert(wire.end(),body.begin()+offset,body.begin()+offset+n); offset+=n;
        }
        if (!transmit(wire.data(),wire.size())) throw std::runtime_error("RTMP write failed");
    }
    Chunk message() {
        for (;;) {
            uint8_t b; read(&b,1); unsigned fmt=b>>6, channel=b&63;
            if (!channel) {read(&b,1); channel=64+b;}
            else if (channel==1) {uint8_t x[2]; read(x,2); channel=64+x[0]+256*x[1];}
            if (channel>=chunks.size()) throw std::runtime_error("RTMP chunk stream ID exceeds LAN player bound");
            auto &c=chunks[channel]; bool continued=c.partial;
            if (fmt && !c.valid) throw std::runtime_error("RTMP missing chunk header");
            if (fmt!=3 && continued) throw std::runtime_error("RTMP interrupted partial message");
            if (!continued) c.data.clear();
            uint8_t h[11]{}; uint32_t field=0;
            if (fmt==0) {
                read(h,11); field=be24(h); c.length=be24(h+3); c.type=h[6];
                c.stream=uint32_t(h[7])|(uint32_t(h[8])<<8)|(uint32_t(h[9])<<16)|(uint32_t(h[10])<<24); c.delta=0;
            } else if (fmt==1) {read(h,7); field=be24(h); c.length=be24(h+3); c.type=h[6];}
            else if (fmt==2) {read(h,3); field=be24(h);}
            if (fmt!=3) c.extended=field==0xffffff;
            if (c.extended) {read(h,4); field=be32(h);}
            if (fmt==0) c.stamp=field;
            else if (fmt<3) {c.delta=field; c.stamp+=field;}
            else if (!continued) c.stamp+=c.delta;
            c.valid=true;
            if (c.length>8*1024*1024 || !chunkSize || chunkSize>1024*1024) throw std::runtime_error("RTMP oversized message/chunk");
            size_t n=std::min(size_t(chunkSize),size_t(c.length)-c.data.size()), old=c.data.size();
            size_t allocated=0;for(const auto &item:chunks)allocated+=item.data.capacity();
            if(allocated+n>16*1024*1024)throw std::runtime_error("RTMP partial-message memory bound exceeded");
            c.data.resize(old+n); if(n) read(c.data.data()+old,n);
            c.partial=c.data.size()<c.length;
            if (!c.partial) {Chunk ready=c; Bytes{}.swap(c.data); return ready;}
        }
    }
    // Command response scanner only reads top-level scalar AMF0 values.
    static bool result(const Bytes &b,double tx,double *last=nullptr) {
        if (b.size()<3 || b[0]!=2) return false;
        size_t n=(size_t(b[1])<<8)|b[2], p=3+n;
        if (p+9>b.size() || std::string(b.begin()+3,b.begin()+p)!="_result" || b[p++]!=0) return false;
        auto get=[](const uint8_t *v){ uint64_t bits=0; for(unsigned i=0;i<8;++i) bits=(bits<<8)|v[i]; double d;std::memcpy(&d,&bits,8);return d;};
        double id=get(b.data()+p);p+=8; if(id!=tx) return false;
        if(last) {
            if(p<b.size() && (b[p]==5 || b[p]==6)) ++p;
            if(p+9>b.size() || b[p++]!=0) return false;
            *last=get(b.data()+p);
        }
        return true;
    }
    void control(const Chunk &c) {
        if(c.type==1 && c.data.size()==4) {chunkSize=be32(c.data.data())&0x7fffffff; if(!chunkSize || chunkSize>1024*1024) throw std::runtime_error("RTMP invalid chunk size");}
        if(c.type==2 && c.data.size()==4) {auto id=be32(c.data.data()); if(id<chunks.size()){chunks[id].data.clear();chunks[id].valid=false;}}
        if(c.type==5 && c.data.size()==4) ackWindow=be32(c.data.data());
        if(c.type==4 && c.data.size()==6 && c.data[0]==0 && c.data[1]==6) {Bytes pong=c.data;pong[1]=7;send(2,4,0,pong);}
        if(c.type==20 || c.type==17) {
            std::string s(c.data.begin(),c.data.end());
            if(s.find("StreamNotFound")!=std::string::npos || s.find("NetConnection.Connect.Rejected")!=std::string::npos || s.find("NetStream.Play.Failed")!=std::string::npos)
                throw std::runtime_error("RTMP stream unavailable or access denied");
        }
    }
    void waitResult(double tx,double *numberResult=nullptr) {
        for(unsigned i=0;i<256;++i){auto c=message();control(c);if(c.type==20 && result(c.data,tx,numberResult))return;}
        throw std::runtime_error("RTMP command response limit exceeded");
    }
public:
    RtmpPull(std::function<bool(uint8_t *,size_t)> r,std::function<bool(const uint8_t *,size_t)> w):receive(std::move(r)),transmit(std::move(w)){}
    void start(const RtmpURL &url) {
        Bytes c(1537,0);c[0]=3;for(size_t i=9;i<c.size();++i)c[i]=uint8_t((i*73+19)&255);
        if(!transmit(c.data(),c.size()))throw std::runtime_error("RTMP handshake write failed");
        Bytes server(3073);read(server.data(),server.size());if(server[0]!=3)throw std::runtime_error("Unsupported RTMP version");
        if(!transmit(server.data()+1,1536))throw std::runtime_error("RTMP handshake acknowledgement failed");
        Bytes b;string(b,"connect");number(b,1);b.push_back(3);
        property(b,"app",url.app);property(b,"tcUrl","rtmp://"+url.host+":"+std::to_string(url.port)+"/"+url.app);
        property(b,"flashVer","FMLE/3.0 (compatible; OBSBridge)");
        auto num=[&](const char *name,double v){size_t n=std::strlen(name);b.push_back(0);b.push_back(uint8_t(n));b.insert(b.end(),name,name+n);number(b,v);};
        num("fpad",0);num("capabilities",15);num("audioCodecs",1024);num("videoCodecs",128);num("videoFunction",1);num("objectEncoding",0);
        b.insert(b.end(),{0,0,9});send(3,20,0,b);waitResult(1);
        b.clear();string(b,"createStream");number(b,2);b.push_back(5);send(3,20,0,b);
        double id=0;waitResult(2,&id);if(id<1 || id>65535)throw std::runtime_error("Invalid RTMP media stream ID");streamID=uint32_t(id);
        b.clear();b.insert(b.end(),{0,3});put32(b,streamID);put32(b,300);send(2,4,0,b);
        b.clear();string(b,"play");number(b,0);b.push_back(5);string(b,url.stream);number(b,-1);send(8,20,streamID,b);
        pending={'F','L','V',1,5,0,0,0,9,0,0,0,0};pendingOffset=0;
    }
    int readFLV(uint8_t *out,int size) {
        if(size<=0)return 0;
        while(pendingOffset>=pending.size()) {
            auto c=message();control(c);
            if(c.type!=8 && c.type!=9 && c.type!=18)continue;
            if(c.stream!=streamID || c.data.empty())continue;
            pending.clear();pending.push_back(c.type);put24(pending,uint32_t(c.data.size()));
            put24(pending,c.stamp&0xffffff);pending.push_back(uint8_t(c.stamp>>24));put24(pending,0);
            pending.insert(pending.end(),c.data.begin(),c.data.end());put32(pending,uint32_t(11+c.data.size()));pendingOffset=0;
        }
        size_t n=std::min(size_t(size),pending.size()-pendingOffset);std::memcpy(out,pending.data()+pendingOffset,n);pendingOffset+=n;return int(n);
    }
};
}
