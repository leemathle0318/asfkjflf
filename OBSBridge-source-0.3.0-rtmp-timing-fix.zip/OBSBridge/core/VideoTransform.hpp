#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace obs {
struct VideoTransform {
    double zoom=1, x=0, y=0, left=0, right=0, top=0, bottom=0;
    bool landscape=false;
    void normalize() {
        auto clamp=[](double v,double low,double high){return std::isfinite(v)?std::clamp(v,low,high):low;};
        zoom=clamp(zoom,1,4);x=clamp(x,-1,1);y=clamp(y,-1,1);
        left=clamp(left,0,.45);right=clamp(right,0,.45);top=clamp(top,0,.45);bottom=clamp(bottom,0,.45);
    }
    uint64_t position() const {
        VideoTransform v=*this;v.normalize();
        return uint64_t(std::lround(v.zoom*1000)) | (uint64_t(uint16_t(int16_t(std::lround(v.x*1000))))<<16) |
            (uint64_t(uint16_t(int16_t(std::lround(v.y*1000))))<<32) | (uint64_t(v.landscape)<<48);
    }
    uint64_t crop() const {
        VideoTransform v=*this;v.normalize();
        return uint64_t(std::lround(v.left*10000)) | (uint64_t(std::lround(v.right*10000))<<16) |
            (uint64_t(std::lround(v.top*10000))<<32) | (uint64_t(std::lround(v.bottom*10000))<<48);
    }
    static VideoTransform decode(uint64_t pos,uint64_t crop) {
        VideoTransform v;
        v.zoom=double(uint16_t(pos))/1000;v.x=double(int16_t(pos>>16))/1000;v.y=double(int16_t(pos>>32))/1000;
        v.landscape=((pos>>48)&1)!=0;
        v.left=double(uint16_t(crop))/10000;v.right=double(uint16_t(crop>>16))/10000;
        v.top=double(uint16_t(crop>>32))/10000;v.bottom=double(uint16_t(crop>>48))/10000;v.normalize();return v;
    }
};
struct FillGeometry {double scale, tx, ty;};
inline int outputOrientation(double dw,double dh,bool landscape) {
    // Output orientation, not input aspect ratio, determines the sensor correction.
    // A landscape source must not become sideways merely because it matches the sensor's aspect.
    return ((dw>dh) != landscape)?8:1;
}
inline FillGeometry fillGeometry(double sw,double sh,double dw,double dh,const VideoTransform &config) {
    VideoTransform v=config;v.normalize();
    double scale=std::max(dw/sw,dh/sh)*v.zoom;
    double extraX=std::max(0.,sw*scale-dw),extraY=std::max(0.,sh*scale-dh);
    // Pan is limited to available overflow: dragging cannot uncover empty borders.
    return {scale,-extraX/2+v.x*extraX/2,-extraY/2-v.y*extraY/2};
}
}
