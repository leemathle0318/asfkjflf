#pragma once
#include <array>
#include <cmath>
namespace obs {
// One mapping for BOTH tracks. Recover sustained window rejection, not isolated
// network jitter. Never retime video independently of the audio clock.
class PresentationClock {
    struct Miss { unsigned count = 0; double since = 0; };
    std::array<Miss, 2> misses{};
    bool valid = false;
    double originPTS = 0, originLocal = 0, lastRecovery = -1e30;
public:
    struct Result { double due; bool rebased; };
    static bool usable(double due, double now) {
        return std::isfinite(due) && due >= now - .25 && due < now + .75;
    }
    void reset() { *this = PresentationClock{}; }
    Result schedule(double pts, double now, bool video, bool recoverWindow) {
        if (!std::isfinite(pts) || !std::isfinite(now)) return {NAN, false};
        if (!valid) { originPTS = pts; originLocal = now + .180; valid = true; }
        double due = originLocal + pts - originPTS;
        auto &miss = misses[video ? 0 : 1];
        if (usable(due, now)) miss = {};
        else { if (!miss.count) miss.since = now; if (miss.count < 1000) ++miss.count; }
        bool sustained = recoverWindow && miss.count >= 4 && now - miss.since >= .250 &&
                         now - lastRecovery >= 1.;
        if (due < now - 1. || due > now + 1. || sustained) {
            originPTS = pts; originLocal = now + .180;
            misses = {}; lastRecovery = now;
            return {originLocal, true};
        }
        return {due, false};
    }
};
}
