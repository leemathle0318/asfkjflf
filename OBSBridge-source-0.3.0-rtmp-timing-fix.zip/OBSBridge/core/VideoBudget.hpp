#pragma once
#include <cstdint>
#include <cmath>
namespace obs {
struct VideoBudget { unsigned edge, fps; };
inline VideoBudget videoBudget(unsigned profile, unsigned thermal) {
    if (thermal >= 3) return {640, 15};
    if (thermal >= 2) return {800, 20};
    return profile ? VideoBudget{1280, 30} : VideoBudget{960, 30};
}
struct FrameGate {
    double last = 0, next = 0;
    unsigned rate = 0;
    bool valid = false;
    bool admit(double pts, unsigned fps) {
        if (!std::isfinite(pts) || !fps) return false;
        double period = 1. / fps;
        if (!valid || pts < last || fps != rate) {
            last = pts; next = pts + period; rate = fps; valid = true; return true;
        }
        if (pts == last) return false;
        last = pts;
        // FLV timestamps have millisecond precision. Keep a phase deadline,
        // rather than restarting the interval after every rounded timestamp.
        double tolerance = std::fmin(.0015, period * .1);
        if (pts + tolerance < next) return false;
        next += (std::floor((pts + tolerance - next) / period) + 1.) * period;
        return true;
    }
};
}
