#pragma once
#include "Timeline.hpp"

namespace obs {
struct NativePCM {
    unsigned bits = 0, bytes = 0, frameBytes = 0, channels = 0, fractionBits = 0;
    bool floating = false, signedInteger = false, planar = false, bigEndian = false, highAligned = false;
    bool valid() const {
        if (!channels || channels > 8 || !bytes || bytes > 8 ||
            frameBytes != bytes * (planar ? 1 : channels)) return false;
        if (floating) return !signedInteger && !fractionBits && ((bits == 32 && bytes == 4) || (bits == 64 && bytes == 8));
        return signedInteger && (bits == 16 || bits == 24 || bits == 32) &&
            bytes >= (bits + 7) / 8 && bytes <= 4 && fractionBits < bits;
    }
};
inline uint64_t pcmWord(const uint8_t *p, unsigned bytes, bool big) {
    uint64_t word = 0;
    for (unsigned i = 0; i < bytes; ++i) word |= uint64_t(p[i]) << (8 * (big ? bytes - 1 - i : i));
    return word;
}
inline void pcmStore(uint8_t *p, unsigned bytes, bool big, uint64_t word) {
    for (unsigned i = 0; i < bytes; ++i) p[i] = uint8_t(word >> (8 * (big ? bytes - 1 - i : i)));
}
inline double pcmRead(const uint8_t *p, const NativePCM &f) {
    uint64_t word = pcmWord(p, f.bytes, f.bigEndian);
    if (f.floating) {
        if (f.bits == 32) { uint32_t bits = uint32_t(word); float v; std::memcpy(&v, &bits, 4); return std::isfinite(v) ? v : 0; }
        double v; std::memcpy(&v, &word, 8); return std::isfinite(v) ? v : 0;
    }
    if (f.highAligned) word >>= f.bytes * 8 - f.bits;
    word &= (uint64_t(1) << f.bits) - 1;
    int64_t signedWord = word & (uint64_t(1) << (f.bits - 1)) ?
        int64_t(word) - int64_t(uint64_t(1) << f.bits) : int64_t(word);
    return double(signedWord) / double(uint64_t(1) << (f.fractionBits ? f.fractionBits : f.bits - 1));
}
inline void pcmWrite(uint8_t *p, const NativePCM &f, double value) {
    double v = std::isfinite(value) ? std::clamp(value, -1., 1.) : 0;
    uint64_t word;
    if (f.floating) {
        if (f.bits == 32) { float x = float(v); uint32_t bits; std::memcpy(&bits, &x, 4); word = bits; }
        else std::memcpy(&word, &v, 8);
    } else {
        int64_t scale = int64_t(uint64_t(1) << (f.fractionBits ? f.fractionBits : f.bits - 1));
        int64_t limit = int64_t(uint64_t(1) << (f.bits - 1));
        int64_t x = std::clamp<int64_t>(std::llround(v * double(scale)), -limit, limit - 1);
        word = uint64_t(x) & ((uint64_t(1) << f.bits) - 1);
        if (f.highAligned) word <<= f.bytes * 8 - f.bits;
        else if (x < 0 && f.bytes * 8 > f.bits) word |= ~((uint64_t(1) << f.bits) - 1);
    }
    pcmStore(p, f.bytes, f.bigEndian, word);
}
inline bool nativeLayout(const NativePCM &f, const PCMBuffer *buffers, size_t n, size_t frames) {
    if (!f.valid() || !buffers || !frames || frames > 8192 ||
        n != (f.planar ? f.channels : 1)) return false;
    for (size_t i = 0; i < n; ++i) {
        if (!buffers[i].data || buffers[i].channels != (f.planar ? 1 : f.channels) ||
            frames > buffers[i].bytes / f.frameBytes) return false;
    }
    return true;
}
inline bool mixNative(const float *source, PCMBuffer *buffers, size_t n, size_t frames,
                      const NativePCM &f, double micGain, double sourceGain) {
    if (!source || !nativeLayout(f, buffers, n, frames) ||
        !std::isfinite(micGain) || !std::isfinite(sourceGain)) return false;
    for (size_t b = 0; b < n; ++b) {
        auto *data = static_cast<uint8_t *>(buffers[b].data);
        for (size_t i = 0; i < frames; ++i) for (unsigned c = 0; c < buffers[b].channels; ++c) {
            uint8_t *p = data + i * f.frameBytes + c * f.bytes;
            double obs = std::isfinite(source[i]) ? source[i] : 0;
            pcmWrite(p, f, micGain * pcmRead(p, f) + sourceGain * obs);
        }
    }
    return true;
}
// Separate from the native mic capture PTS: OBS video is selected at delivery
// time too. Preserve mic PTS in the output, but read OBS on this host cursor.
struct AudioDeliveryCursor {
    uint64_t session = 0;
    uint32_t generation = 0;
    double next = 0, rate = 0;
    bool initialized = false;
    double begin(uint64_t cookie, uint32_t epoch, double now, size_t frames, double sampleRate) {
        if (!cookie || !std::isfinite(now) || now < 0 || !frames || frames > 8192 ||
            !std::isfinite(sampleRate) || sampleRate < 8000 || sampleRate > 192000) {
            initialized = false; return NAN;
        }
        if (!initialized || cookie != session || epoch != generation || sampleRate != rate ||
            std::fabs(next - now) > .080) next = now;
        initialized = true; session = cookie; generation = epoch; rate = sampleRate;
        double start = next; next += double(frames) / rate;
        return start;
    }
};
enum class AudioPhase : uint32_t { None, Inactive, Format, FrameCount, NotReady, BufferList,
    Layout, Busy, Underflow, Build, Mixed, AlreadyMixed };
}
