# 0.2.9 检查记录（2026-10-12）

## 用户GitHub实测

- 0.2.6纯C++回归通过，CoreMedia混音输出读取断言失败，没有错误码。
- 0.2.7真实CoreMedia第一个原始音频fixture读取失败，status=-12737（ArrayTooSmall）、needed24/capacity4096/buffers0；还未进入混音。查询/填充阶段未区分，不能认定具体阶段或仅是分配空间小。

## 本机执行

- 从0.2.9源码重新编译并运行10组C++测试：timeline、shortcut、shared_media、nonblocking_read、pending_frames、mapped_media、access_attempt、video_continuity、native_audio、audio_list_contract。
- 新列表契约测试覆盖-12737+有效24字节查询可继续、1/2/8条目容量、真正空间不足/其他API错误/零或残缺尺寸/超过8条目拒绝。这是纯策略测试，不冒充CoreMedia实际API执行。
- 保留44种原生PCM格式、独立已知字节、合成双音源幅度、游标重置/抖动、限幅/NaN/越界测试；5000并发帧版本和两Windows进程只读媒体映射回归。
- 12个插件单元加CoreMedia测试源文件，共13个iOS arm64 Mach-O对象编译，SDK16.5/deploy15/ARC/blocks/Wall/Wextra/Werror。
- 16项源码结构检查、5项打包准备、12项不可安装的合成deb检查；源码ZIP版本/LF/完整性，工作流YAML/Bash/嵌入Python和10种源码定位/旧版本/危险路径/换行案例检查。

## 未执行/未确认

Windows不能执行macOS CoreMedia库。Actions内真实8种CoreMedia用例和所有断言保留；新行为是否解决用户报错需要这一步实际结果。完整Theos链接、签名、arm64e、真机视频/OBS音轨+麦克风/音画同步/观众端没有通过记录。未把成功编译叫作声音功能实现验收。
