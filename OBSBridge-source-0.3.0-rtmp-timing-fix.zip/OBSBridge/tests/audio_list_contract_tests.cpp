#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/AudioListQuery.hpp"
#include <cassert>
#include <cstdio>
#include <initializer_list>
int main() {
    constexpr int32_t small=-12737;
    auto plan=obs::audioListPlan(small,small,24,4096,8,16);
    assert(plan.code==obs::AudioListPlanCode::Ready && plan.buffers==1);
    plan=obs::audioListPlan(0,small,40,4096,8,16);
    assert(plan.code==obs::AudioListPlanCode::Ready && plan.buffers==2);
    plan=obs::audioListPlan(small,small,136,136,8,16);
    assert(plan.code==obs::AudioListPlanCode::Ready && plan.buffers==8);
    assert(obs::audioListPlan(small,small,24,1,8,16).code==obs::AudioListPlanCode::Capacity);
    assert(obs::audioListPlan(-12731,small,24,4096,8,16).code==obs::AudioListPlanCode::APIError);
    for (size_t invalid : {size_t(0),size_t(8),size_t(9),size_t(23),size_t(25),size_t(152)})
        assert(obs::audioListPlan(small,small,invalid,4096,8,16).code==obs::AudioListPlanCode::InvalidSize);
    std::puts("PASS: audio list query status/required-size contract: -12737 with valid 24-byte size proceeds, exact entry counts 1/2/8, real errors/short/zero/malformed/oversized lists rejected (not CoreMedia runtime)");
}
