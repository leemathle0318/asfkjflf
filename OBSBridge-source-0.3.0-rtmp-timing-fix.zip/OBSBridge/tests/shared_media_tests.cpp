#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/SharedMedia.hpp"
#include "../core/Timeline.hpp"
#include <cassert>
#include <iostream>
#include <memory>
#include <thread>
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

using obs::SharedMedia;
static bool inspectShared(SharedMedia *bus) {
    float samples[8]{};
    if (!bus->readAudio(samples, 8, 10, 48000, 10000000)) return false;
    for (float sample : samples) if (sample != .25f) return false;
    return obs::acquireReader(bus->video[0]);
}
static void prepare(SharedMedia *bus) {
    bus->initialize(); bus->enabled = 1; bus->generation = 1; bus->heartbeatUS = 10000000;
    float samples[8]; std::fill(std::begin(samples), std::end(samples), .25f);
    bus->writeAudio(samples, 8, 10);
}
#ifdef _WIN32
int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    if (argc == 3 && std::wstring(argv[1]) == L"--shared-child") {
        HANDLE handle = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, argv[2]);
        if (!handle) return 10;
        auto *bus = static_cast<SharedMedia *>(MapViewOfFile(handle, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedMedia)));
        bool ok = bus && inspectShared(bus);
        if (bus) UnmapViewOfFile(bus);
        CloseHandle(handle); return ok ? 0 : 11;
    }
#else
int main() {
#endif
    auto bus = std::make_unique<SharedMedia>();
    prepare(bus.get());
    float out[8]{};
    assert(bus->readAudio(out, 8, 10, 48000, 10000000));
    assert(out[0] == .25f && out[7] == .25f);
    bus->enabled = 0; assert(!bus->readAudio(out, 8, 10, 48000, 10000000));
    bus->enabled = 1; assert(!bus->readAudio(out, 8, 10, 48000, 12000000));
    assert(!bus->readAudio(out, 8, 10, 1000, 10000000));
    assert(!bus->readAudio(out, 8, -1, 48000, 10000000));
    bus->resetAudio(); assert(!bus->readAudio(out, 8, 10, 48000, 10000000));
    float ramp[] = {0, .5f, 1}; bus->writeAudio(ramp, 3, 10);
    assert(bus->readAudio(out, 2, 10, 96000, 10000000));
    assert(std::fabs(out[1] - .25f) < .001f);
    float invalid[] = {NAN, INFINITY}; bus->writeAudio(invalid, 2, 10);
    assert(bus->readAudio(out, 2, 10, 48000, 10000000));
    assert(std::fabs(out[0]) < .00001f && std::fabs(out[1]) < .00001f);
    // Tag rollover cannot expose NaN/uninitialized storage.
    double wrap = double(uint64_t(UINT32_MAX) + 40) / 48000;
    bus->heartbeatUS = uint64_t(wrap * 1000000);
    bus->writeAudio(ramp, 3, wrap);
    assert(bus->readAudio(out, 3, wrap, 48000, bus->heartbeatUS.load()));
    assert(std::fabs(out[1] - .5f) < .001f);
    assert(!bus->readAudio(out, 3, 10, 48000, bus->heartbeatUS.load())); // old clock cannot be consumed

    auto &slot = bus->video[0];
    assert(obs::acquireWriter(slot)); assert(!obs::acquireReader(slot)); obs::releaseWriter(slot);
    assert(obs::acquireReader(slot)); assert(obs::acquireReader(slot)); assert(!obs::acquireWriter(slot));
    obs::releaseReader(slot); assert(!obs::acquireWriter(slot)); obs::releaseReader(slot);
    assert(obs::acquireWriter(slot)); obs::releaseWriter(slot);
    assert(obs::heartbeatFresh(obs::heartbeatState(42, 100), 102));
    assert(!obs::heartbeatFresh(obs::heartbeatState(42, 100), 104));
    double hbWrap = double(UINT32_MAX) / 1000;
    assert(obs::heartbeatFresh(obs::heartbeatState(42, hbWrap), hbWrap + 1));
    assert(!obs::heartbeatFresh(0, 0));

    // Two real processes see the same PCM and coordinate the same slot lease.
#ifdef _WIN32
    std::wstring name = L"Local\\OBSBridgeProtocol-" + std::to_wstring(GetCurrentProcessId());
    HANDLE handle = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(SharedMedia), name.c_str());
    assert(handle && GetLastError() != ERROR_ALREADY_EXISTS);
    auto *shared = static_cast<SharedMedia *>(MapViewOfFile(handle, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedMedia)));
    assert(shared); prepare(new (shared) SharedMedia);
    wchar_t exe[32768]; assert(GetModuleFileNameW(nullptr, exe, 32768));
    std::wstring command = L"\"" + std::wstring(exe) + L"\" --shared-child " + name;
    STARTUPINFOW startup{}; startup.cb = sizeof(startup);
    PROCESS_INFORMATION process{};
    assert(CreateProcessW(nullptr, command.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW,
        nullptr, nullptr, &startup, &process));
    assert(WaitForSingleObject(process.hProcess, 10000) == WAIT_OBJECT_0);
    DWORD result = 99; assert(GetExitCodeProcess(process.hProcess, &result)); assert(result == 0);
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
#else
    void *memory = mmap(nullptr, sizeof(SharedMedia), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANON, -1, 0);
    assert(memory != MAP_FAILED);
    auto *shared = new (memory) SharedMedia; prepare(shared);
    pid_t pid = fork(); assert(pid >= 0);
    if (!pid) _exit(inspectShared(shared) ? 0 : 11);
    int result = 99; assert(waitpid(pid, &result, 0) == pid); assert(WIFEXITED(result) && WEXITSTATUS(result) == 0);
#endif
    assert(shared->video[0].lease.load() == 1);
    assert(!obs::acquireWriter(shared->video[0]));
    obs::releaseReader(shared->video[0]); assert(obs::acquireWriter(shared->video[0]));
    obs::releaseWriter(shared->video[0]);
#ifdef _WIN32
    UnmapViewOfFile(shared); CloseHandle(handle);
#else
    munmap(shared, sizeof(SharedMedia));
#endif

    // Atomic PCM cells never expose torn tag/value pairs during concurrent writes.
    prepare(bus.get()); std::atomic<bool> done{false};
    std::thread writer([&]{ float samples[8]; std::fill(std::begin(samples), std::end(samples), .75f);
        for (unsigned i = 0; i < 10000; ++i) bus->writeAudio(samples, 8, 10);
        done = true; });
    while (!done.load()) {
        if (bus->readAudio(out, 8, 10, 48000, 10000000))
            for (float sample : out) assert(sample == .25f || sample == .75f);
    }
    writer.join();
    float source[] = {.5f, -.5f}, mic[] = {.25f, -.25f};
    obs::PCMBuffer buffer{mic, sizeof(mic), 1};
    assert(obs::mixSamples(source, &buffer, 1, 2, obs::PCMKind::Float32, 1, 1));
    assert(mic[0] == .75f && mic[1] == -.75f);
    std::cout << "PASS: shared PCM, freshness, reset, wrap, resampling, leases, real two-process mapping, atomic concurrency, mic+OBS mix\n";
}
