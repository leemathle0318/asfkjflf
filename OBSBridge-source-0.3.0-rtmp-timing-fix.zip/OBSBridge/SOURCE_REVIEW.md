# 公开源码审查与实际复用（2026-10-12）

本记录区分源码事实、作者声明、本机检查与手机实测。没有找到已独立验证同时满足“8 Plus / 15.0.2 / rootless / OBS TCP / 系统视频替换 / OBS音频+真实麦克风”的完整公开成品。

## 1. 实际接入：opa334/libSandy

审查固定提交 `9c77311172485e92bf0c439391be5a9565c877e4`：README、公开头文件、库实现、sandyd 的调用者校验/文件 profile 实现、Makefile 和 MIT LICENSE。

- [公开接口与实现](https://github.com/opa334/libSandy/blob/9c77311172485e92bf0c439391be5a9565c877e4/libSandy.m)
- [服务端 profile 与调用者检查](https://github.com/opa334/libSandy/blob/9c77311172485e92bf0c439391be5a9565c877e4/sandyd/main.m)
- [MIT 许可证](https://github.com/opa334/libSandy/blob/9c77311172485e92bf0c439391be5a9565c877e4/LICENSE)

实际复用的是安装依赖提供的公开 `libSandy_applyProfile` 接口；新增自己的最小文件只读 profile、异步适配器与实际访问探测。不是复制整个项目，也不是自己重写扩展签发逻辑。

重要源码事实：返回 0 是拿到扩展字符串；库实现没有根据 consume 返回值重新判定授权成功。因此本工程另做真实 open/mmap/协议探测，避免再把“调用成功”说成“摄像头已替换”。进程签名标识和该机沙盒是否支持扩展未经过真机确认，不会以通配进程兜底。

## 2. GUSHU101/VCamLab-2.0：研究，不直接搬代码

审查提交 `d0c11066176fa1dea6b5f148d5290e6425aff905` 的共享媒体总线、协议、系统视频输出入口、音频转换和设备测试计划。

[源码及功能说明](https://github.com/GUSHU101/VCamLab-2.0/tree/d0c11066176fa1dea6b5f148d5290e6425aff905)。其网络模式未发布替换音频，不能直接满足 OBS 音轨与手机麦克风混合的全部需求；设备测试计划不是通过记录。审查的文件树未发现许可证，不直接复制其实现或二进制。接口原理可以对照研究，不能说“拼好就已经可用”。

## 3. EthanArbuckle/vcam-ios：入口原理，不是稳定成品

审查提交 `55560cb5a1fd20fddb44ade179018a6111d31225` 的 Tweak.x 和 README。

[作者项目](https://github.com/EthanArbuckle/vcam-ios)。作者将其定位为 POC，并注明资源泄漏导致媒体服务短时间退出；审查树未发现许可证。不直接复制媒体实现。系统 `BWNodeOutput emitSampleBuffer:` 入口作为研究依据，本工程自己的 hook 回调已在用户截图中出现，但这不证明样本替换已经成功。

## 4. notaudren/VCam-iOS-16：不是可借用实现源码

审查提交 `be2a71cef42dbe3ce77ea190422fc208569b8250` 的文件树只有 README，没有插件实现源文件。

[仓库](https://github.com/notaudren/VCam-iOS-16)。作者宣传的 iOS16 支持不是 15.0.2 验证记录；不能把说明文字当源代码拼接。

## 结论

能借鉴，也已经实际整合有明确许可证的现成授权组件。保持用户已证实的网络、解码、发布和系统回调部分，只修当前缓存打不开的断点。音频路径仍是自己的实现，未找到可合法直接移植且覆盖全部需求的已验证组合；未用借鉴一词掩盖这项差距。

本机没有该手机、没有其系统拒绝日志/远程访问；0.2.4 仍需设备证据，不能当作已完成的可用插件交付。

## 0.2.6 音频参考与修改边界

对照审查VCamLab-2.0的 `VCAudioSampleConverter.m` 原生float/integer/分通道和节点游标接口思路；没有复制未明确授权的代码。本版NativePCM与AudioSample是独立实现。作者网络模式/测试计划不构成OBS+手机麦克风的已通过证据。

[已审查固定版本音频文件](https://github.com/GUSHU101/VCamLab-2.0/blob/d0c11066176fa1dea6b5f148d5290e6425aff905/VCAudioSampleConverter.m)。Apple SDK CoreMedia/CoreAudioTypes头文件用于核对样本构造、非交错大小数组、原生ASBD位标记与错误常量；[Apple CreateReady 文档](https://developer.apple.com/documentation/coremedia/cmsamplebuffercreateready(allocator:databuffer:formatdescription:samplecount:sampletimingentrycount:sampletimingarray:samplesizeentrycount:samplesizearray:samplebufferout:))。

0.2.4设备授权已由用户后续截图确认；本版保持该访问路径，不再次把libSandy接口调用本身当成功。音频真实ASBD/OSStatus仍未知，用实际运行的格式诊断而不是推测取代证据。

## 0.2.7 音频提取接口核对

已读取Apple CMSampleBuffer.h关于查询bufferListSizeNeededOut、容量不足返回ArrayTooSmall和保留block生命周期的注释。另对照WebKit固定提交10ea3bdfd9009b070aa95cb6e46e7948f0b1b7f6的两阶段查询/提取调用方式；本版按公开接口独立实现，没有直接搬WebKit封装。

用户0.2.6真实CoreMedia测试失败已加入TEST_RESULTS；错误码尚未知，不把文档中的可能错误当成实际返回。0.2.7保留所有测试并自动打印细节。

## 0.2.9 新证据与接口契约处理

0.2.7用户真实CoreMedia测试返回-12737并报告所需24字节，但没有查询/填充阶段，因此不假定只有内存大小问题。本版分别保留两次原生返回值，验证有效大小后允许尺寸查询ArrayTooSmall继续，初始化列表条目容量，以精确查询大小和第二次nullptr尺寸输出进行填充。所有真实API测试保留。
