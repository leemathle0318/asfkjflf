#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <substrate.h>
#import "Shared.h"
#import "Client.h"
#include "core/Shortcut.hpp"
#include <notify.h>
#include <sys/stat.h>
#include <cstring>

namespace {
using VolumeIMP = void (*)(id, SEL);
VolumeIMP originalUp = nullptr, originalDown = nullptr;
bool hooksReady = false;
obs::UpDownShortcut sequence;
NSString *hookDescription = @"尚未检查音量接口";
NSString *lastLockCheck = @"尚未检查";
unsigned long long upCallbacks = 0, downCallbacks = 0;
dispatch_source_t hookTimer;

void writeShortcutStatus(NSString *message) {
    NSDictionary *status = @{@"Version": OB_VERSION, @"Date": [NSDate date],
        @"HooksReady": @(hooksReady), @"Hook": hookDescription ?: @"", @"Message": message ?: @"",
        @"UpCallbacks": @(upCallbacks), @"DownCallbacks": @(downCallbacks), @"LockCheck": lastLockCheck};
    if ([status writeToFile:OB_SHORTCUT_STATUS atomically:YES])
        chmod(OB_SHORTCUT_STATUS.fileSystemRepresentation, 0644);
}
bool isVoidNoArgs(Method method) {
    if (!method || method_getNumberOfArguments(method) != 2) return false;
    char type[32]{}; method_getReturnType(method, type, sizeof(type));
    return !strcmp(type, "v");
}
bool isUnlocked() {
    Class cls = objc_getClass("SBLockScreenManager");
    SEL shared = sel_registerName("sharedInstance"), locked = sel_registerName("isUILocked");
    Method factory = cls ? class_getClassMethod(cls, shared) : nullptr;
    Method getter = cls ? class_getInstanceMethod(cls, locked) : nullptr;
    if (!factory || !getter || method_getNumberOfArguments(factory) != 2 ||
        method_getNumberOfArguments(getter) != 2) return false;
    char result[128]{};
    method_getReturnType(factory, result, sizeof(result));
    if (result[0] != '@') return false;
    method_getReturnType(getter, result, sizeof(result));
    if (result[0] != 'B' && result[0] != 'c') return false;
    id manager = ((id (*)(id, SEL))objc_msgSend)((id)cls, shared);
    return manager && !((BOOL (*)(id, SEL))objc_msgSend)(manager, locked);
}
}

@interface OBShortcutController : NSObject
@property(nonatomic, strong) UIWindow *window;
@property(nonatomic, weak) UIWindow *previousWindow;
- (void)showMenu;
- (void)showMore;
- (void)close;
@end

@implementation OBShortcutController
- (UIViewController *)openWindow {
    if (!isUnlocked() || self.window) return nil;
    UIWindow *old = nil;
    UIWindowScene *scene = nil;
    for (UIScene *candidate in UIApplication.sharedApplication.connectedScenes) {
        if (![candidate isKindOfClass:UIWindowScene.class] ||
            candidate.activationState != UISceneActivationStateForegroundActive) continue;
        UIWindowScene *windowScene = (UIWindowScene *)candidate;
        if (!scene) scene = windowScene;
        for (UIWindow *window in windowScene.windows) {
            if (window.isKeyWindow) { old = window; scene = windowScene; break; }
        }
        if (old) break;
    }
    self.previousWindow = old;
    UIWindow *window = scene ? [[UIWindow alloc] initWithWindowScene:scene] :
                              [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    window.frame = UIScreen.mainScreen.bounds;
    window.windowLevel = UIWindowLevelAlert + 1;
    window.backgroundColor = UIColor.clearColor;
    UIViewController *root = [UIViewController new];
    root.view.backgroundColor = UIColor.clearColor;
    window.rootViewController = root;
    self.window = window;
    [window makeKeyAndVisible];
    return root;
}
- (void)close {
    [self.window.rootViewController dismissViewControllerAnimated:NO completion:nil];
    self.window.hidden = YES;
    self.window.rootViewController = nil;
    self.window = nil;
    if (isUnlocked()) [self.previousWindow makeKeyWindow];
    self.previousWindow = nil;
}
- (void)showMessage:(NSString *)message {
    // Allow the preceding UIAlertAction's automatic dismissal to finish.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC / 3), dispatch_get_main_queue(), ^{
        @autoreleasepool {
            UIViewController *root = [self openWindow];
            if (!root) return;
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:
                @"tk推流助手" message:message preferredStyle:UIAlertControllerStyleAlert];
            __weak OBShortcutController *weakSelf = self;
            [alert addAction:[UIAlertAction actionWithTitle:@"关闭" style:UIAlertActionStyleCancel
                handler:^(UIAlertAction *action) { (void)action; [weakSelf close]; }]];
            [root presentViewController:alert animated:YES completion:nil];
        }
    });
}
- (void)showMenu {
    UIViewController *root = [self openWindow];
    if (!root) return;
    NSString *url = OBCURL() ?: @"未连接 Wi-Fi";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:
        @"tk推流助手"
        message:[NSString stringWithFormat:@"%@\n%@", OBCSummary(), url]
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"电脑 IP，例如 192.168.1.100";
        field.text = OBCPeerIP();
        field.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
    }];
    __weak OBShortcutController *weakSelf = self;
    __weak UIAlertController *weakAlert = alert;
    [alert addAction:[UIAlertAction actionWithTitle:@"开始接收 OBS" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action;
        NSString *peer = [weakAlert.textFields.firstObject.text copy];
        NSString *error = OBCSendCommand(YES, peer);
        NSString *result = error ?: [NSString stringWithFormat:@"启动请求已发送\nOBS 输出地址：%@", OBCURL() ?: @"未知"];

        [weakSelf close]; [weakSelf showMessage:result];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"停止并恢复摄像头" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        (void)action;
        NSString *result = OBCSendCommand(NO, nil) ?: @"停止请求已发送";
        [weakSelf close]; [weakSelf showMessage:result];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"复制手机 TCP 地址" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action;
        NSString *value = OBCURL();
        if (value) UIPasteboard.generalPasteboard.string = value;
        [weakSelf close]; [weakSelf showMessage:value ? [@"已复制：" stringByAppendingString:value] : @"未找到手机 Wi-Fi IPv4。"]; 
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"更多设置" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action; [weakSelf close];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC / 3), dispatch_get_main_queue(), ^{ [weakSelf showMore]; });
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        (void)action; [weakSelf close];
    }]];
    [root presentViewController:alert animated:YES completion:^{ writeShortcutStatus(@"菜单已显示"); }];
}
- (void)showMore {
    UIViewController *root = [self openWindow]; if (!root) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"更多设置" message:nil preferredStyle:UIAlertControllerStyleAlert];
    __weak OBShortcutController *weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:
        [NSString stringWithFormat:@"画面旋转 +90°（当前额外 %ld°）", (long)OBCVideoRotation() * 90]
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action;
        NSInteger next = (OBCVideoRotation() + 1) & 3;
        NSString *error = OBCSetVideoRotation(next);
        NSString *result = error ?: [NSString stringWithFormat:@"已旋转至 %ld°", (long)next * 90];
        [weakSelf close]; [weakSelf showMessage:result];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:
        [NSString stringWithFormat:@"OBS 声音混入直播：%@", OBCLiveAudioEnabled() ? @"开" : @"关"]
        style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action; NSString *error = OBCSetLiveAudioEnabled(!OBCLiveAudioEnabled());
        [weakSelf close]; [weakSelf showMessage:error ?: @"声音设置已保存"];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"完整状态" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action; NSString *text = OBCStatus();
        [weakSelf close]; [weakSelf showMessage:text];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"复制完整状态" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        (void)action; UIPasteboard.generalPasteboard.string = OBCStatus();
        [weakSelf close]; [weakSelf showMessage:@"状态已复制"];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"关闭" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        (void)action; [weakSelf close];
    }]];
    [root presentViewController:alert animated:YES completion:nil];
}

@end

namespace {
OBShortcutController *controller;
void observeButton(bool up) {
    double time = NSProcessInfo.processInfo.systemUptime;
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            if (up) ++upCallbacks; else ++downCallbacks;
            bool unlocked = isUnlocked();
            lastLockCheck = unlocked ? @"已确认解锁" : @"锁屏中，或解锁状态接口未匹配";
            if (controller.window || !unlocked) {
                sequence.reset();
                if (upCallbacks + downCallbacks <= 6) writeShortcutStatus(@"收到音量回调，菜单已打开或当前无法确认解锁，未新开菜单");
                return;
            }
            if (sequence.button(up, time)) {
                writeShortcutStatus(@"识别到音量上 → 音量下");
                [controller showMenu];
            } else if (upCallbacks + downCallbacks <= 6) writeShortcutStatus(@"已收到音量方法回调，等待完整的上→下顺序");
        }
    });
}
void up(id self, SEL cmd) { originalUp(self, cmd); observeButton(true); }
void down(id self, SEL cmd) { originalDown(self, cmd); observeButton(false); }
bool installHooks() {
    if (hooksReady) return true;
    Class cls = objc_getClass("SBVolumeControl");
    SEL plus = sel_registerName("increaseVolume"), minus = sel_registerName("decreaseVolume");
    Method a = cls ? class_getInstanceMethod(cls, plus) : nullptr;
    Method b = cls ? class_getInstanceMethod(cls, minus) : nullptr;
    if (!isVoidNoArgs(a) || !isVoidNoArgs(b)) {
        hookDescription = @"SBVolumeControl 音量接口未加载或签名不匹配";
        return false;
    }
    MSHookMessageEx(cls, plus, (IMP)up, (IMP *)&originalUp);
    MSHookMessageEx(cls, minus, (IMP)down, (IMP *)&originalDown);
    hooksReady = true;
    hookDescription = @"SBVolumeControl increaseVolume/decreaseVolume 已挂接（待按键实测）";
    writeShortcutStatus(@"快捷键观察器已安装；仅解锁状态下显示菜单");
    return true;
}
}

__attribute__((constructor)) static void OBShortcutInitialize() {
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            controller = [OBShortcutController new];
            writeShortcutStatus(@"SpringBoard 模块已加载");
            int token;
            notify_register_dispatch("com.apple.springboard.lockstate", &token, dispatch_get_main_queue(), ^(int value) {
                (void)value;
                if (!isUnlocked()) { sequence.reset(); [controller close]; }
            });
            if (installHooks()) return;
            // A bounded wait covers classes loaded late during SpringBoard startup.
            __block unsigned attempts = 0;
            hookTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
            dispatch_source_set_timer(hookTimer, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC),
                                      NSEC_PER_SEC, NSEC_PER_SEC / 10);
            dispatch_source_set_event_handler(hookTimer, ^{
                if (installHooks() || ++attempts >= 30) {
                    if (!hooksReady) writeShortcutStatus(@"快捷键接口不匹配，未安装按键 Hook");
                    dispatch_source_cancel(hookTimer); hookTimer = nil;
                }
            });
            dispatch_resume(hookTimer);
        }
    });
}
