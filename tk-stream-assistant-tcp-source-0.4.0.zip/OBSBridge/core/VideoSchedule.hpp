#pragma once
#include <algorithm>
namespace obs {
template<class Queue> double nextVideoDelay(const Queue &pending, double now) {
    return pending.empty() ? .5 : std::max(0., std::min(.5, pending.front()->due - now));
}
}
