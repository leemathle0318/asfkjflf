#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import "../Shared.h"
#import "../Client.h"
@interface OBPrefs : PSListController
@end
@implementation OBPrefs
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (![key isKindOfClass:NSString.class]) return nil;
    if ([key isEqualToString:@"LiveAudio"]) return @(OBCLiveAudioEnabled());
    return [key isEqualToString:@"PCIP"] ? OBCPeerIP() : [specifier propertyForKey:@"default"];
}
- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if ([key isEqualToString:@"LiveAudio"] && [value isKindOfClass:NSNumber.class]) {
        NSString *error = OBCSetLiveAudioEnabled([value boolValue]); if (error) [self message:error]; return;
    }
    if (![key isEqualToString:@"PCIP"] || ![value isKindOfClass:NSString.class]) return;
    NSString *error = OBCSavePeerIP(value);
    if (error) [self message:error];
}
- (void)message:(NSString *)text {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"tk推流助手"
        message:text preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (BOOL)command:(BOOL)enabled {
    [self.view endEditing:YES];
    NSString *error = OBCSendCommand(enabled, OBCPeerIP());
    if (error) { [self message:error]; return NO; }
    return YES;
}
- (void)startLive {
    if ([self command:YES]) [self message:[NSString stringWithFormat:
        @"启动请求已发送\nOBS 输出地址：%@", OBCURL()]];
}
- (void)stopLive { if ([self command:NO]) [self message:@"停止请求已发送"]; }
- (void)copyURL {
    NSString *url = OBCURL();
    if (!url) { [self message:@"未找到 Wi-Fi IPv4 地址"]; return; }
    UIPasteboard.generalPasteboard.string = url;
    [self message:@"手机 TCP 地址已复制"]; 
}
- (void)showStatus {
    [self message:OBCSummary()];
}
- (void)rotateVideo {
    NSInteger next = (OBCVideoRotation() + 1) & 3;
    NSString *error = OBCSetVideoRotation(next);
    [self message:error ?: [NSString stringWithFormat:@"已旋转至 %ld°", (long)next * 90]];
}
- (void)copyStatus { UIPasteboard.generalPasteboard.string = OBCStatus(); [self message:@"状态已复制"]; }
@end
