#pragma once
#define OB_DOMAIN CFSTR("local.xiaoguai.obsbridge")
#define OB_NOTIFY "local.xiaoguai.obsbridge.changed"
#define OB_CONFIG @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.plist"
#define OB_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.status.plist"
#define OB_PORT 5000
#define OB_VERSION @"0.4.0"
#define OB_VERSION_CODE 0x00040001u
#define OB_AUDIO_NOTIFY "local.xiaoguai.obsbridge.v6.audio"
#define OB_VIDEO_ROTATION_NOTIFY "local.xiaoguai.obsbridge.v6.video.rotation"
#define OB_ACCESS_PROFILE "local.xiaoguai.obsbridge.media-read"
#define OB_ACCESS_NOTIFY "local.xiaoguai.obsbridge.v6.media.read-permission"
#define OB_BUS_FILE "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v6.dat"
#define OB_BUS_NOTIFY "local.xiaoguai.obsbridge.v6.bus"
#define OB_MEDIA_HEARTBEAT "local.xiaoguai.obsbridge.v2.media.heartbeat"
#define OB_MEDIA_HOOKS "local.xiaoguai.obsbridge.v2.media.hooks"
#define OB_MEDIA_COUNTS "local.xiaoguai.obsbridge.v2.media.counts"
#define OB_MEDIA_MAPPING "local.xiaoguai.obsbridge.v6.media.mapping"
#if OB_APP_AUDIO
// Separate diagnosis/authorization channels: the app must not overwrite media
// service mapping status, identity or health notifications.
#undef OB_ACCESS_PROFILE
#define OB_ACCESS_PROFILE "local.xiaoguai.obsbridge.live-read"
#undef OB_ACCESS_NOTIFY
#define OB_ACCESS_NOTIFY "local.xiaoguai.obsbridge.live.read-permission"
#undef OB_MEDIA_MAPPING
#define OB_MEDIA_MAPPING "local.xiaoguai.obsbridge.live.mapping"
#endif
#define OB_SHORTCUT_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.shortcut.status.plist"
